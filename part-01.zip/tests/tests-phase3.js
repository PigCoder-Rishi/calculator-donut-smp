import { defaultState, sanitizeState } from "../src/state.js";
import {
  updatePrice,
  priceChange,
  loadExamples,
  priceKey,
} from "../src/core.js";
import { formatMoney } from "../src/core.js";
import {
  bulkPlan,
  evaluatePlan,
  dropTolerance,
  combineTrades,
} from "../src/core.js";
import { recipes, resolveRecipe } from "../src/core.js";
import { calculate } from "../src/core.js";
import { encodePayload, decodePayload } from "../src/core.js";
export async function phase3Tests() {
  let count = 0;
  const check = (ok, msg) => {
    if (!ok) throw Error(msg);
    count++;
  };
  const proof = JSON.parse(
    await (
      await import("node:fs/promises")
    ).readFile(new URL("./recipe-checksum.json", import.meta.url), "utf8"),
  );
  const added = JSON.parse(
    await (
      await import("node:fs/promises")
    ).readFile(new URL("../data/recipes.json", import.meta.url), "utf8"),
  );
  check(
    (await import("node:crypto"))
      .createHash("sha256")
      .update(JSON.stringify(added))
      .digest("hex") === proof.schemaSha256,
    "Verified recipe schema checksum",
  );
  const state = defaultState();
  for (let n = 1; n <= 60; n++)
    updatePrice(
      state,
      "prices",
      "bone",
      String(n),
      "1",
      new Date(n * 1000).toISOString(),
    );
  check(
    state.prices.bone.history.length === 50 &&
      state.prices.bone.history[0].value === "11",
    "History cap keeps latest 50",
  );
  check(
    Math.abs(priceChange(state.prices.bone) - 100 / 59) < 1e-10,
    "Price percentage delta",
  );
  updatePrice(state, "prices", "bone", "60");
  check(
    state.prices.bone.history.length === 50,
    "Identical price has no duplicate history",
  );
  const old = {
    version: 2,
    prices: { bone: { value: "3k", unit: "64", updated: "2025-01-01" } },
    inputs: { bones: { amount: "100", sell: "500" } },
    history: [
      {
        name: "Trade",
        date: "2025-01-01",
        quantity: 2,
        profit: 1,
        cost: 2,
        revenue: 3,
      },
    ],
  };
  const migrated = sanitizeState(old);
  check(
    migrated.version === 4 &&
      migrated.prices.bone.value === "3k" &&
      migrated.inputs.bones.amount === "100" &&
      migrated.history.length === 1,
    "Version 2 data migrates without loss",
  );
  check(
    migrated.prices.bone.history.length === 0 &&
      !migrated.compactMoney &&
      migrated.plans.length === 0,
    "Migration new defaults",
  );
  check(
    sanitizeState(JSON.parse(JSON.stringify(state))).prices.bone.history
      .length === 50,
    "Histories export/import",
  );
  check(
    formatMoney(1500000, true) === "$1.5m" &&
      formatMoney(2300000000, true) === "$2.3b" &&
      formatMoney(-1250, true) === "-$1.25k",
    "Compact signed money",
  );
  const chest = calculate(
    resolveRecipe("chests"),
    { amount: "10", sell: "300" },
    { "spruce-log": 100 },
  );
  check(
    Math.abs(dropTolerance(chest) - 100 / 3) < 1e-10,
    "Sell drop tolerance",
  );
  check(
    dropTolerance({ ...chest, sale: 0 }) === null,
    "No zero-sale risk division",
  );
  const fees = calculate(
    resolveRecipe("chests"),
    {
      amount: "10",
      sell: "300",
      fees: { enabled: true, percent: "10", flat: "5", listings: "2" },
    },
    { "spruce-log": 100 },
  );
  check(
    Math.abs(dropTolerance(fees) - (300 - fees.breakEven) / 3) < 1e-10,
    "Risk includes fees",
  );
  const data = defaultState();
  data.prices["spruce-log"] = { value: "100", unit: "1" };
  data.sells["chests:"] = { value: "300", unit: "1" };
  const planned = bulkPlan(data, { budget: 1050, count: 1 });
  check(
    planned.cost === 1000 &&
      planned.profit === 500 &&
      planned.unspent === 50 &&
      planned.rows[0].quantity === 10,
    "Bulk whole material budget",
  );
  const capped = bulkPlan(data, { budget: 10000, count: 1, cap: 400 });
  check(capped.cost === 400 && capped.unspent === 9600, "Bulk cap");
  check(
    bulkPlan(defaultState(), { budget: 1000 }).items.length === 0,
    "No guessed prices",
  );
  check(bulkPlan(data, { budget: 0 }).cost === 0, "Zero budget");
  check(
    bulkPlan(data, { budget: 1000, fees: { enabled: true, percent: "100" } })
      .items.length === 0,
    "Bulk excludes fee loss",
  );
  const p = {
    name: "Two trades",
    items: [
      {
        recipeId: "chests",
        input: { amount: "10", sell: "300" },
        prices: data.prices,
      },
      {
        recipeId: "chests",
        input: { amount: "4", sell: "400" },
        prices: data.prices,
      },
    ],
  };
  const combined = evaluatePlan(p);
  check(
    combined.cost === 1400 &&
      combined.revenue === 2300 &&
      combined.profit === 900 &&
      combined.rows[0].quantity === 14,
    "Plan aggregates material and totals",
  );
  const sanitized = sanitizeState({ version: 3, plans: [p] });
  check(
    evaluatePlan(sanitized.plans[0]).profit === 900,
    "Plan survives persistence",
  );
  for (const options of [
    { budget: -1 },
    { budget: 100, count: 0 },
    { budget: 100, cap: 0 },
  ]) {
    let rejected = false;
    try {
      bulkPlan(data, options);
    } catch {
      rejected = true;
    }
    check(rejected, "Invalid plan option rejected");
  }
  let rejected = false;
  try {
    combineTrades([
      {
        result: {
          cost: Number.MAX_SAFE_INTEGER,
          revenue: 1,
          profit: 1,
          feeCost: 0,
          rows: [],
        },
      },
      { result: { cost: 10, revenue: 1, profit: 1, feeCost: 0, rows: [] } },
    ]);
  } catch {
    rejected = true;
  }
  check(rejected, "Plan overflow");
  const payload = { version: 3, type: "plan", plan: p };
  check(
    JSON.stringify(await decodePayload(await encodePayload(payload))) ===
      JSON.stringify(payload),
    "Compressed plan link round-trip",
  );
  const book = { version: 3, type: "book", prices: state.prices, sells: {} };
  check(
    (await decodePayload(await encodePayload(book))).prices.bone.history
      .length === 50,
    "Price book link keeps histories",
  );
  const baselineCounts = [9, 1, 9, 1, 9, 1, 9, 1, 9, 1, 9, 9, 9, 9, 3, 9, 4, 8];
  for (const [index, r] of recipes.filter((r) => r.sourceRecipe).entries()) {
    check(
      r.outputCount === (r.id.endsWith("-unpack") ? 9 : 1),
      "Verified output " + r.id,
    );
    for (const ing of r.ingredients)
      check(
        Number.isInteger(ing.count) && ing.count > 0,
        "Verified ingredient " + r.id + "/" + ing.id,
      );
    const result = calculate(
      r,
      { amount: String(r.outputCount * 2), sell: "200" },
      Object.fromEntries(r.ingredients.map((i) => [i.id, 10])),
    );
    check(
      result.cost === baselineCounts[index] * 20 &&
        result.crafted === r.outputCount * 2 &&
        result.profit === r.outputCount * 400 - baselineCounts[index] * 20,
      "New baseline " + r.id,
    );
  }
  return count;
}
