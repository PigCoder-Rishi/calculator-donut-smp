// Node smoke test for service worker caching and local static assets.
import fs from "node:fs/promises";
const base = process.env.BASE_URL || "http://localhost:8080/";
const handlers = {},
  stores = new Map();
const originalFetch = fetch;
let offline = false,
  assertions = 0;
function assert(condition, message) {
  if (!condition) throw Error(message);
  assertions++;
}
const key = (request) =>
  typeof request === "string" ? new URL(request, base).href : request.url;
global.self = {
  location: { origin: new URL(base).origin },
  addEventListener: (name, fn) => (handlers[name] = fn),
  skipWaiting: async () => {},
  clients: { claim: async () => {} },
};
global.fetch = async (request) => {
  if (offline) throw Error("offline");
  return originalFetch(
    typeof request === "string"
      ? new URL(request, base)
      : request.url || request,
  );
};
global.caches = {
  open: async (name) => {
    if (!stores.has(name)) stores.set(name, new Map());
    const map = stores.get(name);
    return {
      addAll: async (assets) => {
        for (const asset of assets) {
          const response = await fetch(asset);
          assert(response.ok, "Asset available: " + asset);
          map.set(key(asset), response);
        }
      },
      put: async (request, response) => map.set(key(request), response),
      match: async (request) => map.get(key(request))?.clone(),
    };
  },
  keys: async () => [...stores.keys()],
  delete: async (name) => stores.delete(name),
};
const build = JSON.parse(
  await fs.readFile(new URL("../reports/build.json", import.meta.url), "utf8"),
);
await import("../dist/sw.js");
let install;
handlers.install({ waitUntil: (p) => (install = p) });
await install;
stores.set("donut-profit-old", new Map());
stores.set("unrelated-app", new Map());
let activate;
handlers.activate({ waitUntil: (p) => (activate = p) });
await activate;
assert(
  !stores.has("donut-profit-old") && stores.has("unrelated-app"),
  "Only own old caches removed",
);
offline = true;
let response;
handlers.fetch({
  request: {
    url: new URL(build.entry, base).href,
    method: "GET",
    mode: "cors",
  },
  waitUntil() {},
  respondWith: (p) => (response = p),
});
assert(
  (await (await response).text()).length > 100,
  "Calculator code available offline",
);
handlers.fetch({
  request: {
    url: new URL("unknown-page", base).href,
    method: "GET",
    mode: "navigate",
  },
  waitUntil() {},
  respondWith: (p) => (response = p),
});
assert(
  (await (await response).text()).includes("trade-form"),
  "Navigation has offline app fallback",
);
let externalHandled = false;
handlers.fetch({
  request: { url: "https://example.com/never-requested", method: "GET" },
  respondWith: () => (externalHandled = true),
});
assert(!externalHandled, "External requests not intercepted");
for (const size of [192, 512]) {
  const data = await fs.readFile(
    new URL(`../public/images/icon-${size}.png`, import.meta.url),
  );
  assert(
    data.readUInt32BE(16) === size && data.readUInt32BE(20) === size,
    "PWA PNG dimensions " + size,
  );
}
const manifest = JSON.parse(
  await fs.readFile(
    new URL("../public/manifest.webmanifest", import.meta.url),
    "utf8",
  ),
);
assert(
  manifest.icons.length === 3 && manifest.display === "standalone",
  "Install manifest",
);
for (const icon of manifest.icons)
  assert(
    (await fs.stat(new URL("../public/" + icon.src, import.meta.url))).isFile(),
    "Manifest image exists: " + icon.src,
  );
const banner = await fs.readFile(
  new URL("../public/images/social-banner.png", import.meta.url),
);
assert(
  banner.readUInt32BE(16) === 1200 && banner.readUInt32BE(20) === 630,
  "Social banner dimensions",
);
const html = await fs.readFile(
  new URL("../index.html", import.meta.url),
  "utf8",
);
assert(
  html.includes(
    "https://calculator-donut-smp.vercel.app/images/social-banner.png",
  ),
  "Social image uses absolute images path",
);
console.log({
  offlineChecks: assertions,
  limitations:
    "Service worker tested in simulation; browser installation still needs a connected browser.",
});
