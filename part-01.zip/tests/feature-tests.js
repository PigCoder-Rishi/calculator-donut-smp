﻿import {
  calculate,
  normalizePrices,
  resolveRecipe,
  chainCostHook,
  parseBulkPrices,
  bookDiff,
  snapshotBook,
  actualTradeProfit,
  rankingValue,
  evaluatePlan,
  discordPlan,
} from "../src/core.js";
import { defaultState, sanitizeState } from "../src/state.js";
export function featureTests() {
  let passed = 0;
  const check = (ok, message) => {
    if (!ok) throw Error(message);
    passed++;
  };
  const throws = (fn, message) => {
    let error;
    try {
      fn();
    } catch (e) {
      error = e;
    }
    check(Boolean(error), message);
  };
  const chest = resolveRecipe("chests"),
    prices = { "spruce-log": { value: "100", unit: "1" } };
  for (let owned = 0; owned < 30; owned++)
    for (let amount = 0; amount < 30; amount++) {
      const input = {
        amount: String(amount),
        sell: "250",
        inventoryEnabled: true,
        inventory: { "spruce-log": String(owned) },
      };
      const r = calculate(chest, input, normalizePrices(chest, prices, input));
      check(
        r.cost === Math.max(0, amount - owned) * 100,
        "Inventory missing-only material cost",
      );
      check(
        r.profit === Math.floor(amount / 2) * 250 - r.cost,
        "Inventory profit preserves material order",
      );
    }
  const own = {
    amount: "4",
    sell: "250",
    inventoryEnabled: true,
    inventory: { "spruce-log": "4" },
  };
  check(
    calculate(chest, own, normalizePrices(chest, {}, own)).cost === 0,
    "Fully owned material needs no purchase price",
  );
  throws(
    () =>
      calculate(
        chest,
        { ...own, amount: "5" },
        normalizePrices(chest, {}, own),
      ),
    "Missing material needs its price",
  );
  throws(
    () =>
      calculate(
        chest,
        { ...own, inventory: { "spruce-log": "-1" } },
        normalizePrices(chest, prices, own),
      ),
    "Negative stock rejected",
  );
  const plan = {
    name: "Run",
    items: [
      { recipeId: "chests", input: own, prices },
      { recipeId: "chests", input: own, prices },
    ],
  };
  check(
    evaluatePlan(plan).cost === 400,
    "Plan never counts the same stock twice",
  );
  check(
    evaluatePlan(plan).rows[0].quantity === 4,
    "Shopping list includes only missing materials",
  );
  const slabs = resolveRecipe("slabs");
  const shared = {
    "spruce-log": { value: "100", unit: "1" },
    "spruce-plank": { value: "40", unit: "1" },
  };
  for (let batches = 1; batches < 100; batches++) {
    const r = chainCostHook(shared, { "spruce-plank": "auto" })(
      slabs,
      batches,
      {},
    );
    check(
      r.cost === Math.min(batches * 3 * 40, Math.ceil((batches * 3) / 4) * 100),
      "Auto route respects rounded batches",
    );
  }
  check(
    chainCostHook(
      { "spruce-plank": shared["spruce-plank"] },
      { "spruce-plank": "auto" },
    )(slabs, 1, {}).cost === 120,
    "Auto route tolerates missing raw price",
  );
  check(
    chainCostHook(
      { "spruce-log": shared["spruce-log"] },
      { "spruce-plank": "auto" },
    )(slabs, 1, {}).cost === 100,
    "Auto route tolerates missing buy price",
  );
  const budgetInput = { amount: "400", orderMode: "budget", sell: "60" };
  check(
    calculate(
      slabs,
      budgetInput,
      normalizePrices(slabs, { "spruce-plank": { value: "0" } }),
      chainCostHook(shared, { "spruce-plank": "auto" }),
    ).crafted === 30,
    "Budget re-evaluates automatic route at each quantity",
  );
  const glass = resolveRecipe("smelting");
  const gi = {
    amount: "9",
    sell: "10",
    inventoryEnabled: true,
    inventory: { sand: "8", charcoal: "1" },
  };
  check(
    calculate(
      glass,
      gi,
      normalizePrices(
        glass,
        { sand: { value: "2" }, charcoal: { value: "8" } },
        gi,
      ),
    ).cost === 10,
    "Inventory uses whole charcoal for glass",
  );
  check(
    calculate(
      glass,
      { ...gi, amount: "10", orderMode: "budget" },
      normalizePrices(
        glass,
        { sand: { value: "2" }, charcoal: { value: "8" } },
        gi,
      ),
    ).crafted === 9,
    "Budget handles owned free first batches",
  );
  const pasted = parseBulkPrices(
    'item,price,unit\n"Spruce logs",2.5k,64\nbone 20\nsell:Chests,500,1',
  );
  check(
    pasted.rows.length === 3 && !pasted.errors.length,
    "CSV and lines parse together",
  );
  check(
    pasted.rows[0].unit === "64" && pasted.rows[2].kind === "sells",
    "Paste preserves price units and sale distinction",
  );
  for (const bad of [
    "unknown 3",
    "bone -5",
    "bone 10\nbone 20",
    "bone,5,3",
    "bone NaN",
    "",
  ])
    check(
      parseBulkPrices(bad).errors.length > 0,
      "Invalid paste rejected: " + bad,
    );
  const state = defaultState();
  state.prices = prices;
  const before = snapshotBook(state, "Before", "one");
  state.prices["spruce-log"] = { value: "12800", unit: "64" };
  const after = snapshotBook(state, "After", "two");
  check(before.prices["spruce-log"].value === "100", "Snapshot is independent");
  check(
    !("history" in before.prices["spruce-log"]),
    "Snapshots avoid duplicating histories",
  );
  const diff = bookDiff(before, after);
  check(
    diff.length === 1 && diff[0].change === 100,
    "Diff normalizes stack prices",
  );
  check(
    bookDiff(before, { prices: {}, sells: {} })[0].after === null,
    "Diff shows removed prices",
  );
  const trade = {
    quantity: 10,
    cost: 100,
    profit: 190,
    actualSell: "40",
    snapshot: {
      fees: { enabled: true, percent: "10", flat: "5", listings: "2" },
    },
  };
  check(actualTradeProfit(trade) === 250, "Actual sale recalculates fees");
  check(
    actualTradeProfit({ ...trade, actualSell: "" }) === null,
    "Unknown actual sales remain unknown",
  );
  throws(
    () => actualTradeProfit({ ...trade, actualSell: "-1" }),
    "Negative actual prices rejected",
  );
  check(
    actualTradeProfit({ ...trade, actualSell: "0" }) === -110,
    "Zero actual sale is supported",
  );
  check(
    rankingValue({ profitPerItem: 3 }, "profitHour", "2k") === 6000,
    "Hourly ranking uses output rate",
  );
  check(
    rankingValue({ profitPerItem: 3 }, "profitHour", "") === null,
    "Missing output rate is not guessed",
  );
  state.favorites = ["chests:"];
  state.recent = ["slabs:"];
  state.bookSnapshots = [before, after];
  state.history = [
    {
      ...trade,
      name: "Chests",
      date: new Date().toISOString(),
      revenue: 300,
      notes: "Run",
      tags: ["daily"],
    },
  ];
  state.inputs.chests = own;
  state.plans = [{ ...plan, checked: ["spruce-log"] }];
  state.chains = { "slabs:": { "spruce-plank": "auto" } };
  const clean = sanitizeState(JSON.parse(JSON.stringify(state)));
  check(
    clean.history[0].notes === "Run" && clean.history[0].actualSell === "40",
    "History fields survive reload",
  );
  check(
    clean.bookSnapshots.length === 2 &&
      clean.favorites[0] === "chests:" &&
      clean.recent[0] === "slabs:",
    "Snapshots and preferences migrate",
  );
  check(
    clean.inputs.chests.inventory["spruce-log"] === "4" &&
      clean.plans[0].checked[0] === "spruce-log" &&
      clean.chains["slabs:"]["spruce-plank"] === "auto",
    "Inventory, checklist, auto choice survive reload",
  );
  check(
    discordPlan(
      { ...plan, checked: ["spruce-log"] },
      evaluatePlan(plan),
    ).includes(String.fromCharCode(0x2611) + " 4 Spruce logs"),
    "Discord checklist includes missing materials",
  );
  return passed;
}
