import { test, expect, openSection } from "../../tools/test-exports.js";
import fs from "node:fs/promises";
test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(page.locator("#quantity")).toBeVisible();
});
test("history coalesces typing and Enter ignores recipe search and summaries", async ({
  page,
}, info) => {
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  const search = page.locator("#recipe-search");
  if (info.project.name === "desktop") {
    await search.fill("Spruce");
    await search.press("Enter");
    await expect(page.locator("#notice")).not.toContainText("Trade saved");
  }
  const summary = page.locator(".fee-fields summary");
  await summary.focus();
  await summary.press("Enter");
  await expect(page.locator("#notice")).not.toContainText("Trade saved");
  await openSection(page, "Price Book");
  await page
    .getByRole("button", { name: "Load example prices", exact: true })
    .click();
  const bone = page.locator("#book-bone");
  await bone.fill("");
  await bone.pressSequentially("2.5k", { delay: 50 });
  await bone.blur();
  await expect
    .poll(
      async () =>
        JSON.parse(
          (await page.evaluate(() =>
            localStorage.getItem("donut-profit-v4"),
          )) || "{}",
        ).prices?.bone?.history?.at(-1)?.value,
    )
    .toBe("2.5k");
  const history = await page.evaluate(
    () =>
      JSON.parse(localStorage.getItem("donut-profit-v4")).prices.bone.history,
  );
  expect(history).toHaveLength(2);
  expect(history.map((p) => p.value)).toEqual(["100", "2.5k"]);
});
test("corrupt saved data has export and confirmed reset recovery", async ({
  page,
}) => {
  await page.addInitScript(() => {
    if (!localStorage.getItem("test-seeded")) {
      localStorage.setItem("donut-profit-v4", '{"broken"');
      localStorage.setItem("test-seeded", "true");
    }
  });
  await page.reload();
  await expect(
    page.getByRole("heading", { name: "Let’s recover your calculator" }),
  ).toBeVisible();
  const pending = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export data", exact: true }).click();
  const download = await pending;
  const raw = JSON.parse(await fs.readFile(await download.path(), "utf8"));
  expect(raw["donut-profit-v4"]).toBe('{"broken"');
  await page.getByRole("button", { name: "Reset data", exact: true }).click();
  await expect(
    page.getByRole("button", { name: "Confirm reset of calculator data" }),
  ).toBeVisible();
  await page
    .getByRole("button", { name: "Confirm reset of calculator data" })
    .click();
  await expect(page.locator("#quantity")).toBeVisible();
});
test("legacy trade links preview before changing prices", async ({ page }) => {
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  await page.waitForTimeout(700);
  const payload = {
    version: 1,
    mode: "chests",
    input: { amount: "10", orderMode: "quantity", sell: "300" },
    prices: { "spruce-log": { value: "17", unit: "1" } },
  };
  await page.goto("/#trade=" + encodeURIComponent(JSON.stringify(payload)));
  await expect(page.locator("#trade-link-preview")).toBeVisible();
  await expect(page.locator("#price-spruce-log")).toHaveValue("100");
  expect(page.url()).toContain("#data=");
  await page.getByRole("button", { name: "Apply shared trade" }).click();
  await expect(page.locator("#price-spruce-log")).toHaveValue("17");
  await expect(page.locator("#profit-value")).toHaveText("$1,330.00");
});
test("quota failure keeps the calculator usable and data exportable", async ({
  page,
}) => {
  await page.addInitScript(() => {
    Storage.prototype.setItem = function () {
      const error = new Error("Full");
      error.name = "QuotaExceededError";
      throw error;
    };
  });
  await page.reload();
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  await expect(page.locator("#profit-value")).toHaveText("$86,400.00");
  await expect(page.locator("#notice")).toContainText("Device storage is full");
  await openSection(page, "Price Book");
  await expect(page.locator("#storage-size")).toContainText("quota");
  await openSection(page, "Trade History");
  const pending = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export JSON", exact: true }).click();
  const download = await pending;
  const backup = JSON.parse(await fs.readFile(await download.path(), "utf8"));
  expect(backup.inputs.chests.amount).toBe("1728");
});
