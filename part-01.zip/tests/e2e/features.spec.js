import {
  test,
  expect,
  openSection,
  AxeBuilder,
} from "../../tools/test-exports.js";
const errors = new WeakMap();
test.beforeEach(async ({ page }) => {
  errors.set(page, []);
  page.on("pageerror", (error) => errors.get(page).push(error.message));
  await page.goto("/");
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
});
test.afterEach(async ({ page }) => expect(errors.get(page)).toEqual([]));
test("inventory, history edits and actual sales persist with delete undo", async ({
  page,
  context,
}) => {
  await page.locator("#inventory-mode").check();
  await page.locator("#owned-spruce-log").fill("100");
  await expect(page.locator("#profit-value")).toHaveText("$96,400.00");
  await page
    .getByRole("button", { name: "Save this trade", exact: true })
    .click();
  await openSection(page, "history");
  await page.getByRole("button", { name: "Edit Chests", exact: true }).click();
  await page.locator("#edit-notes").fill("Sold at spawn");
  await page.locator("#edit-tags").fill("daily, spruce");
  await page.locator("#edit-actual").fill("350");
  await page.getByRole("button", { name: "Save history changes" }).click();
  await expect(page.locator("#history-page")).toContainText("Sold at spawn");
  await expect(page.locator("#history-page")).toContainText("$139,600.00");
  await page
    .getByRole("button", { name: "Delete Chests", exact: true })
    .click();
  await expect(page.locator("#history-page")).toContainText(
    "No trades saved yet",
  );
  await page.getByRole("button", { name: "Undo last history change" }).click();
  await expect(page.locator("#history-page")).toContainText("Sold at spawn");
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller)
      await new Promise((resolve) =>
        navigator.serviceWorker.addEventListener("controllerchange", resolve, {
          once: true,
        }),
      );
  });
  await context.setOffline(true);
  await page.reload();
  await openSection(page, "history");
  await expect(page.locator("#history-page")).toContainText("daily, spruce");
  await page.getByRole("button", { name: "Edit Chests", exact: true }).click();
  const audit = await new AxeBuilder({ page }).analyze();
  expect(audit.violations).toEqual([]);
});
test("bulk price preview, snapshot diff and restore require approval", async ({
  page,
}) => {
  await openSection(page, "prices");
  await page.getByText("Named price snapshots", { exact: true }).click();
  await page.locator("#snapshot-name").fill("Before run");
  await page.getByRole("button", { name: "Save price snapshot" }).click();
  await page.getByText("Bulk price paste", { exact: true }).click();
  await page.locator("#bulk-prices").fill("Spruce logs 200\nunknown 10");
  await page.getByRole("button", { name: "Preview pasted prices" }).click();
  await expect(
    page.getByRole("button", { name: "Apply pasted prices" }),
  ).toBeDisabled();
  await page
    .locator("#bulk-prices")
    .fill("item,price,unit\nSpruce logs,200,1\nsell:Chests,400,1");
  await page.getByRole("button", { name: "Preview pasted prices" }).click();
  await expect(page.locator("#book-spruce-log")).toHaveValue("100");
  await page.getByRole("button", { name: "Apply pasted prices" }).click();
  await page.getByText("Named price snapshots", { exact: true }).click();
  await expect(page.locator("#snapshot-diff")).toContainText("100%");
  await page
    .getByRole("button", { name: "Preview restore Before run" })
    .click();
  await expect(page.locator("#book-spruce-log")).toHaveValue("200");
  await page
    .getByRole("button", { name: "Apply price book", exact: true })
    .click();
  await expect(page.locator("#book-spruce-log")).toHaveValue("100");
  await page.getByText("Bulk price paste", { exact: true }).click();
  await page.locator("#bulk-prices").fill("bone 10");
  await page.getByRole("button", { name: "Preview pasted prices" }).click();
  const audit = await new AxeBuilder({ page }).analyze();
  expect(audit.violations).toEqual([]);
});
test("hourly rankings, capital filters, comparison and checklist", async ({
  page,
}) => {
  await page
    .getByText("Selling fees & profit per hour", { exact: true })
    .click();
  await page.locator("#throughput").fill("1k");
  await openSection(page, "leaderboard");
  await page.locator("#rank-sort").selectOption("profitHour");
  await expect(page.locator("#ranking")).toContainText("$100,000.00");
  await page
    .getByRole("button", { name: "Favorite Chests", exact: true })
    .click();
  await page.locator("#rank-view").selectOption("favorites");
  await expect(page.locator("#ranking")).toContainText("1 ranked");
  await page.locator("#maximum-capital").fill("1");
  await expect(page.locator("#ranking")).toContainText(
    "No complete saved prices",
  );
  await page.locator("#maximum-capital").fill("");
  await openSection(page, "compare");
  await page.locator("#compare-throughput-B").fill("2k");
  await page.locator("#compare-rank").selectOption("profitHour");
  await expect(page.locator("#comparison-winner")).toContainText("Scenario B");
  await page.locator("#compare-rank").selectOption("returnPercent");
  await expect(page.locator("#comparison-winner")).toContainText("tie");
  await openSection(page, "calculator");
  await page.getByRole("button", { name: "Add to plan", exact: true }).click();
  await expect(page.locator("#plans-page")).toBeVisible();
  await page.locator("#shopping-spruce-log").check();
  await page.getByRole("button", { name: "Save plan", exact: true }).click();
  await page.getByRole("button", { name: "Copy as Discord text" }).click();
  await expect(page.locator("#notice")).toContainText("Shopping list copied");
  await page.emulateMedia({ media: "print" });
  await expect(page.locator("header")).not.toBeVisible();
  await expect(page.locator(".plan-checklist")).toBeVisible();
  await page.emulateMedia({ media: "screen" });
  await page.reload();
  await openSection(page, "plans");
  await page
    .getByRole("button", { name: "My crafting plan", exact: true })
    .click();
  await expect(page.locator("#shopping-spruce-log")).toBeChecked();
  const audit = await new AxeBuilder({ page }).analyze();
  expect(audit.violations).toEqual([]);
});
test("cheapest chain selects rounded purchase versus craft route", async ({
  page,
}, info) => {
  if (info.project.name === "mobile")
    await page.locator("#mode-picker").selectOption("slabs");
  else
    await page
      .getByRole("button", { name: "Spruce Slabs", exact: true })
      .click();
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  await page.locator("#quantity").fill("6");
  await openSection(page, "chains");
  await page
    .getByRole("button", { name: "Cheapest route", exact: true })
    .click();
  await page.locator("#chain-price-spruce-plank").fill("40");
  await page.locator("#chain-price-spruce-log").fill("100");
  await expect(page.locator("#chain-result")).toContainText(
    "Craft cost $100.00",
  );
  await page.locator("#chain-price-spruce-plank").fill("10");
  await expect(page.locator("#chain-result")).toContainText(
    "Spruce planks · Buy",
  );
});
