import { test, expect, openSection } from "../../tools/test-exports.js";
test("dismissed welcome stays compact and search survives a recipe change", async ({
  page,
}, info) => {
  await page.goto("/");
  await page.getByRole("button", { name: "Dismiss welcome" }).click();
  await expect(page.locator("html")).toHaveAttribute("data-welcomed", "true");
  if (info.project.name === "desktop") {
    const top = await page
      .getByRole("heading", { name: "Your trade", exact: true })
      .boundingBox();
    expect(top.y).toBeLessThan(700);
    await page.locator("#recipe-search").fill("spruce");
    await page
      .getByRole("button", { name: "Spruce Slabs", exact: true })
      .click();
    await expect(page.locator("#recipe-search")).toHaveValue("spruce");
    await expect(page.locator("#quantity")).toBeFocused();
  }
  await page.reload();
  await expect(page.locator("#welcome-card")).not.toBeVisible();
  await expect(page.locator("html")).toHaveAttribute("data-welcomed", "true");
});
test("mobile More menu supports keyboard and closes after routing", async ({
  page,
}, info) => {
  await page.goto("/");
  if (info.project.name !== "mobile") {
    await expect(page.locator("#more-button")).not.toBeVisible();
    return;
  }
  await expect(page.locator("#more-button")).toBeVisible();
  await expect(page.locator("#tab-history")).not.toBeVisible();
  await page.locator("#more-button").click();
  await expect(
    page.getByRole("menuitem", { name: "Trade History" }),
  ).toBeFocused();
  await page.keyboard.press("ArrowDown");
  await expect(
    page.getByRole("menuitem", { name: "Crafting Chains" }),
  ).toBeFocused();
  await page.keyboard.press("Escape");
  await expect(page.locator("#more-menu")).not.toBeVisible();
  await expect(page.locator("#more-button")).toBeFocused();
  await openSection(page, "plans");
  await expect(page.locator("#plans-page")).toBeVisible();
  await expect(page.locator("#more-menu")).not.toBeVisible();
  await expect(page.locator("#more-button")).toContainText("Plans");
});
