import {
  test,
  expect,
  AxeBuilder,
  openSection,
} from "../../tools/test-exports.js";
import { encodePayload } from "../../src/core.js";
import fs from "node:fs/promises";
const example = async (page) => {
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  await expect(page.locator("#profit-value")).toHaveText("$86,400.00");
};
const selectRecipe = async (page, id, name) => {
  const select = page.locator("#mode-picker");
  if (await select.isVisible()) await select.selectOption(id);
  else await page.getByRole("button", { name, exact: true }).click();
};
test.beforeEach(async ({ page }) => {
  await page.goto("/");
  await expect(page.locator("#trade-form")).not.toBeEmpty();
});
test("calculate, switch recipes, save history, shortcuts, and keyboard tabs", async ({
  page,
}) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  await example(page);
  await page
    .getByRole("button", { name: "Save this trade", exact: true })
    .click();
  await openSection(page, "Trade History");
  await expect(page.locator("#history-page")).toContainText("86,400");
  await openSection(page, "Calculator");
  await selectRecipe(page, "smelting", "Glass");
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  await expect(page.locator("#profit-value")).toHaveText("$8,500.00");
  await page.locator("#quantity").fill("9");
  await expect(page.locator("#profit-value")).toHaveText("$350.00");
  await page.locator("#tab-calculator").focus();
  await page.keyboard.press("ArrowRight");
  await expect(page.locator("#tab-leaderboard")).toBeFocused();
  await expect(page.locator("#leaderboard-page")).toBeVisible();
  await page.keyboard.press("/");
  await expect(page.locator("#quantity")).toBeFocused();
  await page.locator("#tab-calculator").focus();
  await page.keyboard.press("?");
  await expect(page.locator("#help-dialog")).toBeVisible();
  await page.keyboard.press("Escape");
  await expect(page.locator("#help-dialog")).not.toBeVisible();
  await page.getByText("Explore price sensitivity", { exact: true }).click();
  const chart = page.locator("#sensitivity .chart").first();
  await chart.locator("circle[role=button]").first().focus();
  await page.keyboard.press("ArrowRight");
  await expect(chart.locator("circle[role=button]").nth(1)).toBeFocused();
  await expect(chart.locator(".chart-tooltip")).toContainText("·");
  expect(errors).toEqual([]);
});
test("export and preview full-state import", async ({ page }) => {
  await example(page);
  await page
    .getByRole("button", { name: "Save this trade", exact: true })
    .click();
  await openSection(page, "Trade History");
  const pending = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export JSON", exact: true }).click();
  const file = await pending;
  const exported = JSON.parse(await fs.readFile(await file.path(), "utf8"));
  expect(exported.version).toBe(4);
  expect(exported.history).toHaveLength(1);
  await page.locator("#import-data").setInputFiles({
    name: "trades.json",
    mimeType: "application/json",
    buffer: Buffer.from(JSON.stringify(exported)),
  });
  await expect(page.locator("#import-preview")).toContainText("1 trades");
  await page
    .getByRole("button", { name: "Replace with imported data" })
    .click();
  await expect(page.locator("#history-page")).toContainText("86,400");
});
test("theme and compact display persist", async ({ page }) => {
  await page.locator("#theme-toggle").click();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  await page.reload();
  await expect(page.locator("html")).toHaveAttribute("data-theme", "light");
  await openSection(page, "Price Book");
  await page.locator("#compact-money").selectOption("compact");
  await openSection(page, "Calculator");
  await exampleCompact(page);
  await page.reload();
  await expect(page.locator("#profit-value")).toHaveText("$86.4k");
});
async function exampleCompact(page) {
  await page
    .getByRole("button", { name: "Try an example", exact: true })
    .click();
  await expect(page.locator("#profit-value")).toHaveText("$86.4k");
}
test("offline reload caches image assets and calculators", async ({
  page,
  context,
}) => {
  await example(page);
  await page.evaluate(async () => {
    await navigator.serviceWorker.ready;
    if (!navigator.serviceWorker.controller)
      await new Promise((resolve) =>
        navigator.serviceWorker.addEventListener("controllerchange", resolve, {
          once: true,
        }),
      );
  });
  await context.setOffline(true);
  await page.reload();
  await expect(page.locator("#profit-value")).toHaveText("$86,400.00");
  const response = await page.evaluate(async () => ({
    ok: (await fetch("./images/icon-192.png")).ok,
    bannerCached: Boolean(
      await caches.match(
        new URL("./images/social-banner.png", location.href).href,
      ),
    ),
  }));
  expect(response).toEqual({ ok: true, bannerCached: false });
});
test("examples, price history, bulk plans, and plan share previews", async ({
  page,
}) => {
  await openSection(page, "Price Book");
  await page
    .getByRole("button", { name: "Load example prices", exact: true })
    .click();
  await expect(page.locator("#prices-page")).toContainText("placeholders");
  await page.locator("#book-bone").fill("150");
  await page.locator("#book-bone").fill("180");
  await openSection(page, "Plans");
  await page
    .getByLabel("Total material budget ($)", { exact: true })
    .fill("100k");
  await page.getByRole("button", { name: "Suggest budget plan" }).click();
  await expect(page.locator("#plans-page")).toContainText(
    "Combined profit after fees",
  );
  await page.getByRole("button", { name: "Save plan", exact: true }).click();
  await expect(page.locator("#notice")).toContainText("Plan saved.");
  const download = page.waitForEvent("download");
  await page.getByRole("button", { name: "Export plan JSON" }).click();
  const file = await download;
  const payload = JSON.parse(await fs.readFile(await file.path(), "utf8"));
  expect(payload.plan.items.length).toBeGreaterThan(0);
  const encoded = await encodePayload(payload);
  await page.goto("/#data=" + encoded);
  await expect(page.locator("#plans-page")).toContainText(
    "Preview shared plan",
  );
  await page.getByRole("button", { name: "Use this plan" }).click();
  await expect(page.locator("#plans-page")).toContainText("Combined revenue");
});
test("price book import requires preview approval", async ({ page }) => {
  const p = {
    version: 3,
    type: "book",
    prices: { bone: { value: "321", unit: "1", updated: "2026-10-01" } },
    sells: {},
  };
  const encoded = await encodePayload(p);
  await page.goto("/#data=" + encoded);
  await expect(page.locator("#prices-page")).toContainText(
    "Preview price book changes",
  );
  await expect(page.locator("#book-bone")).toHaveValue("");
  await page.getByRole("button", { name: "Apply price book" }).click();
  await expect(page.locator("#book-bone")).toHaveValue("321");
});
test("CSP, accessibility in both themes, and responsive screenshots", async ({
  page,
}, info) => {
  const csp = [];
  page.on("console", (msg) => {
    if (
      msg.type() === "error" &&
      /Content Security Policy|Refused to/i.test(msg.text())
    )
      csp.push(msg.text());
  });
  await setTheme(page, "dark");
  await example(page);
  await fs.mkdir("tests/screenshots", { recursive: true });
  await page.screenshot({
    path: "tests/screenshots/" + info.project.name + "-calculator-dark.png",
    fullPage: true,
  });
  for (const theme of ["dark", "light"]) {
    await setTheme(page, theme);
    for (const id of [
      "calculator",
      "leaderboard",
      "prices",
      "history",
      "chains",
      "compare",
      "plans",
    ]) {
      await openSection(page, id);
      const scan = await new AxeBuilder({ page }).analyze();
      expect(scan.violations, theme + "/" + id).toEqual([]);
      expect(
        await page.evaluate(
          () => document.documentElement.scrollWidth <= innerWidth,
        ),
        theme + "/" + id + " fits viewport",
      ).toBeTruthy();
    }
  }
  await openSection(page, "calculator");
  await page.screenshot({
    path: "tests/screenshots/" + info.project.name + "-calculator-light.png",
    fullPage: true,
  });
  expect(csp).toEqual([]);
});

async function setTheme(page, theme) {
  for (let n = 0; n < 3; n++) {
    if (
      (await page.locator("#theme-toggle").textContent()) ===
      "Theme: " + theme
    )
      return;
    await page.locator("#theme-toggle").click();
  }
}
