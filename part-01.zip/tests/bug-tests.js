import {
  calculate,
  normalizePrices,
  resolveRecipe,
  allRecipes,
  combineTrades,
  chainCostHook,
  editPrice,
  priceChange,
} from "../src/core.js";
import {
  defaultState,
  sanitizeState,
  createStorage,
  STORAGE_KEY,
} from "../src/state.js";
export function bugTests() {
  let count = 0;
  const check = (ok, msg) => {
    if (!ok) throw Error(msg);
    count++;
  };
  const state = defaultState();
  state.prices.bone = {
    value: "100",
    unit: "1",
    updated: "2026-10-01T00:00:00Z",
  };
  for (const [index, value] of ["2", "2.", "2.5", "2.5k"].entries())
    editPrice(
      state,
      "prices",
      "bone",
      value,
      "1",
      new Date(Date.parse("2026-10-04T00:00:00Z") + index * 200).toISOString(),
    );
  check(
    state.prices.bone.history.length === 2 &&
      state.prices.bone.history[1].value === "2.5k",
    "Coalesce price keystrokes into one final edit",
  );
  check(
    priceChange(state.prices.bone) === 2400,
    "Change badge uses preceding committed price",
  );
  editPrice(state, "prices", "bone", "3000", "1", "2026-10-04T00:00:10Z");
  check(
    state.prices.bone.history.length === 3,
    "A later edit is a separate change",
  );
  const persisted = new Map([
      [
        "donut-profit-v2",
        JSON.stringify({
          version: 2,
          prices: { bone: { value: "123", unit: "1" } },
          history: [],
        }),
      ],
    ]),
    local = {
      getItem: (key) => persisted.get(key) || null,
      setItem: (key, v) => persisted.set(key, v),
      removeItem: (key) => persisted.delete(key),
    };
  const storage = createStorage(local),
    migrated = storage.load();
  check(
    migrated.version === 4 && migrated.prices.bone.value === "123",
    "Legacy key/version migration",
  );
  storage.save(migrated);
  check(
    persisted.has(STORAGE_KEY) && STORAGE_KEY === "donut-profit-v4",
    "Write versioned storage key",
  );
  check(
    sanitizeState({
      version: 3,
      prices: { bone: { value: "100", unit: "1" } },
      history: [],
    }).version === 4,
    "Version 3 migration",
  );
  const quota = createStorage({
    getItem: () => null,
    setItem() {
      const e = Error("Full");
      e.name = "QuotaExceededError";
      throw e;
    },
  });
  check(
    !quota.save(defaultState()) && quota.load().version === 4,
    "Quota failure retains in-tab data",
  );
  const decimal = calculate(
    resolveRecipe("chests"),
    { amount: "6", sell: "0.3" },
    { "spruce-log": 0.1 },
  );
  check(
    decimal.cost === 0.6 && decimal.revenue === 0.9 && decimal.profit === 0.3,
    "Proven binary-floating cancellation bug is fixed",
  );
  const combined = combineTrades(
    Array.from({ length: 3 }, () => ({ result: decimal })),
  );
  check(
    combined.profit === 0.9 && combined.cost === 1.8,
    "Exact combined totals avoid repeated decimal cancellation",
  );
  const chained = calculate(
    resolveRecipe("books", "buy"),
    { amount: "1", sell: "1" },
    { book: 0, feather: 0.1, "ink-sac": 0.1 },
    chainCostHook(
      { paper: "0.1", leather: "0.1", feather: "0.1", "ink-sac": "0.1" },
      { book: "craft" },
    ),
  );
  check(
    chained.cost === 0.6 && chained.profit === 0.4,
    "Chain totals use exact leaf prices",
  );
  const high = calculate(
    resolveRecipe("chests"),
    {
      amount: "2",
      sell: "50000000000000",
      fees: { enabled: true, percent: "99.99" },
    },
    { "spruce-log": 1e13 },
  );
  check(
    high.breakEven === 2e17,
    "Derived break-even retains exact percent without a total limit",
  );
  let seed = 1945;
  const random = (max) => {
      seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0;
      return seed % max;
    },
    items = allRecipes();
  const parseFraction = (s) => {
    const [n, d = "1"] = s.split("/");
    return [BigInt(n), BigInt(d)];
  };
  for (let n = 0; n < 800; n++) {
    const recipe = items[random(items.length)],
      amount = random(10000),
      saleCents = random(100000),
      sellUnit = recipe.stackable ? [1, 64, 1728][random(3)] : 1,
      entries = {};
    let materialNumerator = 0n;
    const crafted =
        recipe.specialRules === "materialOrder"
          ? Math.floor(amount / recipe.ingredients[0].count)
          : Math.ceil(amount / recipe.outputCount) * recipe.outputCount,
      batches = crafted / recipe.outputCount;
    for (const ingredient of recipe.ingredients) {
      const cents = random(100000),
        unit = [1, 64, 1728][random(3)];
      entries[ingredient.id] = {
        value: String(cents / 100),
        unit: String(unit),
      };
      const quantity =
        recipe.specialRules === "materialOrder"
          ? amount
          : recipe.specialRules === "wholeFuel"
            ? Math.ceil(batches * ingredient.count)
            : batches * ingredient.count;
      materialNumerator +=
        BigInt(cents) * BigInt(quantity) * BigInt(1728 / unit);
    }
    const basisPoints = random(5000),
      flatCents = random(500),
      listings = random(5);
    const result = calculate(
      recipe,
      {
        amount: String(amount),
        sell: String(saleCents / 100),
        sellUnit: String(sellUnit),
        fees: {
          enabled: true,
          percent: String(basisPoints / 100),
          flat: String(flatCents / 100),
          listings: String(listings),
        },
      },
      normalizePrices(recipe, entries),
    );
    const revenueNumerator =
        BigInt(saleCents) * BigInt(crafted) * BigInt(1728 / sellUnit),
      feeNumerator =
        revenueNumerator * BigInt(basisPoints) +
        BigInt(flatCents) * BigInt(listings) * 1728n * 10000n,
      profitNumerator =
        (revenueNumerator - materialNumerator) * 10000n - feeNumerator;
    for (const [key, numerator, denominator] of [
      ["cost", materialNumerator, 172800n],
      ["revenue", revenueNumerator, 172800n],
      ["feeCost", feeNumerator, 1728000000n],
      ["profit", profitNumerator, 1728000000n],
    ]) {
      const [actualN, actualD] = parseFraction(result.exact[key]);
      check(
        actualN * denominator === numerator * actualD,
        "BigInt reference " + key + " case " + n,
      );
    }
  }
  return count;
}
