import { bugTests } from "./bug-tests.js";
import { phase3Tests } from "./tests-phase3.js";
import { parseAmount, validateAmount } from "../src/core.js";
import { recipes, resolveRecipe, allRecipes } from "../src/core.js";
import { calculate, productionCost, targetPrice } from "../src/core.js";
import { chainCostHook } from "../src/core.js";
import { createStorage, sanitizeState, defaultState } from "../src/state.js";
import { featureTests } from "./feature-tests.js";
import {
  loadExamples,
  clearExamples,
  hasExamples,
  updatePrice,
  missingPrices,
} from "../src/core.js";

export async function runTests() {
  let passed = 0;
  function assert(condition, message) {
    if (!condition) throw new Error(message);
    passed++;
  }
  const baseline =
    typeof global !== "undefined"
      ? JSON.parse(
          await (
            await import("node:fs/promises")
          ).readFile(new URL("./baseline.json", import.meta.url), "utf8"),
        )
      : await (await fetch("./baseline.json")).json();
  for (const c of baseline) {
    const recipe = resolveRecipe(c.id, c.variant);
    const prices =
      c.prices ||
      Object.fromEntries(
        recipe.ingredients.map((i, index) => [i.id, c.legacyPrices[index]]),
      );
    const r = calculate(
      recipe,
      {
        amount: String(c.amount),
        orderMode: c.budget ? "budget" : "quantity",
        sell: String(c.sell),
      },
      prices,
    );
    for (const key of Object.keys(c.expected))
      assert(
        r[key] === c.expected[key],
        `${c.id}/${c.variant || ""} amount ${c.amount} budget ${c.budget}: ${key}: ${r[key]} vs ${c.expected[key]}`,
      );
  }
  for (const [raw, expected] of [
    ["100k", 100000],
    ["2.5m", 2500000],
    ["1b", 1e9],
    ["1.001k", 1001],
    [".5M", 500000],
    [" 2 K ", 2000],
    ["1,000.5k", 1000500],
  ])
    assert(parseAmount(raw) === expected, "Parser " + raw);
  for (const raw of ["", "k", "1kk", "1km", "Infinity", "1e3", "1,2k", "0x10"])
    assert(Number.isNaN(parseAmount(raw)), "Reject " + raw);
  assert(validateAmount("-1").includes("Negative"), "Negative message");
  assert(
    validateAmount("1.5", { whole: true }).includes("whole"),
    "Fractional message",
  );
  for (const r of allRecipes())
    assert(r.ingredients.length > 0 && r.outputCount > 0, "Schema " + r.name);
  const glass = resolveRecipe("smelting");
  for (const sand of [0, 1, 10])
    for (const coal of [0, 1, 40])
      for (let amount = 0; amount < 200; amount += 7) {
        if (sand + coal === 0) continue;
        const r = calculate(
          glass,
          { amount: String(amount), orderMode: "budget", sell: "20" },
          { sand, charcoal: coal },
        );
        const cost = (n) => n * sand + Math.ceil(n / 8) * coal;
        assert(
          cost(r.crafted) <= amount && cost(r.crafted + 1) > amount,
          "Whole fuel budget is maximal",
        );
      }
  assert(
    productionCost(glass, 9, { sand: 100, charcoal: 500 }).cost === 1900,
    "Partial fuel batch",
  );
  const slab = calculate(
    resolveRecipe("slabs"),
    { amount: "1", sell: "100" },
    { "spruce-plank": 100 },
  );
  assert(slab.crafted === 6 && slab.cost === 300, "Batch rounds to six");
  let rejected = false;
  try {
    calculate(slab, { amount: "1b", sell: "1b" }, {});
  } catch {
    rejected = true;
  }
  assert(rejected, "Large invalid values guarded");
  const throwing = {
    getItem() {
      throw Error();
    },
    setItem() {
      throw Error();
    },
  };
  const storage = createStorage(throwing);
  const memory = storage.load();
  memory.mode = "walls";
  storage.save(memory);
  assert(storage.load().mode === "walls", "Storage fallback");
  assert(sanitizeState(defaultState()).version === 4, "Storage validation");
  const fees = calculate(
    resolveRecipe("chests"),
    {
      amount: "10",
      sell: "300",
      fees: { enabled: true, percent: "10", flat: "5", listings: "2" },
    },
    { "spruce-log": 100 },
  );
  assert(
    fees.profitBeforeFees === 500 &&
      fees.feeCost === 160 &&
      fees.profit === 340,
    "Fees applied to revenue and listings",
  );
  assert(Math.abs(fees.breakEven - 1010 / 4.5) < 1e-10, "Fee-aware break-even");
  assert(
    Math.abs(targetPrice(fees, 25) - 1260 / 4.5) < 1e-10,
    "Target return includes fees",
  );
  const logChain = calculate(
    resolveRecipe("slabs"),
    { amount: "6", sell: "100" },
    { "spruce-plank": 0 },
    chainCostHook(
      { "spruce-log": { value: "100", unit: "1" } },
      { "spruce-plank": "craft" },
    ),
  );
  assert(
    logChain.cost === 100 &&
      logChain.profit === 500 &&
      logChain.steps[0].leftover === 1,
    "Logs to planks to slabs",
  );
  const crystalChain = calculate(
    resolveRecipe("crystals"),
    { amount: "1", sell: "5k" },
    { glass: 0, "ender-eye": 1000, "ghast-tear": 2000 },
    chainCostHook(
      { sand: "100", charcoal: "500", "ender-eye": "1k", "ghast-tear": "2k" },
      { glass: "craft" },
    ),
  );
  assert(
    crystalChain.cost === 4200 &&
      crystalChain.rows.find((r) => r.id === "charcoal").quantity === 1,
    "Sand to glass to crystals",
  );
  const bookChain = calculate(
    resolveRecipe("books", "buy"),
    { amount: "1", sell: "250" },
    { book: 0, feather: 20, "ink-sac": 30 },
    chainCostHook(
      { paper: "10", leather: "50", feather: "20", "ink-sac": "30" },
      { book: "craft" },
    ),
  );
  assert(
    bookChain.cost === 130 && bookChain.profit === 120,
    "Craft books into book and quill",
  );
  const chainBudget = calculate(
    resolveRecipe("slabs"),
    { amount: "100", sell: "100", orderMode: "budget" },
    { "spruce-plank": 0 },
    chainCostHook({ "spruce-log": "100" }, { "spruce-plank": "craft" }),
  );
  assert(
    chainBudget.crafted === 6 && chainBudget.cost === 100,
    "Chain budget honors whole log purchases",
  );
  const roundTrip = sanitizeState(JSON.parse(JSON.stringify(defaultState())));
  assert(roundTrip.chains && roundTrip.prices, "Persistence export/import");
  const examples = defaultState();
  examples.prices.diamond = { value: "999", unit: "1" };
  loadExamples(examples);
  assert(
    examples.prices.diamond.value === "999",
    "Examples preserve user prices",
  );
  assert(
    hasExamples(examples) && examples.sells["chests:"].example,
    "Example sale flags",
  );
  updatePrice(examples, "prices", "bone", "123");
  clearExamples(examples);
  assert(
    examples.prices.bone.value === "123" && !hasExamples(examples),
    "Clear only example records",
  );
  assert(
    missingPrices(resolveRecipe("crystals"), defaultState()).length === 4,
    "Missing fields identify ingredients and selling price",
  );
  passed += await phase3Tests();
  passed += bugTests();
  passed += featureTests();
  return { passed, baselineCases: baseline.length, modeCount: recipes.length };
}
if (typeof global !== "undefined") console.log(await runTests());
