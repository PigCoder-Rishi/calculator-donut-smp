# Upgrade verification

All five required suites ran before and after each numbered step, sequentially. Failures discovered during development were fixed and the full post-step suites rerun. Calculation outputs retain all 88 original baseline cases; new BigInt tests prove and cover decimal-cancellation fixes.

| Step               | Before          | After           | Calculation checks after |                       Browser tests after | Lighthouse after (performance/accessibility/best practices/SEO) |
| ------------------ | --------------- | --------------- | -----------------------: | ----------------------------------------: | --------------------------------------------------------------- |
| 1. Structure/build | All five passed | All five passed |                      743 |                                        14 | 99/100/100/100                                                  |
| 2. Bugs            | All five passed | All five passed |                    3,954 |                                        22 | 99/100/100/100                                                  |
| 3. UX              | All five passed | All five passed |                    3,954 | 25 + one desktop-inapplicable mobile test | 96/100/100/100                                                  |
| 4. Trading tools   | All five passed | All five passed |                    5,885 |                              34, no skips | 99/100/100/100                                                  |
| 5. CI/docs         | All five passed | All five passed |                    5,885 |                              34, no skips | 99/100/100/100                                                  |

Every post-step UI run passed 22 simulated checks. Original offline tests inspected 51 individual source assets; the bundled production app now has 26 offline assertions. Real Playwright offline reload is also covered, including images and saved history. The original desktop skip was replaced with a desktop assertion that More is hidden; no final browser tests are skipped.

Reports: `reports/step1-before.json` through `reports/step5-after.json`, `reports/lighthouse.html`, `reports/lighthouse.json`, `reports/quality.json`, `reports/build.json`, and `reports/playwright/`. Reports/screenshots/traces are generated locally and uploaded by CI rather than committed.

ESLint rejects undefined identifiers, unused variables/imports and unsafe patterns covered by its recommended rules. Prettier covers source/tools/tests/data/public/configuration. All axe violations fail the final desktop/mobile and light/dark audits; editor, bulk-preview and checklist states have additional checks. Lighthouse uses the raw score threshold of 0.90, not a rounded display score. Current Lighthouse has no PWA category, so manifest, worker control and offline assertions are separate.

Self-assessment: **930/1000**, with the per-area rubric in `README.md`. This is an engineering assessment supported by local checks, not an independent product review.

No requested implementation skipped. Checks not performed: hosted GitHub Actions, Vercel production deployment/audit, Firefox/Safari, manual screen-reader QA, OS-level PWA installation. Chains optimize existing supported intermediates using whole market-price batches, not mixed buy/craft allocations or leftover sales. Inventory counts purchase cost only. No external publication/deployment was made.

Final additional gates passed: ESLint, Prettier, and size checks. Initial JS: 22,435 bytes gzipped; all production images: 29,577 bytes; social banner: 17,947 bytes. A deep comparison against the original baseline commit confirms identical baseline values (formatting changed only). Strict CSP remains unchanged.
