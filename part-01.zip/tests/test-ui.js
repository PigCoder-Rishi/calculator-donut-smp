// A dependency-free DOM smoke test. It checks wiring, not browser layout.
import { fileURLToPath } from "node:url";
class Element {
  constructor(tag = "div") {
    this.tagName = tag.toUpperCase();
    this.children = [];
    this.attributes = {};
    this.listeners = {};
    this.dataset = {};
    this.style = {};
    this.value = "";
    this._text = "";
    this.hidden = false;
    this.checked = false;
    this.classList = {
      add: (...names) => names.forEach((n) => this.classes.add(n)),
      toggle: (n, on) => {
        if (on === undefined) on = !this.classes.has(n);
        on ? this.classes.add(n) : this.classes.delete(n);
      },
      remove: (n) => this.classes.delete(n),
    };
    this.classes = new Set();
  }
  set id(value) {
    this.attributes.id = value;
  }
  get id() {
    return this.attributes.id;
  }
  set textContent(value) {
    this._text = String(value ?? "");
    this.children = [];
  }
  get textContent() {
    return this._text + this.children.map((c) => c.textContent).join("");
  }
  setAttribute(k, v) {
    this.attributes[k] = String(v);
    if (k === "class") this.classes = new Set(String(v).split(" "));
  }
  getAttribute(k) {
    return this.attributes[k];
  }
  append(...children) {
    for (const child of children) {
      const c = child instanceof Element ? child : new Element("text");
      if (c !== child) c.textContent = child;
      c.parent = this;
      this.children.push(c);
    }
  }
  prepend(...children) {
    for (const c of children.reverse()) {
      c.parent = this;
      this.children.unshift(c);
    }
  }
  replaceChildren(...children) {
    this.children = [];
    this._text = "";
    this.append(...children);
  }
  addEventListener(type, fn) {
    (this.listeners[type] ||= []).push(fn);
  }
  async fire(type) {
    for (const fn of this.listeners[type] || [])
      await fn({ target: this, preventDefault() {} });
  }
  click() {
    return this.fire("click");
  }
  focus() {
    document.activeElement = this;
  }
  select() {}
  remove() {
    if (this.parent)
      this.parent.children = this.parent.children.filter((c) => c !== this);
  }
  querySelector(selector) {
    return this.querySelectorAll(selector)[0] || null;
  }
  querySelectorAll(selector) {
    const result = [];
    const matches = (e) =>
      selector.startsWith("#")
        ? e.id === selector.slice(1)
        : selector.startsWith(".")
          ? e.classes.has(selector.slice(1))
          : e.tagName.toLowerCase() === selector;
    function visit(e) {
      for (const c of e.children) {
        if (matches(c)) result.push(c);
        visit(c);
      }
    }
    visit(this);
    return result;
  }
  closest(selector) {
    if (selector[0] === "." && this.classes.has(selector.slice(1))) return this;
    return this.parent?.closest(selector) || null;
  }
  get isConnected() {
    return true;
  }
  showModal() {
    this.open = true;
  }
  close() {
    this.open = false;
  }
}
const body = new Element("body"),
  root = new Element("html");
root.append(body);
const doc = {
  body,
  documentElement: root,
  activeElement: null,
  listeners: {},
  createElement: (tag) => new Element(tag),
  createElementNS: (_, tag) => new Element(tag),
  createTextNode: (text) => {
    const n = new Element("text");
    n.textContent = text;
    return n;
  },
  getElementById: (id) => root.querySelector("#" + id),
  querySelector: (s) => root.querySelector(s),
  addEventListener(type, fn) {
    (this.listeners[type] ||= []).push(fn);
  },
  dispatchEvent(event) {
    for (const fn of this.listeners[event.type] || []) fn(event);
  },
};
for (const id of [
  "header-actions",
  "tabs",
  "mobile-more-mount",
  "notice",
  "recipe-picker",
  "trade-form",
  "result",
  "sensitivity",
  "profit-announcement",
  ...[
    "calculator",
    "leaderboard",
    "prices",
    "history",
    "chains",
    "compare",
    "plans",
  ].map((p) => p + "-page"),
]) {
  const e = new Element("div");
  e.id = id;
  body.append(e);
}
const data = new Map();
const local = {
  getItem: (k) => data.get(k) || null,
  setItem: (k, v) => data.set(k, v),
};
global.document = doc;
global.Node = Element;
global.window = {
  localStorage: local,
  listeners: {},
  addEventListener(name, fn) {
    (this.listeners[name] ||= []).push(fn);
  },
};
global.location = {
  hash: "",
  href: "http://localhost:8080/",
  protocol: "http:",
};
global.matchMedia = () => ({ matches: true, addEventListener() {} });
global.requestAnimationFrame = (fn) =>
  setTimeout(() => fn(performance.now() + 1000), 0);
Object.defineProperty(global, "navigator", {
  value: { clipboard: { writeText: async () => {} } },
  configurable: true,
});
global.CustomEvent = class {
  constructor(type, options = {}) {
    this.type = type;
    this.detail = options.detail;
  }
};
let checks = 0;
const assert = (condition, message) => {
  if (!condition) throw Error(message);
  checks++;
};
const ui = await import("../src/ui.js"),
  features = await import("../src/ui.js");
const $ = (id) => doc.getElementById(id);
const { defaultState } = await import("../src/state.js");
ui.replaceState(defaultState());
$("tabs").replaceChildren();
$("header-actions").replaceChildren();
$("calculator-page").replaceChildren();
$("help-dialog")?.remove();
await features.initFeatures();
function buttons(parent) {
  return parent.querySelectorAll("button");
}
async function example() {
  await buttons($("trade-form"))
    .find((b) => b.textContent === "Try an example")
    .click();
}
const expectations = {
  chests: 86400,
  bones: 49850,
  books: 10000,
  diamonds: 5000,
  crystals: 130000,
  anchors: 250000,
  slabs: 5100,
  turtles: 250000,
  walls: 5100,
  smelting: 8500,
};
for (const [id, expected] of Object.entries(expectations)) {
  ui.state.mode = id;
  ui.renderForm();
  await example();
  assert(ui.getResult().profit === expected, "UI example " + id);
}
ui.state.mode = "books";
ui.input().variant = "craft";
ui.renderForm();
await example();
assert(ui.getResult().profit === 12000, "Craft-book UI");
for (const id of ["leaderboard", "prices", "history", "chains", "compare"]) {
  await features.showPage(id);
  assert($(id + "-page").children.length > 0, "Tab renders " + id);
}
await features.showPage("calculator");
ui.state.mode = "chests";
ui.renderForm();
await example();
await buttons($("calculator-page"))
  .find((b) => b.textContent === "Save this trade")
  .click();
assert(ui.state.history.length === 1, "Save trade");
await features.showPage("history");
assert($("history-page").textContent.includes("86,400"), "History total");
await features.showPage("compare");
assert($("comparison-winner").textContent.length > 0, "Comparison summary");
await features.showPage("prices");
const diamond = $("book-diamond");
diamond.value = "2.5k";
await diamond.fire("input");
assert(ui.state.prices.diamond.value === "2.5k", "Shared price edits");
await features.showPage("calculator");
ui.state.mode = "diamonds";
ui.renderForm();
assert($("price-diamond").value === "2.5k", "Shared price auto-fill");
const amount = $("quantity");
amount.value = "-1";
await amount.fire("input");
assert(
  $("quantity-error").textContent.includes("Negative"),
  "Inline negative error",
);
console.log({
  uiChecks: checks,
  recipes: Object.keys(expectations).length,
  limitations:
    "Simulated DOM: visual layout and browser APIs need a real browser.",
});
