import {
  notify,
  clipboard,
  node as node2,
  button as button2,
  download as download2,
  $ as $2,
  table as table2,
} from "./widgets.js";
import {
  recipes,
  resolveRecipe,
  calculate,
  normalizePrices,
  money,
  number,
  encodePayload,
  decodePayload,
  parseAmount as parseAmount2,
} from "./core.js";
import {
  sanitizeState,
  state,
  input,
  save,
  currentRecipe,
  hooks,
} from "./state.js";

var renderForm = (...args) => hooks.renderForm(...args);
function summary(recipe, result) {
  return `${recipe.product} \xB7 Donut SMP
Quantity: ${number(result.crafted)}
Cost: ${money(result.cost)}
Revenue: ${money(result.revenue)}
Profit before fees: ${money(result.profitBeforeFees)}
Fees: ${money(result.feeCost)}
Profit: ${money(result.profit)}
Return: ${result.returnPercent === null ? "N/A" : number(result.returnPercent) + "%"}
Break-even / item: ${money(result.breakEven)}`;
}
async function share() {
  return sharePayload({
    type: "trade",
    version: 4,
    mode: state.mode,
    input: structuredClone(input()),
    prices: Object.fromEntries(
      currentRecipe().ingredients.map((i) => [i.id, state.prices[i.id]]),
    ),
  });
}
async function restoreLink() {
  if (!location.hash.startsWith("#trade=")) return;
  try {
    if (location.hash.length > 64000) throw Error("Link is too large.");
    const old = JSON.parse(decodeURIComponent(location.hash.slice(7)));
    if (old.version !== 1) throw Error("Unknown trade version.");
    const payload = {
      type: "trade",
      version: 4,
      mode: old.mode,
      input: old.input,
      prices: old.prices,
    };
    const url = new URL(location.href);
    url.hash = "data=" + (await encodePayload(payload));
    window.history.replaceState(null, "", url);
    await previewTrade(payload);
  } catch (error) {
    notify("That shared trade link is invalid: " + error.message);
  }
}
async function previewTrade(payload) {
  if (
    !recipes.some((r) => r.id === payload.mode) ||
    !payload.input ||
    typeof payload.input !== "object" ||
    Array.isArray(payload.input)
  )
    throw Error("Invalid recipe or inputs.");
  const clean = sanitizeState({
    version: payload.version,
    mode: payload.mode,
    inputs: { [payload.mode]: payload.input },
    prices: payload.prices,
  });
  const data = clean.inputs[payload.mode],
    recipe = resolveRecipe(payload.mode, data.variant);
  const relevant = Object.fromEntries(
    recipe.ingredients
      .filter((i) => clean.prices[i.id])
      .map((i) => [i.id, clean.prices[i.id]]),
  );
  await hooks.showPage("calculator");
  const panel = node2("section", null, {
    class: "card import-preview",
    id: "trade-link-preview",
  });
  panel.append(
    node2("h2", "Preview shared trade"),
    node2(
      "p",
      "Review this trade before applying its quantities and prices. Your saved prices have not changed.",
    ),
    node2(
      "p",
      recipe.product +
        " · quantity / budget " +
        (data.amount || "—") +
        " · sell price " +
        (data.sell || "—"),
    ),
    table2(
      ["Material", "Your saved price", "Shared price"],
      recipe.ingredients.map((i) => [
        i.name,
        state.prices[i.id]?.value || "Not set",
        relevant[i.id]?.value || "Not supplied",
      ]),
    ),
  );
  try {
    const result = calculate(
      recipe,
      data,
      normalizePrices(recipe, { ...state.prices, ...relevant }),
    );
    panel.append(node2("p", "Estimated profit: " + money(result.profit)));
  } catch (error) {
    panel.append(node2("p", "Incomplete shared trade: " + error.message));
  }
  panel.append(
    button2(
      "Apply shared trade",
      () => {
        state.mode = payload.mode;
        state.inputs[payload.mode] = data;
        for (const [id, p] of Object.entries(relevant)) state.prices[id] = p;
        save();
        renderForm();
        panel.remove();
        notify("Shared trade applied.");
      },
      true,
    ),
    button2("Cancel shared trade", () => panel.remove()),
  );
  $2("calculator-page").prepend(panel);
}

async function sharePayload(payload) {
  try {
    const encoded = await encodePayload(payload);
    if (encoded.length > 6e3) {
      download2(
        "donut-" + payload.type + ".json",
        JSON.stringify(payload, null, 2),
        "application/json",
      );
      notify("This share is large. A JSON file was exported instead.");
      return;
    }
    const address = new URL(location.href);
    address.hash = "data=" + encoded;
    await clipboard(address.href);
  } catch {
    notify("Link sharing is unavailable. Export the JSON file instead.");
  }
}
function shareBook() {
  return sharePayload({
    type: "book",
    version: 4,
    prices: state.prices,
    sells: state.sells,
  });
}
function previewBook(payload) {
  if (payload.type !== "book") throw Error("Choose a price book file.");
  const clean = sanitizeState(payload),
    changes = [];
  for (const kind of ["prices", "sells"])
    for (const [key, p] of Object.entries(clean[kind])) {
      if (!Number.isFinite(parseAmount2(p.value)) || parseAmount2(p.value) < 0)
        continue;
      const previous = state[kind][key];
      if (previous?.value !== p.value || previous?.unit !== p.unit)
        changes.push({ kind, key, p, previous });
    }
  const panel = node2("section", null, { class: "card import-preview" });
  panel.append(
    node2("h2", "Preview price book changes"),
    node2(
      "p",
      changes.length +
        " changed prices. Existing prices outside this import are preserved.",
    ),
    table2(
      ["Price", "Current / item", "Imported / item"],
      changes.map((c) => [
        c.key,
        money(
          c.previous
            ? parseAmount2(c.previous.value) / Number(c.previous.unit)
            : null,
        ),
        money(parseAmount2(c.p.value) / Number(c.p.unit)),
      ]),
    ),
  );
  panel.append(
    button2(
      "Apply price book",
      () => {
        for (const c of changes) {
          state[c.kind][c.key] = c.p;
          if (c.kind === "sells") {
            for (const [id, data] of Object.entries(state.inputs))
              if (id + ":" + (data.variant || "") === c.key) {
                data.sell = c.p.value;
                data.sellUnit = c.p.unit;
              }
          }
        }
        save();
        panel.remove();
        hooks.showPage("prices");
        notify("Price book imported.");
      },
      true,
    ),
    button2("Cancel import", () => panel.remove()),
  );
  $2("prices-page").prepend(panel);
  panel.scrollIntoView?.({ block: "start" });
}
function bookImport() {
  const input2 = node2("input", null, {
    type: "file",
    accept: ".json,application/json",
    "aria-label": "Import price book JSON",
  });
  input2.addEventListener("change", async () => {
    try {
      const file = input2.files[0];
      if (!file) return;
      if (file.size > 2e6) throw Error("File is too large.");
      previewBook(JSON.parse(await file.text()));
    } catch (e) {
      notify("Import failed: " + e.message);
    }
  });
  return input2;
}
async function restoreDataLink() {
  if (!location.hash.startsWith("#data=")) return;
  try {
    const payload = await decodePayload(location.hash.slice(6));
    if (payload.type === "trade") {
      await previewTrade(payload);
    } else if (payload.type === "book") {
      await hooks.showPage("prices");
      previewBook(payload);
    } else if (payload.type === "plan") {
      const clean = sanitizeState({
        version: payload.version,
        plans: [payload.plan],
      });
      if (!clean.plans[0]?.items.length) throw Error("Empty plan.");
      await hooks.showPage("plans");
      hooks.previewPlan(clean.plans[0]);
    } else throw Error("Unknown link type.");
  } catch (e) {
    notify("Cannot read this shared link: " + e.message);
  }
}
export {
  bookImport,
  previewTrade,
  previewBook,
  restoreDataLink,
  restoreLink,
  share,
  shareBook,
  sharePayload,
  summary,
};
