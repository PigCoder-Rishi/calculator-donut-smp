import {
  notify,
  node as node3,
  $ as $3,
  button as button3,
  clipboard,
  amountField,
  itemIcon,
  makeSelect as makeSelect2,
  metric as metric2,
} from "./widgets.js";
import {
  dropTolerance,
  recipes,
  money as money2,
  number,
  calculate,
  normalizePrices,
  editPrice as updatePrice,
} from "./core.js";
import { restoreDataLink, share, restoreLink, summary } from "./share.js";
import {
  hooks as hooks2,
  state,
  save,
  currentRecipe,
  input,
  stale,
  recipeKey,
  replaceState as replaceState2,
} from "./state.js";

function applyTheme() {
  const theme =
    state.theme === "system"
      ? matchMedia("(prefers-color-scheme: light)").matches
        ? "light"
        : "dark"
      : state.theme;
  document.documentElement.dataset.theme = theme;
  document
    .querySelector('meta[name="theme-color"]')
    ?.setAttribute("content", theme === "light" ? "#f4f7ee" : "#101512");
  if ($3("theme-toggle"))
    $3("theme-toggle").textContent = "Theme: " + state.theme;
}
function animateProfit(element, value, previous) {
  const formatter = { format: money2 };
  if (
    matchMedia("(prefers-reduced-motion: reduce)").matches ||
    !Number.isFinite(previous) ||
    previous === value
  ) {
    element.textContent = formatter.format(value);
    return;
  }
  const start = performance.now();
  function frame(now) {
    if (!element.isConnected) return;
    const t = Math.min(1, (now - start) / 350),
      ease = 1 - (1 - t) ** 3;
    element.textContent = formatter.format(
      previous + (value - previous) * ease,
    );
    if (t < 1) requestAnimationFrame(frame);
  }
  requestAnimationFrame(frame);
}
function initDelight(showPage2) {
  const theme = button3("Theme: " + state.theme, () => {
    state.theme =
      { system: "light", light: "dark", dark: "system" }[state.theme] ||
      "system";
    applyTheme();
    save();
  });
  theme.id = "theme-toggle";
  const help = node3("dialog", null, {
    id: "help-dialog",
    "aria-labelledby": "help-title",
  });
  help.append(
    node3("h2", "A little help", { id: "help-title" }),
    node3(
      "p",
      "Use k / m / b for large values. Shared prices update every calculator. Save trades to track estimates, and export JSON to keep a backup.",
    ),
    node3("ul"),
  );
  const list = help.querySelector("ul");
  for (const text of [
    "/ \u2014 focus quantity",
    "Enter \u2014 save the current trade",
    "1\u20137 \u2014 switch sections",
    "? \u2014 open help",
    "Escape \u2014 close this dialog",
  ])
    list.append(node3("li", text));
  help.append(
    node3(
      "p",
      "Rankings use saved prices, not live server prices. Incomplete crafting batches round up. Fees reduce sales revenue. Comparisons rank total profit, so check quantities too.",
    ),
    button3("Close", () => help.close()),
  );
  document.body.append(help);
  const openHelp = () => help.showModal();
  $3("header-actions").append(theme, button3("?", openHelp));
  applyTheme();
  matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => {
    if (state.theme === "system") applyTheme();
  });
  document.addEventListener("keydown", (event) => {
    const editing =
      ["INPUT", "TEXTAREA", "SELECT"].includes(event.target.tagName) ||
      event.target.isContentEditable;
    if (editing || event.ctrlKey || event.metaKey || event.altKey || help.open)
      return;
    if (event.key === "/") {
      event.preventDefault();
      showPage2("calculator");
      $3("quantity")?.focus();
    }
    if (event.key === "?") {
      event.preventDefault();
      openHelp();
    }
    const pages2 = [
      "calculator",
      "leaderboard",
      "prices",
      "history",
      "chains",
      "compare",
      "plans",
    ];
    if (/^[1-7]$/.test(event.key)) showPage2(pages2[Number(event.key) - 1]);
  });
}

function renderWelcome() {
  document.documentElement.dataset.welcomed = String(
    Boolean(state.welcomeDismissed),
  );
  let root = $3("welcome-card");
  if (!root) {
    root = node3("section", null, {
      id: "welcome-card",
      class: "card welcome",
    });
    $3("calculator-page").prepend(root);
  }
  root.hidden = Boolean(state.welcomeDismissed);
  root.replaceChildren();
  if (root.hidden) return;
  root.append(
    node3("h2", "Welcome, trader."),
    node3(
      "p",
      "1. Set your material costs in Price Book. 2. Add selling prices. 3. Use Best Profit to compare your margins. Your numbers stay on this device.",
    ),
    button3("Set my prices", () => hooks2.showPage("prices"), true),
    button3("Dismiss welcome", () => {
      state.welcomeDismissed = true;
      root.hidden = true;
      document.documentElement.dataset.welcomed = "true";
      pickerExpanded = false;
      renderPicker();
      save();
    }),
  );
}

var lazyPages;
var loadPages = () => (lazyPages ||= import("./pages.js"));
var saveTrade = async () => {
  (await loadPages()).saveTrade();
};
var addCurrentTrade = async () => {
  (await loadPages()).addCurrentTrade();
};
var renderSensitivity = async () => {
  if (hooks2.getResult() && $3("sensitivity-panel")?.open)
    (await loadPages()).renderSensitivity();
};
var pages = [
  ["calculator", "Calculator"],
  ["leaderboard", "Best Profit"],
  ["prices", "Price Book"],
  ["history", "Trade History"],
  ["chains", "Crafting Chains"],
  ["compare", "Compare"],
  ["plans", "Plans"],
];
var activePage = "calculator";
async function showPage(id) {
  activePage = id;
  if ($3("more-menu")) $3("more-menu").hidden = true;
  if ($3("more-button")) {
    const label = pages.find(([key]) => key === id)?.[1];
    $3("more-button").textContent = pages.slice(3).some(([key]) => key === id)
      ? "More · " + label
      : "More";
    $3("more-button").setAttribute("aria-expanded", "false");
  }
  for (const [key] of pages) {
    $3(key + "-page").hidden = key !== id;
    $3("tab-" + key)?.setAttribute("aria-selected", String(key === id));
    $3("tab-" + key)?.setAttribute("tabindex", key === id ? "0" : "-1");
  }
  if (id !== "calculator") {
    const module = await loadPages();
    if (activePage !== id) return;
    module[
      {
        leaderboard: "renderLeaderboard",
        prices: "renderPrices",
        history: "renderHistory",
        chains: "renderChains",
        compare: "renderCompare",
        plans: "renderPlans",
      }[id]
    ]();
  }
}
async function initFeatures() {
  hooks2.showPage = showPage;
  renderWelcome();
  initDelight(showPage);
  $3("tabs").setAttribute("role", "tablist");
  for (const [index, [id, label]] of pages.entries()) {
    const tab = button3(label, () => {
      if (id === "calculator") hooks2.renderForm();
      showPage(id);
    });
    tab.id = "tab-" + id;
    tab.setAttribute("role", "tab");
    tab.setAttribute("aria-controls", id + "-page");
    tab.setAttribute("aria-selected", String(id === "calculator"));
    tab.setAttribute("tabindex", id === "calculator" ? "0" : "-1");
    const page = $3(id + "-page");
    page.setAttribute("role", "tabpanel");
    page.setAttribute("aria-labelledby", tab.id);
    page.setAttribute("tabindex", "0");
    tab.addEventListener("keydown", (e) => {
      const length = matchMedia("(max-width: 720px)").matches
        ? 3
        : pages.length;
      let next;
      if (e.key === "ArrowRight") next = (index + 1) % length;
      else if (e.key === "ArrowLeft") next = (index - 1 + length) % length;
      else if (e.key === "Home") next = 0;
      else if (e.key === "End") next = length - 1;
      else return;
      e.preventDefault();
      if (pages[next][0] === "calculator") hooks2.renderForm();
      showPage(pages[next][0]);
      $3("tab-" + pages[next][0]).focus();
    });
    $3("tabs").append(tab);
  }
  addMoreMenu();
  $3("sensitivity-panel")?.addEventListener("toggle", renderSensitivity);
  const actions = node3("div", null, { class: "toolbar" });
  actions.append(
    button3("Save this trade", saveTrade, true),
    button3("Add to plan", addCurrentTrade),
    button3("Copy result summary", () => {
      if (hooks2.getResult())
        clipboard(summary(currentRecipe(), hooks2.getResult()));
    }),
    button3("Share calculation", share),
  );
  $3("calculator-page").append(actions);
  document.addEventListener("trade-updated", () => {
    renderSensitivity();
    if (activePage === "leaderboard")
      loadPages().then((module) => {
        if (activePage === "leaderboard") module.renderLeaderboard();
      });
  });
  window.addEventListener("hashchange", () => {
    restoreLink();
    restoreDataLink();
  });
  restoreLink();
  restoreDataLink();
  renderSensitivity();
  document.addEventListener("keydown", (event) => {
    if (
      event.key === "Enter" &&
      event.target.tagName === "INPUT" &&
      !event.isComposing &&
      /^(quantity|sell|price-.+)$/.test(event.target.id) &&
      activePage === "calculator"
    ) {
      event.preventDefault();
      saveTrade();
    }
  });
}

var queueCalculate = (...args) => hooks2.queueCalculate(...args);
function renderFeeFields(data) {
  const details = node3("details", null, { class: "fee-fields" });
  details.append(node3("summary", "Selling fees & profit per hour"));
  data.fees ||= { enabled: false, percent: "0", flat: "0", listings: "1" };
  const label = node3("label", null, { class: "check" }),
    check = node3("input", null, { type: "checkbox" });
  check.checked = Boolean(data.fees.enabled);
  check.addEventListener("change", () => {
    data.fees.enabled = check.checked;
    queueCalculate();
  });
  label.append(check, node3("span", "Apply selling fees"));
  details.append(label);
  for (const [key, text] of [
    ["percent", "Sell fee (%)"],
    ["flat", "Fee per listing ($)"],
    ["listings", "Number of listings"],
  ])
    details.append(
      amountField(
        "fee-" + key,
        text,
        data.fees[key],
        (value) => {
          data.fees[key] = value;
          queueCalculate();
        },
        { whole: key === "listings" },
      ),
    );
  details.append(
    amountField(
      "throughput",
      "Output items per hour (optional)",
      data.throughput || "",
      (value) => {
        data.throughput = value;
        queueCalculate();
      },
      { optional: true },
    ),
  );
  return details;
}

var currentResult = null;
var timer;
function queueCalculate2() {
  clearTimeout(timer);
  timer = setTimeout(() => {
    save();
    recalculate();
  }, 160);
}
let pickerSearch = "",
  pickerExpanded = false;
function recipeLabel(recipe) {
  return recipe.name
    .replace(/^.*?\s*→\s*/, "")
    .replace(/\b[a-z]/g, (c) => c.toUpperCase());
}
function addMoreMenu() {
  const wrap = node3("div", null, {
      class: "mobile-more",
      role: "presentation",
    }),
    toggle = button3("More", () => {
      const menu = $3("more-menu");
      menu.hidden = !menu.hidden;
      toggle.setAttribute("aria-expanded", String(!menu.hidden));
      if (!menu.hidden) menu.querySelector("button").focus();
    }),
    menu = node3("div", null, {
      id: "more-menu",
      role: "menu",
      "aria-label": "More sections",
    });
  toggle.id = "more-button";
  toggle.setAttribute("aria-haspopup", "menu");
  toggle.setAttribute("aria-controls", "more-menu");
  toggle.setAttribute("aria-expanded", "false");
  menu.hidden = true;
  const items = pages.slice(3).map(([id, label]) => {
    const item = button3(label, async () => {
      await showPage(id);
      toggle.focus();
    });
    item.setAttribute("role", "menuitem");
    return item;
  });
  menu.append(...items);
  menu.addEventListener("keydown", (event) => {
    const index = items.indexOf(event.target);
    let next;
    if (event.key === "Escape") {
      menu.hidden = true;
      toggle.setAttribute("aria-expanded", "false");
      toggle.focus();
      event.preventDefault();
      return;
    }
    if (event.key === "ArrowDown") next = (index + 1) % items.length;
    else if (event.key === "ArrowUp")
      next = (index - 1 + items.length) % items.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = items.length - 1;
    else return;
    event.preventDefault();
    items[next].focus();
  });
  wrap.append(toggle, menu);
  $3("mobile-more-mount").append(wrap);
}
function renderPicker() {
  const picker = $3("recipe-picker");
  picker.replaceChildren();
  const choose = (id) => {
    save();
    state.mode = id;
    state.recent = [
      recipeKey(currentRecipe()),
      ...state.recent.filter((key) => key !== recipeKey(currentRecipe())),
    ].slice(0, 50);
    save();
    renderForm();
    $3("quantity").focus();
  };
  const compact = makeSelect2(
    "mode-picker",
    "Choose a calculator",
    recipes.map((r) => [r.id, recipeLabel(r)]),
    state.mode,
    choose,
  );
  compact.classList.add("picker-select");
  picker.append(compact);
  const desktop = node3("div", null, { class: "picker-desktop" }),
    search = node3("input", null, {
      id: "recipe-search",
      type: "search",
      placeholder: "Search calculators…",
      "aria-label": "Search calculators",
    }),
    grid = node3("div", null, { class: "recipe-grid" });
  search.value = pickerSearch;
  const expand = button3("Show all calculators", () => {
    pickerExpanded = !pickerExpanded;
    populate();
  });
  expand.id = "expand-calculators";
  function populate() {
    grid.replaceChildren();
    const query = pickerSearch.toLowerCase(),
      matches = recipes.filter((r) =>
        (r.name + " " + r.ingredients?.map((i) => i.name).join(" "))
          .toLowerCase()
          .includes(query),
      );
    const limit =
      state.welcomeDismissed && !pickerExpanded && !query ? 6 : matches.length;
    for (const recipe of matches.slice(0, limit)) {
      const card = button3("", () => choose(recipe.id));
      card.classList.add("recipe-card");
      card.setAttribute("aria-pressed", String(state.mode === recipe.id));
      card.append(itemIcon(recipe.icon), node3("span", recipeLabel(recipe)));
      grid.append(card);
    }
    if (!matches.length) grid.append(node3("p", "No matching calculators."));
    expand.hidden = !state.welcomeDismissed || Boolean(query);
    expand.textContent = pickerExpanded
      ? "Show fewer calculators"
      : "Show all calculators";
    expand.setAttribute("aria-expanded", String(pickerExpanded));
  }
  search.addEventListener("input", () => {
    pickerSearch = search.value;
    populate();
  });
  desktop.append(search, grid, expand);
  picker.append(desktop);
  populate();
}
function renderForm() {
  const recipe = currentRecipe(),
    data = input(),
    form = $3("trade-form");
  form.replaceChildren();
  const inventoryToggle = node3("input", null, {
    type: "checkbox",
    id: "inventory-mode",
  });
  inventoryToggle.checked = data.inventoryEnabled === true;
  inventoryToggle.addEventListener("change", () => {
    data.inventoryEnabled = inventoryToggle.checked;
    delete data.totalCost;
    renderForm();
    save();
  });
  const inventoryLabel = node3("label", " Use materials I already own", {
    for: "inventory-mode",
  });
  inventoryLabel.prepend(inventoryToggle);
  form.append(inventoryLabel);
  if (data.inventoryEnabled)
    form.append(
      node3(
        "p",
        "Owned materials count as zero purchase cost. Stock is an estimate, not automatically consumed. Quantity includes owned materials.",
        { class: "hint" },
      ),
    );
  if (recipe.variants)
    form.append(
      makeSelect2(
        "variant",
        recipe.variantLabel,
        recipe.variants.map((v) => [v.id, v.name]),
        recipe.variant,
        (value) => {
          save();
          data.variant = value;
          state.recent = [
            state.mode + ":" + value,
            ...state.recent.filter((key) => key !== state.mode + ":" + value),
          ].slice(0, 50);
          const savedSell = state.sells[state.mode + ":" + value];
          if (savedSell) {
            data.sell = savedSell.value;
            data.sellUnit = savedSell.unit;
          }
          renderForm();
          save();
        },
      ),
    );
  form.append(
    makeSelect2(
      "order-mode",
      "Order by",
      [
        [
          "quantity",
          recipe.specialRules === "materialOrder"
            ? "Material quantity"
            : "Output quantity",
        ],
        ["budget", "Total material budget ($)"],
      ],
      data.orderMode,
      (value) => {
        data.orderMode = value;
        delete data.totalCost;
        renderForm();
        save();
      },
    ),
  );
  const units = [
    [
      "1",
      recipe.specialRules === "materialOrder"
        ? recipe.ingredients[0].name
        : recipe.product,
    ],
    ["64", "Stacks (64)"],
    [
      String(recipe.shulkerCapacity),
      "Shulkers (" + number(recipe.shulkerCapacity) + ")",
    ],
  ];
  form.append(
    amountField(
      "quantity",
      data.orderMode === "budget"
        ? "Material budget ($)"
        : recipe.specialRules === "materialOrder"
          ? recipe.ingredients[0].name + " to buy"
          : recipe.product + " to make",
      data.amount,
      (value) => {
        data.amount = value;
        queueCalculate2();
      },
      {
        whole: data.orderMode !== "budget",
        units: recipe.stackable && data.orderMode !== "budget" ? units : void 0,
        unit: data.quantityUnit,
        onUnit: (value) => {
          data.quantityUnit = value;
          queueCalculate2();
        },
      },
    ),
  );
  const priceUnits = [
    ["1", "Per item"],
    ["64", "Per stack"],
    ["1728", "Per shulker"],
  ];
  for (const ingredient of recipe.ingredients) {
    const price = state.prices[ingredient.id] || { value: "", unit: "1" };
    const field = amountField(
      "price-" + ingredient.id,
      ingredient.name + " purchase price ($)",
      price.value,
      (value) => {
        updatePrice(
          state,
          "prices",
          ingredient.id,
          value,
          state.prices[ingredient.id]?.unit || "1",
        );
        queueCalculate2();
      },
      {
        units: priceUnits,
        unit: price.unit,
        onUnit: (value) => {
          updatePrice(
            state,
            "prices",
            ingredient.id,
            state.prices[ingredient.id]?.value || "",
            value,
          );
          renderForm();
          queueCalculate2();
        },
      },
    );
    field.querySelector("label").prepend(itemIcon(ingredient.icon));
    form.append(field);
    if (data.inventoryEnabled)
      form.append(
        amountField(
          "owned-" + ingredient.id,
          ingredient.name + " already owned",
          data.inventory?.[ingredient.id] || "",
          (value) => {
            (data.inventory ||= {})[ingredient.id] = value;
            queueCalculate2();
          },
          { whole: true, optional: true },
        ),
      );
    if (
      price.updated &&
      Date.now() - new Date(price.updated).getTime() > state.staleDays * 864e5
    )
      field.append(
        node3(
          "p",
          "This shared price is older than " + state.staleDays + " days.",
          { class: "hint stale-warning" },
        ),
      );
  }
  if (recipe.specialRules === "materialOrder" && data.orderMode !== "budget")
    form.append(
      amountField(
        "total-cost",
        "Entire order cost ($, optional)",
        data.totalCost || "",
        (value) => {
          data.totalCost = value;
          queueCalculate2();
        },
        { optional: true },
      ),
    );
  form.append(
    amountField(
      "sell",
      "Selling price ($)",
      data.sell,
      (value) => {
        data.sell = value;
        updatePrice(
          state,
          "sells",
          recipeKey(recipe),
          value,
          data.sellUnit || "1",
        );
        queueCalculate2();
      },
      {
        units: recipe.stackable ? priceUnits : void 0,
        unit: data.sellUnit,
        onUnit: (value) => {
          data.sellUnit = value;
          queueCalculate2();
        },
      },
    ),
  );
  form.append(
    node3(
      "div",
      recipe.ingredients
        .map((i) => `${number(i.count)} ${i.name}`)
        .join(" + ") + ` \u2192 ${recipe.outputCount} ${recipe.product}`,
      { class: "recipe" },
    ),
  );
  const actions = node3("div", null, { class: "toolbar" });
  actions.append(
    button3("Try an example", () => {
      recipe.ingredients.forEach((i) => {
        updatePrice(state, "prices", i.id, i.example);
        state.prices[i.id].example = true;
      });
      Object.assign(data, {
        amount: recipe.exampleAmount,
        orderMode: recipe.exampleOrder || "quantity",
        quantityUnit: "1",
        sell: recipe.exampleSell,
        sellUnit: "1",
      });
      updatePrice(state, "sells", recipeKey(recipe), recipe.exampleSell);
      state.sells[recipeKey(recipe)].example = true;
      renderForm();
      save();
    }),
    button3("Clear inputs", () => {
      state.inputs[state.mode] = {
        variant: recipe.variant,
        amount: "",
        sell: "",
        orderMode: "quantity",
        quantityUnit: "1",
        sellUnit: "1",
      };
      renderForm();
      save();
    }),
  );
  form.append(
    renderFeeFields(data),
    actions,
    node3(
      "p",
      "Prices and quantities accept k/m/b. Materials are shared across calculators.",
      { class: "hint" },
    ),
  );
  renderPicker();
  recalculate();
}
function evaluate(recipe = currentRecipe(), data = input()) {
  return calculate(recipe, data, normalizePrices(recipe, state.prices, data));
}
function renderResult(
  result,
  container = $3("result"),
  { prices = state.prices, sell } = {},
) {
  const previous = Number(container.dataset.lastProfit);
  container.dataset.lastProfit = String(result.profit);
  container.replaceChildren();
  const badge = node3(
    "span",
    result.profit > 0
      ? "Profitable trade"
      : result.profit < 0
        ? "Trade loses money"
        : "Break-even trade",
    { class: "status " + (result.profit < 0 ? "negative" : "positive") },
  );
  const profit = node3("div", money2(result.profit), {
    class: "profit " + (result.profit < 0 ? "negative" : ""),
  });
  if (container === $3("result")) profit.id = "profit-value";
  container.append(badge, profit);
  animateProfit(profit, result.profit, previous);
  const meter = node3("progress", null, {
    class: "profit-meter " + (result.profit < 0 ? "loss-meter" : "gain-meter"),
    max: 100,
    value: Math.min(100, Math.abs(result.returnPercent || 0)),
    "aria-label": "Magnitude of return on cost (up to 100%)",
  });
  container.append(meter);
  metric2(
    "Sell price can drop before a loss",
    dropTolerance(result) === null
      ? "Unavailable"
      : number(dropTolerance(result)) + "%",
    container,
  );
  metric2("Items produced", number(result.crafted), container);
  metric2("Total purchase cost", money2(result.cost), container);
  metric2("Total sales revenue", money2(result.revenue), container);
  metric2("Profit per item", money2(result.profitPerItem), container);
  metric2(
    "Return on cost",
    result.returnPercent === null
      ? "\u2014"
      : number(result.returnPercent) + "%",
    container,
  );
  metric2(
    "Break-even sale price / item",
    money2(
      result.breakEven === null
        ? null
        : Math.ceil(result.breakEven * 100) / 100,
    ),
    container,
  );
  if (result.feesEnabled) {
    metric2("Profit before fees", money2(result.profitBeforeFees), container);
    metric2("Selling fees", money2(result.feeCost), container);
    metric2("Profit after fees", money2(result.profit), container);
  }
  const details = node3("details");
  details.append(node3("summary", "Material cost breakdown"));
  result.rows.forEach((r) =>
    metric2(
      r.name +
        " \xD7 " +
        number(r.quantity) +
        (r.ownedQuantity
          ? " to buy · " + number(r.ownedQuantity) + " owned"
          : ""),
      money2(r.cost),
      details,
    ),
  );
  container.append(details);
  const staleNames = result.rows
    .filter((r) => stale(prices[r.id]))
    .map((r) => r.name);
  const sale =
    sell || state.sells[result.recipeId + ":" + (result.variant || "")];
  if (stale(sale)) staleNames.push("selling price");
  if (result.rows.some((r) => prices[r.id]?.example) || sale?.example)
    container.append(
      node3(
        "p",
        "Example prices: replace these placeholders with your server prices.",
        { class: "example-banner" },
      ),
    );
  if (staleNames.length)
    container.append(
      node3(
        "p",
        "Stale prices: " +
          staleNames.join(", ") +
          ". Check them in Price Book.",
        { class: "stale-warning" },
      ),
    );
  if (result.unspent)
    container.append(
      node3("p", money2(result.unspent) + " unspent budget.", {
        class: "note",
      }),
    );
  if (result.rounded)
    container.append(
      node3(
        "p",
        `Rounded up from ${number(result.requested)} to ${number(result.crafted)} for complete crafting batches.`,
        { class: "note" },
      ),
    );
  if (result.leftovers)
    container.append(
      node3("p", number(result.leftovers) + " leftover materials.", {
        class: "note",
      }),
    );
}
function recalculate() {
  try {
    currentResult = evaluate();
    renderResult(currentResult);
    const summary2 = "Estimated profit " + money2(currentResult.profit);
    if ($3("profit-announcement").textContent !== summary2)
      $3("profit-announcement").textContent = summary2;
  } catch (error) {
    currentResult = null;
    $3("result").replaceChildren(
      node3("p", error.message, { class: "empty-state" }),
    );
    $3("profit-announcement").textContent = "";
  }
  document.dispatchEvent(
    new CustomEvent("trade-updated", { detail: currentResult }),
  );
}
function getResult() {
  return currentResult;
}
Object.assign(hooks2, {
  renderForm,
  renderResult,
  queueCalculate: queueCalculate2,
  getResult,
  recalculate,
});
document.addEventListener("state-replaced", () => {
  renderForm();
  applyTheme();
});
renderForm();
initFeatures();
document.documentElement.classList.remove("app-loading");
if (
  "serviceWorker" in navigator &&
  ["http:", "https:"].includes(location.protocol)
)
  navigator.serviceWorker.register("./sw.js").catch(() => {
    notify(
      "Offline installation is unavailable here; the calculator still works online.",
    );
  });
export {
  $3 as $3,
  amountField as amountField,
  animateProfit,
  applyTheme,
  button3 as button3,
  currentRecipe as currentRecipe,
  evaluate,
  getResult,
  initDelight,
  initFeatures,
  input as input,
  makeSelect2 as makeSelect,
  metric2 as metric,
  node3 as node3,
  queueCalculate2 as queueCalculate,
  recalculate,
  renderFeeFields,
  renderForm,
  renderPicker,
  renderResult,
  renderWelcome,
  replaceState2 as replaceState,
  save as save,
  showPage,
  state as state,
};
