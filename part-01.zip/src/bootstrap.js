// Keep startup independent so a broken module cannot hide all visitor feedback.
let failed = false;
function recover(error) {
  if (failed) return;
  failed = true;
  document.documentElement.classList.remove("app-loading");
  const main = document.querySelector("main");
  main.replaceChildren();
  const panel = document.createElement("section");
  panel.className = "card";
  const heading = document.createElement("h1");
  heading.textContent = "Let’s recover your calculator";
  const message = document.createElement("p");
  message.textContent =
    "Startup failed. Your saved data is still on this device. Export a backup before resetting.";
  panel.append(heading, message);
  const action = (label, run) => {
    const button = document.createElement("button");
    button.type = "button";
    button.textContent = label;
    button.addEventListener("click", run);
    panel.append(button);
  };
  action("Export data", () => {
    try {
      const data = {};
      for (const key of [
        "donut-profit-v4",
        "donut-profit-v3",
        "donut-profit-v2",
      ]) {
        const value = localStorage.getItem(key);
        if (value !== null) data[key] = value;
      }
      const blob = new Blob([JSON.stringify(data, null, 2)], {
          type: "application/json",
        }),
        url = URL.createObjectURL(blob),
        link = document.createElement("a");
      link.href = url;
      link.download = "donut-recovery.json";
      link.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      message.textContent =
        "Storage access is blocked. Allow browser storage, then reload.";
    }
  });
  action("Reset data", () => {
    const confirm = document.createElement("button");
    confirm.type = "button";
    confirm.textContent = "Confirm reset of calculator data";
    confirm.addEventListener("click", () => {
      try {
        for (const key of [
          "donut-profit-v4",
          "donut-profit-v3",
          "donut-profit-v2",
        ])
          localStorage.removeItem(key);
        location.reload();
      } catch {
        message.textContent =
          "Storage access is blocked. Allow browser storage, then reload.";
      }
    });
    panel.append(confirm);
  });
  action("Reload", () => location.reload());
  main.append(panel);
  console.error(error);
}
window.addEventListener("error", (event) => recover(event.error));
window.addEventListener("unhandledrejection", (event) => recover(event.reason));
try {
  await import("./ui.js");
} catch (error) {
  recover(error);
}
