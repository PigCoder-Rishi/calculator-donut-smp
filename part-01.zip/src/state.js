import { notify, $ } from "./widgets.js";
import {
  updatePrice,
  recipes,
  resolveRecipe,
  setCompactMoney,
} from "./core.js";
var STORAGE_KEY = "donut-profit-v4";
const LEGACY_KEYS = ["donut-profit-v3", "donut-profit-v2"];
function defaultState() {
  return {
    version: 4,
    mode: "chests",
    inputs: {},
    prices: {},
    sells: {},
    history: [],
    session: "Default",
    staleDays: 7,
    theme: "system",
    chains: {},
    welcomeDismissed: false,
    compactMoney: false,
    plans: [],
    favorites: [],
    recent: [],
    bookSnapshots: [],
  };
}
function createStorage(storage, onError = () => {}) {
  let fallback = defaultState(),
    problem = null,
    raw = "",
    bytes = 0;
  return {
    get problem() {
      return problem;
    },
    get bytes() {
      return bytes;
    },
    get raw() {
      return raw;
    },
    load() {
      let saved;
      try {
        saved = storage?.getItem(STORAGE_KEY);
        if (!saved)
          for (const key of LEGACY_KEYS) {
            saved = storage?.getItem(key);
            if (saved) break;
          }
      } catch {
        problem = { kind: "unavailable" };
        onError("Browser storage is unavailable. Export to keep changes.");
        return fallback;
      }
      if (saved) {
        raw = saved;
        bytes = new TextEncoder().encode(raw).length;
        try {
          fallback = sanitizeState(JSON.parse(raw));
        } catch (error) {
          problem = { kind: "invalid", message: error.message };
          onError("Saved data needs recovery.");
        }
      }
      return fallback;
    },
    save(value) {
      fallback = value;
      raw = JSON.stringify(value);
      bytes = new TextEncoder().encode(raw).length;
      try {
        storage?.setItem(STORAGE_KEY, raw);
        if (!storage) {
          problem = { kind: "unavailable" };
          return false;
        }
        problem = null;
        return true;
      } catch (error) {
        problem = {
          kind: error.name === "QuotaExceededError" ? "quota" : "unavailable",
        };
        onError(
          problem.kind === "quota"
            ? "Device storage is full. Keep this tab open and export your data or prune history."
            : "Browser storage is unavailable. Export your data to keep it.",
        );
        return false;
      }
    },
  };
}
function sanitizeState(value) {
  if (
    !value ||
    typeof value !== "object" ||
    Array.isArray(value) ||
    ![2, 3, 4].includes(value.version)
  )
    throw new Error("Unsupported data file.");
  const clean = defaultState();
  for (const key of ["mode", "session", "theme"])
    if (typeof value[key] === "string") clean[key] = value[key].slice(0, 200);
  for (const key of ["inputs", "prices", "sells", "chains"])
    if (
      value[key] &&
      typeof value[key] === "object" &&
      !Array.isArray(value[key])
    ) {
      clean[key] = Object.fromEntries(
        Object.entries(value[key])
          .filter(
            ([k]) => !["__proto__", "constructor", "prototype"].includes(k),
          )
          .slice(0, 500)
          .map(([k, v]) => [k, JSON.parse(JSON.stringify(v))]),
      );
    }
  clean.staleDays =
    Number.isFinite(value.staleDays) && value.staleDays >= 1
      ? Math.min(365, value.staleDays)
      : 7;
  clean.history = Array.isArray(value.history)
    ? value.history
        .filter(
          (t) =>
            t &&
            typeof t === "object" &&
            typeof t.name === "string" &&
            typeof t.date === "string" &&
            [t.quantity, t.profit, t.cost, t.revenue].every(Number.isFinite),
        )
        .slice(-1e4)
        .map((t) => ({
          ...t,
          id: String(t.id || "legacy-" + t.date + "-" + t.name).slice(0, 200),
          name: t.name.slice(0, 200),
          session: String(t.session || "Default").slice(0, 200),
          notes: String(t.notes || "").slice(0, 2000),
          tags: Array.isArray(t.tags)
            ? t.tags
                .filter((v) => typeof v === "string")
                .slice(0, 20)
                .map((v) => v.slice(0, 50))
            : [],
          actualSell:
            typeof t.actualSell === "string" ? t.actualSell.slice(0, 100) : "",
        }))
    : [];
  const inputFields = [
    "amount",
    "orderMode",
    "quantityUnit",
    "sell",
    "sellUnit",
    "variant",
    "totalCost",
    "throughput",
  ];
  clean.inputs = Object.fromEntries(
    Object.entries(clean.inputs)
      .filter(
        ([, data]) => data && typeof data === "object" && !Array.isArray(data),
      )
      .map(([key, data]) => {
        const valid = Object.fromEntries(
          inputFields
            .filter((k) => typeof data[k] === "string")
            .map((k) => [k, data[k].slice(0, 100)]),
        );
        if (data.fees && typeof data.fees === "object")
          valid.fees = {
            enabled: data.fees.enabled === true,
            percent: String(data.fees.percent ?? "0").slice(0, 100),
            flat: String(data.fees.flat ?? "0").slice(0, 100),
            listings: String(data.fees.listings ?? "1").slice(0, 100),
          };
        valid.inventoryEnabled = data.inventoryEnabled === true;
        valid.inventory = Object.fromEntries(
          Object.entries(data.inventory || {})
            .filter(
              ([key, v]) =>
                !["__proto__", "constructor", "prototype"].includes(key) &&
                typeof v === "string",
            )
            .slice(0, 500)
            .map(([key, v]) => [key, v.slice(0, 100)]),
        );
        return [key, valid];
      }),
  );
  const validPrice = (p) => ({
    value: p.value.slice(0, 100),
    unit: ["1", "64", "1728"].includes(String(p.unit)) ? String(p.unit) : "1",
    updated:
      typeof p.updated === "string" && !Number.isNaN(Date.parse(p.updated))
        ? p.updated
        : void 0,
    example: p.example === true,
  });
  for (const kind of ["prices", "sells"])
    clean[kind] = Object.fromEntries(
      Object.entries(clean[kind])
        .filter(
          ([, p]) => p && typeof p === "object" && typeof p.value === "string",
        )
        .map(([key, p]) => [
          key,
          {
            ...validPrice(p),
            history: Array.isArray(p.history)
              ? p.history
                  .filter(
                    (h) =>
                      h &&
                      typeof h.value === "string" &&
                      typeof h.updated === "string" &&
                      !Number.isNaN(Date.parse(h.updated)),
                  )
                  .slice(-50)
                  .map(validPrice)
              : [],
          },
        ]),
    );
  clean.welcomeDismissed = value.welcomeDismissed === true;
  clean.compactMoney = value.compactMoney === true;
  for (const key of ["favorites", "recent"])
    clean[key] = Array.isArray(value[key])
      ? [
          ...new Set(
            value[key]
              .filter((v) => typeof v === "string")
              .map((v) => v.slice(0, 200)),
          ),
        ].slice(0, 100)
      : [];
  clean.bookSnapshots = Array.isArray(value.bookSnapshots)
    ? value.bookSnapshots
        .filter((p) => p && typeof p.name === "string")
        .slice(-20)
        .map((p) => ({
          id: String(p.id || ""),
          name: p.name.slice(0, 200),
          date: String(p.date || ""),
          prices: sanitizeState({ version: 4, prices: p.prices }).prices,
          sells: sanitizeState({ version: 4, sells: p.sells }).sells,
        }))
    : [];
  clean.plans = Array.isArray(value.plans)
    ? value.plans
        .filter(
          (p) => p && typeof p.name === "string" && Array.isArray(p.items),
        )
        .slice(-100)
        .map((p) => ({
          id: String(p.id || ""),
          name: p.name.slice(0, 200),
          checked: Array.isArray(p.checked)
            ? p.checked
                .filter((v) => typeof v === "string")
                .slice(0, 500)
                .map((v) => v.slice(0, 100))
            : [],
          date:
            typeof p.date === "string"
              ? p.date
              : /* @__PURE__ */ new Date().toISOString(),
          items: p.items
            .filter(
              (i) =>
                i &&
                typeof i.recipeId === "string" &&
                i.input &&
                typeof i.input === "object" &&
                i.prices &&
                typeof i.prices === "object",
            )
            .slice(0, 50)
            .map((i) => ({
              recipeId: i.recipeId,
              variant: typeof i.variant === "string" ? i.variant : void 0,
              input: sanitizeState({ version: 3, inputs: { entry: i.input } })
                .inputs.entry,
              prices: sanitizeState({ version: 3, prices: i.prices }).prices,
            })),
        }))
    : [];
  clean.chains = Object.fromEntries(
    Object.entries(clean.chains)
      .filter(([, c]) => c && typeof c === "object" && !Array.isArray(c))
      .map(([key, c]) => [
        key,
        Object.fromEntries(
          Object.entries(c).filter(
            ([k, v]) =>
              !["__proto__", "constructor", "prototype"].includes(k) &&
              ["buy", "craft", "auto"].includes(v),
          ),
        ),
      ]),
  );
  if (!["system", "dark", "light"].includes(clean.theme))
    clean.theme = "system";
  return clean;
}

var local;
try {
  local = window.localStorage;
} catch {}
var persistence = createStorage(local, (message) => {
  if (typeof document !== "undefined" && $("notice")) notify(message);
});
var state = persistence.load() || defaultState();
if (persistence.problem?.kind === "invalid")
  throw Error(
    "Your saved data could not be loaded. Export it before resetting.",
  );
setCompactMoney(state.compactMoney);
if (!recipes.some((r) => r.id === state.mode)) state.mode = "chests";
let saveTimer;
function flushSave() {
  clearTimeout(saveTimer);
  persistence.save(state);
}
if (typeof window !== "undefined")
  window.addEventListener("pagehide", flushSave);
function storageBytes() {
  return new TextEncoder().encode(JSON.stringify(state)).length;
}
function pruneHistory(keep) {
  if (!Number.isSafeInteger(keep) || keep < 0 || keep > 10000)
    throw Error("Choose a supported history limit.");
  state.history = state.history.slice(-keep);
  if (keep === 0) state.history = [];
  save();
  return state.history.length;
}
function save() {
  const data = input();
  const key = state.mode + ":" + (data.variant || "");
  if (
    data.sell &&
    (state.sells[key]?.value !== data.sell ||
      state.sells[key]?.unit !== (data.sellUnit || "1"))
  )
    updatePrice(state, "sells", key, data.sell, data.sellUnit || "1");
  clearTimeout(saveTimer);
  saveTimer = setTimeout(flushSave, 500);
  saveTimer.unref?.();
}
function replaceState(next) {
  state = next;
  setCompactMoney(state.compactMoney);
  save();
  document.dispatchEvent(new CustomEvent("state-replaced"));
}
function currentRecipe() {
  return resolveRecipe(state.mode, input().variant);
}
function input() {
  const defaults = {
    amount: "",
    orderMode: "quantity",
    quantityUnit: "1",
    sell: "",
    sellUnit: "1",
    variant: recipes.find((r) => r.id === state.mode)?.variants?.[0]?.id,
  };
  if (!state.inputs[state.mode] || typeof state.inputs[state.mode] !== "object")
    state.inputs[state.mode] = {
      ...defaults,
      sell:
        state.sells[state.mode + ":" + (defaults.variant || "")]?.value || "",
      sellUnit:
        state.sells[state.mode + ":" + (defaults.variant || "")]?.unit || "1",
    };
  for (const [key, value] of Object.entries(defaults))
    if (state.inputs[state.mode][key] === void 0)
      state.inputs[state.mode][key] = value;
  return state.inputs[state.mode];
}
function recipeKey(recipe) {
  return recipe.id + ":" + (recipe.variant || "");
}
function stale(entry) {
  return (
    entry?.updated &&
    Date.now() - new Date(entry.updated).getTime() > state.staleDays * 864e5
  );
}

var hooks = {};
export {
  flushSave,
  storageBytes,
  pruneHistory,
  STORAGE_KEY,
  createStorage,
  currentRecipe,
  defaultState,
  hooks,
  input,
  persistence,
  recipeKey,
  replaceState,
  sanitizeState,
  save,
  stale,
  state,
};
