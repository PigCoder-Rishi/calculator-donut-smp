import { node } from "./widgets.js";
import { money, number } from "./core.js";

var NS = "http://www.w3.org/2000/svg";
function svgNode(tag, attrs, text) {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, String(v));
  if (text) e.textContent = text;
  return e;
}
function lineChart(
  points,
  { title = "Profit", xLabel = "Scenario", marker, selected } = {},
) {
  points = points.filter((p) => Number.isFinite(p.x) && Number.isFinite(p.y));
  const wrap = node("div", null, { class: "chart" });
  if (!points.length) {
    wrap.append(
      node("p", "Add data to see this chart.", { class: "empty-state" }),
    );
    return wrap;
  }
  const xs = points.map((p) => p.x),
    ys = points.map((p) => p.y);
  let minX = Math.min(...xs),
    maxX = Math.max(...xs),
    minY = Math.min(0, ...ys),
    maxY = Math.max(0, ...ys);
  if (minX === maxX) maxX = minX + 1;
  if (minY === maxY) maxY = minY + 1;
  const x = (v) => 95 + ((v - minX) / (maxX - minX)) * 455,
    y = (v) => 180 - ((v - minY) / (maxY - minY)) * 145;
  const svg = svgNode("svg", {
    viewBox: "0 0 600 240",
    role: "group",
    "aria-label": title,
    preserveAspectRatio: "xMidYMid meet",
  });
  svg.append(
    svgNode("title", {}, title),
    svgNode("rect", {
      x: 95,
      y: 35,
      width: 455,
      height: y(0) - 35,
      fill: "var(--positive)",
      "fill-opacity": ".07",
    }),
    svgNode("rect", {
      x: 95,
      y: y(0),
      width: 455,
      height: 180 - y(0),
      fill: "var(--negative)",
      "fill-opacity": ".07",
    }),
  );
  for (let i = 0; i < 5; i++) {
    const value = minY + ((maxY - minY) * i) / 4;
    svg.append(
      svgNode("line", {
        x1: 95,
        x2: 550,
        y1: y(value),
        y2: y(value),
        stroke: "var(--border)",
        "stroke-opacity": ".6",
      }),
      svgNode(
        "text",
        {
          x: 87,
          y: y(value) + 4,
          "text-anchor": "end",
          fill: "var(--muted)",
          "font-size": 11,
        },
        money(value),
      ),
    );
  }
  for (let i = 0; i < 4; i++) {
    const value = minX + ((maxX - minX) * i) / 3;
    svg.append(
      svgNode(
        "text",
        {
          x: x(value),
          y: 205,
          "text-anchor": "middle",
          fill: "var(--muted)",
          "font-size": 11,
        },
        number(value),
      ),
    );
  }
  svg.append(
    svgNode("line", {
      x1: 95,
      x2: 550,
      y1: y(0),
      y2: y(0),
      stroke: "var(--muted)",
    }),
    svgNode("polyline", {
      points: points.map((p) => x(p.x) + "," + y(p.y)).join(" "),
      fill: "none",
      stroke: "var(--accent)",
      "stroke-width": 3,
    }),
  );
  const tooltip = node(
      "p",
      title + ": hover a point or focus it and use arrow keys.",
      { class: "chart-tooltip", "aria-live": "polite" },
    ),
    dots = [];
  points.forEach((p, index) => {
    const dot = svgNode("circle", {
      cx: x(p.x),
      cy: y(p.y),
      r: 5,
      fill: p.y < 0 ? "var(--negative)" : "var(--accent)",
      tabindex: index === 0 ? 0 : -1,
      role: "button",
      "aria-label": xLabel + " " + number(p.x) + ": " + money(p.y),
    });
    const show = () => {
      tooltip.textContent = xLabel + " " + number(p.x) + " \xB7 " + money(p.y);
      dots.forEach((d, i) => d.setAttribute("tabindex", i === index ? 0 : -1));
    };
    dot.addEventListener("mouseenter", show);
    dot.addEventListener("focus", show);
    dot.addEventListener("click", () => {
      dot.focus();
      show();
    });
    dot.addEventListener("keydown", (e) => {
      let next;
      if (["ArrowRight", "ArrowDown"].includes(e.key))
        next = Math.min(points.length - 1, index + 1);
      else if (["ArrowLeft", "ArrowUp"].includes(e.key))
        next = Math.max(0, index - 1);
      else if (e.key === "Home") next = 0;
      else if (e.key === "End") next = points.length - 1;
      else if (["Enter", " "].includes(e.key)) {
        e.preventDefault();
        show();
        return;
      } else return;
      e.preventDefault();
      dots[next].focus();
    });
    dots.push(dot);
    svg.append(dot);
  });
  if (selected && selected.x >= minX && selected.x <= maxX)
    svg.append(
      svgNode("circle", {
        cx: x(selected.x),
        cy: y(selected.y),
        r: 6,
        fill: "var(--pink)",
        "aria-hidden": "true",
      }),
    );
  if (marker !== null && marker !== void 0 && marker >= minX && marker <= maxX)
    svg.append(
      svgNode("line", {
        x1: x(marker),
        x2: x(marker),
        y1: 25,
        y2: 180,
        stroke: "var(--pink)",
        "stroke-dasharray": "4 4",
      }),
      svgNode(
        "text",
        {
          x: Math.min(480, Math.max(95, x(marker) - 45)),
          y: 18,
          fill: "var(--pink)",
          "font-size": 11,
        },
        "Break-even",
      ),
    );
  svg.append(
    svgNode(
      "text",
      {
        x: 290,
        y: 230,
        "text-anchor": "middle",
        fill: "var(--muted)",
        "font-size": 11,
      },
      xLabel,
    ),
  );
  const details = node("details");
  details.append(node("summary", "Chart values"));
  const list = node("ul");
  points.forEach((p) =>
    list.append(node("li", number(p.x) + ": " + money(p.y))),
  );
  details.append(list);
  wrap.append(svg, tooltip, details);
  return wrap;
}
export { lineChart };
