function parseAmount(value) {
  const match = String(value)
    .trim()
    .match(/^(-?(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d+)?|-?\.\d+)\s*([kmb])?$/i);
  if (!match) return NaN;
  const exponent = { k: 3, m: 6, b: 9 }[match[2]?.toLowerCase()] || 0;
  return Number(match[1].replace(/,/g, "") + "e" + exponent);
}
var compactMoney = false;
function setCompactMoney(enabled) {
  compactMoney = Boolean(enabled);
}
function formatMoney(value, compact = compactMoney) {
  if (!Number.isFinite(value)) return "\u2014";
  if (compact) {
    const abs = Math.abs(value);
    for (const [scale, suffix] of [
      [1e9, "b"],
      [1e6, "m"],
      [1e3, "k"],
    ])
      if (abs >= scale)
        return (
          (value < 0 ? "-$" : "$") +
          new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(
            abs / scale,
          ) +
          suffix
        );
  }
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    maximumFractionDigits: 2,
  }).format(value);
}
var money = (value) => formatMoney(value);
var number = (value) =>
  new Intl.NumberFormat("en-US", { maximumFractionDigits: 2 }).format(value);
function validateAmount(raw, { whole: whole2 = false, required = true } = {}) {
  if (!String(raw).trim()) return required ? "Enter a value." : "";
  const value = parseAmount(raw);
  if (!Number.isFinite(value))
    return "Use a number, such as 100, 2.5k, 1m, or 1b.";
  if (value < 0) return "Negative values are not allowed.";
  if (value > Number.MAX_SAFE_INTEGER)
    return "This number is too large to calculate accurately.";
  if (whole2 && !Number.isSafeInteger(value))
    return "Enter a whole number of items or units.";
  return "";
}

import additionalRecipes from "../data/recipes.json" with { type: "json" };
var ingredient = (id, name, count, example, icon = "block") => ({
  id,
  name,
  count,
  example,
  icon,
});
var diamondPieces = [
  ["sword", "Sword", 2, 1],
  ["spear", "Spear", 1, 2],
  ["pickaxe", "Pickaxe", 3, 2],
  ["axe", "Axe", 3, 2],
  ["shovel", "Shovel", 1, 2],
  ["hoe", "Hoe", 2, 2],
  ["helmet", "Helmet", 5, 0],
  ["chestplate", "Chestplate", 8, 0],
  ["leggings", "Leggings", 7, 0],
  ["boots", "Boots", 4, 0],
].map(([id, name, diamonds, sticks]) => ({
  id,
  name: `Diamond ${name.toLowerCase()}`,
  outputId: `diamond-${id}`,
  exampleSell: String(diamonds * 1e3 + sticks * 10 + 500),
  ingredients: [
    ingredient("diamond", "Diamonds", diamonds, "1k", "gem"),
    ...(sticks ? [ingredient("stick", "Sticks", sticks, "10", "stick")] : []),
  ],
}));
var recipes = [
  {
    id: "chests",
    name: "Spruce logs \u2192 Chests",
    product: "Chests",
    outputId: "chest",
    icon: "chest",
    outputCount: 1,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "1728",
    exampleSell: "300",
    specialRules: "materialOrder",
    ingredients: [ingredient("spruce-log", "Spruce logs", 2, "100", "log")],
  },
  {
    id: "bones",
    name: "Bones \u2192 Bone blocks",
    product: "Bone blocks",
    outputId: "bone-block",
    icon: "block",
    outputCount: 1,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "100k",
    exampleOrder: "budget",
    exampleSell: "450",
    specialRules: "materialOrder",
    ingredients: [ingredient("bone", "Bones", 3, "100", "bone")],
  },
  {
    id: "books",
    name: "Book & Quill",
    product: "Books & quills",
    outputId: "book-quill",
    icon: "book",
    outputCount: 1,
    stackable: false,
    shulkerCapacity: 27,
    exampleAmount: "100",
    exampleSell: "250",
    variantLabel: "Book source",
    variants: [
      {
        id: "buy",
        name: "Buy books",
        product: "Books & quills (bought books)",
        ingredients: [
          ingredient("book", "Books", 1, "100", "book"),
          ingredient("feather", "Feathers", 1, "20", "feather"),
          ingredient("ink-sac", "Ink sacs", 1, "30", "drop"),
        ],
      },
      {
        id: "craft",
        name: "Craft books",
        product: "Books & quills (crafted books)",
        ingredients: [
          ingredient("paper", "Paper", 3, "10", "paper"),
          ingredient("leather", "Leather", 1, "50", "hide"),
          ingredient("feather", "Feathers", 1, "20", "feather"),
          ingredient("ink-sac", "Ink sacs", 1, "30", "drop"),
        ],
      },
    ],
  },
  {
    id: "diamonds",
    name: "Diamond pieces",
    product: "Diamond pieces",
    outputId: "diamond-sword",
    icon: "gem",
    outputCount: 1,
    stackable: false,
    shulkerCapacity: 27,
    exampleAmount: "10",
    variantLabel: "Diamond piece",
    variants: diamondPieces,
  },
  {
    id: "crystals",
    name: "End crystals",
    product: "End crystals",
    outputId: "end-crystal",
    icon: "crystal",
    outputCount: 1,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "100",
    exampleSell: "5k",
    ingredients: [
      ingredient("glass", "Glass", 7, "100", "glass"),
      ingredient("ender-eye", "Eyes of Ender", 1, "1k", "eye"),
      ingredient("ghast-tear", "Ghast tears", 1, "2k", "drop"),
    ],
  },
  {
    id: "anchors",
    name: "Respawn anchors",
    product: "Respawn anchors",
    outputId: "respawn-anchor",
    icon: "anchor",
    outputCount: 1,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "100",
    exampleSell: "10k",
    note: "Uncharged anchors; charging glowstone is not included.",
    ingredients: [
      ingredient("crying-obsidian", "Crying obsidian", 6, "1k", "block"),
      ingredient("glowstone", "Glowstone blocks", 3, "500", "glow"),
    ],
  },
  {
    id: "slabs",
    name: "Spruce slabs",
    product: "Spruce slabs",
    outputId: "spruce-slab",
    icon: "slab",
    outputCount: 6,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "100",
    exampleSell: "100",
    ingredients: [
      ingredient("spruce-plank", "Spruce planks", 3, "100", "plank"),
    ],
  },
  {
    id: "turtles",
    name: "Turtle helmets",
    product: "Turtle helmets",
    outputId: "turtle-helmet",
    icon: "helmet",
    outputCount: 1,
    stackable: false,
    shulkerCapacity: 27,
    exampleAmount: "100",
    exampleSell: "7.5k",
    ingredients: [
      ingredient("turtle-scute", "Turtle scutes", 5, "1k", "shell"),
    ],
  },
  {
    id: "walls",
    name: "Cobblestone walls",
    product: "Cobblestone walls",
    outputId: "cobblestone-wall",
    icon: "wall",
    outputCount: 6,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "100",
    exampleSell: "150",
    ingredients: [ingredient("cobblestone", "Cobblestone", 6, "100", "block")],
  },
  {
    id: "smelting",
    name: "Sand \u2192 Glass",
    product: "Glass blocks",
    outputId: "glass",
    icon: "glass",
    outputCount: 1,
    stackable: true,
    shulkerCapacity: 1728,
    exampleAmount: "100",
    exampleSell: "250",
    specialRules: "wholeFuel",
    note: "Each charcoal smelts up to 8 sand. Assumes efficient continuous smelting.",
    ingredients: [
      ingredient("sand", "Sand", 1, "100", "sand"),
      ingredient("charcoal", "Charcoal", 1 / 8, "500", "coal"),
    ],
  },
];
recipes.push(...additionalRecipes);
var intermediateRecipes = [
  {
    id: "planks",
    name: "Logs \u2192 Planks",
    product: "Spruce planks",
    outputId: "spruce-plank",
    outputCount: 4,
    ingredients: [ingredient("spruce-log", "Spruce logs", 1, "100", "log")],
  },
  {
    id: "plain-book",
    name: "Paper + Leather \u2192 Books",
    product: "Books",
    outputId: "book",
    outputCount: 1,
    ingredients: [
      ingredient("paper", "Paper", 3, "10", "paper"),
      ingredient("leather", "Leather", 1, "50", "hide"),
    ],
  },
];
function resolveRecipe(id, variant) {
  const base = [...recipes, ...intermediateRecipes].find((r) => r.id === id);
  if (!base) throw new Error("Unknown recipe.");
  const selected =
    base.variants?.find((v) => v.id === variant) || base.variants?.[0];
  return selected
    ? {
        ...base,
        ...selected,
        id: base.id,
        variant: selected.id,
        product: selected.product || selected.name,
        variants: base.variants,
      }
    : { ...base };
}
function allRecipes() {
  return recipes.flatMap((r) =>
    r.variants
      ? r.variants.map((v) => resolveRecipe(r.id, v.id))
      : [resolveRecipe(r.id)],
  );
}
var producers = Object.fromEntries(
  [...intermediateRecipes, recipes.find((r) => r.id === "smelting")].map(
    (r) => [r.outputId, r.id],
  ),
);
var materials = [
  ...new Map(
    [...allRecipes(), ...intermediateRecipes]
      .flatMap((r) => r.ingredients)
      .map((i) => [i.id, i]),
  ).values(),
];

function finite(value, label = "Value") {
  if (!Number.isFinite(value) || value < 0)
    throw new Error(`${label} must be a nonnegative, finite number.`);
  if (value > Number.MAX_SAFE_INTEGER)
    throw new Error(`${label} is too large to calculate accurately.`);
  return value;
}
var whole = (value, label) => {
  finite(value, label);
  if (!Number.isSafeInteger(value))
    throw new Error(
      `${label} must be a whole number within the supported range.`,
    );
  return value;
};
// Totals use reduced BigInt fractions. Conversion to Number happens only at the
// public result boundary, so dividing stack/shulker prices cannot lose money.
const EXACT_PRICES = Symbol("exact-price-values");
const MISSING_PRICES = Symbol("missing-inventory-prices");
function gcd(a, b) {
  a = a < 0n ? -a : a;
  while (b) {
    const next = a % b;
    a = b;
    b = next;
  }
  return a || 1n;
}
function fraction(value) {
  if (Array.isArray(value)) return value;
  const text = String(value);
  if (text.includes("/")) {
    const [n, d] = text.split("/");
    return reduced(BigInt(n), BigInt(d));
  }
  const match = text.match(/^(-?)(\d+)(?:\.(\d+))?(?:e([+-]?\d+))?$/i);
  if (!match) throw Error("Invalid exact money value.");
  const digits = (match[3] || "").length,
    exponent = Number(match[4] || 0) - digits;
  let n = BigInt(match[2] + (match[3] || "")) * (match[1] ? -1n : 1n),
    d = 1n;
  if (exponent >= 0) n *= 10n ** BigInt(exponent);
  else d = 10n ** BigInt(-exponent);
  return reduced(n, d);
}
function reduced(n, d) {
  if (!d) throw Error("Cannot divide money by zero.");
  if (d < 0n) {
    n = -n;
    d = -d;
  }
  const divisor = gcd(n, d);
  return [n / divisor, d / divisor];
}
function addMoney(a, b) {
  a = fraction(a);
  b = fraction(b);
  return reduced(a[0] * b[1] + b[0] * a[1], a[1] * b[1]);
}
function subtractMoney(a, b) {
  b = fraction(b);
  return addMoney(a, [-b[0], b[1]]);
}
function multiplyMoney(a, b) {
  a = fraction(a);
  b = fraction(b);
  return reduced(a[0] * b[0], a[1] * b[1]);
}
function divideMoney(a, b) {
  b = fraction(b);
  return multiplyMoney(a, [b[1], b[0]]);
}
function exactString(value) {
  const [n, d] = fraction(value);
  return n.toString() + "/" + d.toString();
}
function derivedMoneyNumber(value) {
  const [n, d] = fraction(value);
  return Number(n) / Number(d);
}
function moneyNumber(value) {
  const [n, d] = fraction(value);
  if ((n < 0n ? -n : n) > BigInt(Number.MAX_SAFE_INTEGER) * d)
    throw Error("Money total is too large to calculate accurately.");
  return Number(n) / Number(d);
}
function priceFraction(prices, id) {
  return prices[EXACT_PRICES]?.[id] || fraction(prices[id]);
}
function normalizePrices(recipe, entries, options = {}) {
  const result = {},
    exact = {};
  for (const i of recipe.ingredients) {
    const entry = entries[i.id],
      raw = typeof entry === "object" ? entry?.value : entry;
    if (raw === undefined || raw === "") {
      if (
        options.inventoryEnabled &&
        parseAmount(options.inventory?.[i.id] || "0") > 0
      ) {
        result[i.id] = 0;
        exact[i.id] = fraction(0);
        continue;
      }
      throw Error("Enter a price for " + i.name + ".");
    }
    const unit = typeof entry === "object" ? Number(entry.unit || 1) : 1;
    if (![1, 64, 1728].includes(unit))
      throw Error("Invalid material price unit.");
    const amount = finite(parseAmount(raw), i.name + " price");
    exact[i.id] = divideMoney(amount, unit);
    result[i.id] = moneyNumber(exact[i.id]);
  }
  Object.defineProperty(result, EXACT_PRICES, { value: exact });
  Object.defineProperty(result, MISSING_PRICES, {
    value: new Set(
      recipe.ingredients
        .filter(
          (i) =>
            options.inventoryEnabled &&
            !(typeof entries[i.id] === "object"
              ? entries[i.id]?.value
              : entries[i.id]),
        )
        .map((i) => i.id),
    ),
  });
  return result;
}
function productionCost(recipe, batches, prices) {
  whole(batches, "Crafting batches");
  let total = fraction(0);
  const rows = recipe.ingredients.map((i) => {
    const quantity = whole(
      recipe.specialRules === "wholeFuel"
        ? Math.ceil(i.count * batches)
        : i.count * batches,
      i.name + " quantity",
    );
    const unitPrice = finite(prices[i.id], i.name + " price"),
      exact = multiplyMoney(priceFraction(prices, i.id), quantity);
    total = addMoney(total, exact);
    return {
      ...i,
      quantity,
      unitPrice,
      cost: moneyNumber(exact),
      exactCost: exactString(exact),
    };
  });
  return { cost: moneyNumber(total), exactCost: exactString(total), rows };
}
function calculate(recipe, input, prices, costHook) {
  const amount = finite(parseAmount(input.amount), "Quantity or budget"),
    budget = input.orderMode === "budget";
  const stock = input.inventoryEnabled ? input.inventory || {} : {};
  const owned = (id) =>
    whole(parseAmount(stock[id] || "0"), "Owned material quantity");
  if (input.inventoryEnabled && input.totalCost)
    throw Error("Clear the order-cost override to use inventory mode.");
  if (!budget) whole(amount, "Quantity");
  const quantityUnit = recipe.stackable ? Number(input.quantityUnit || 1) : 1,
    sellUnit = recipe.stackable ? Number(input.sellUnit || 1) : 1;
  if (
    ![1, 64, recipe.shulkerCapacity || 1728].includes(quantityUnit) ||
    ![1, 64, recipe.shulkerCapacity || 1728].includes(sellUnit)
  )
    throw Error("Invalid quantity or selling unit.");
  const saleExact = divideMoney(
      finite(parseAmount(input.sell), "Selling price"),
      sellUnit,
    ),
    sale = moneyNumber(saleExact);
  let crafted,
    cost,
    rows,
    batches,
    requested,
    exactCost,
    leftovers = 0,
    steps = [];
  const materialOrder = recipe.specialRules === "materialOrder";
  if (materialOrder) {
    const i = recipe.ingredients[0],
      ratio = i.count,
      price = finite(prices[i.id], i.name + " price"),
      unitExact = priceFraction(prices, i.id),
      total = input.totalCost !== undefined && input.totalCost !== "";
    if (budget && (price <= 0 || total))
      throw Error(
        "Budget mode needs a per-item purchase price greater than zero.",
      );
    const affordable = budget ? divideMoney(amount, unitExact) : null;
    requested = whole(
      budget
        ? Number(affordable[0] / affordable[1]) + owned(i.id)
        : amount * quantityUnit,
      "Material quantity",
    );
    crafted = Math.floor(requested / ratio);
    leftovers = requested % ratio;
    const bought = total
      ? fraction(finite(parseAmount(input.totalCost), "Order cost"))
      : multiplyMoney(Math.max(0, requested - owned(i.id)), unitExact);
    if (requested > owned(i.id) && prices[MISSING_PRICES]?.has(i.id))
      throw Error("Enter a price for missing " + i.name + ".");
    cost = moneyNumber(bought);
    exactCost = exactString(bought);
    rows = [
      {
        ...i,
        quantity: Math.max(0, requested - owned(i.id)),
        requiredQuantity: requested,
        ownedQuantity: Math.min(requested, owned(i.id)),
        unitPrice: requested ? cost / requested : price,
        cost,
        exactCost,
      },
    ];
    batches = crafted;
  } else {
    requested = budget
      ? amount
      : whole(amount * quantityUnit, "Requested quantity");
    const output = recipe.outputCount || 1,
      costFor = (count) => {
        const result = costHook
          ? costHook(recipe, count, prices)
          : productionCost(recipe, count, prices);
        return input.inventoryEnabled
          ? inventoryCost(result, stock, prices)
          : result;
      };
    const affordable = (count) => {
      try {
        const result = costFor(count),
          difference = subtractMoney(result.exactCost || result.cost, amount);
        return difference[0] <= 0n;
      } catch {
        return false;
      }
    };
    if (budget) {
      const one = costFor(1).cost;
      if (one <= 0 && !input.inventoryEnabled)
        throw Error("Budget mode needs a material cost greater than zero.");
      let low = 0,
        high = Math.min(
          Math.floor(Number.MAX_SAFE_INTEGER / output),
          one > 0 ? Math.floor(amount / one) + 1 : 1,
        );
      while (
        high < Math.floor(Number.MAX_SAFE_INTEGER / output) &&
        affordable(high)
      ) {
        low = high;
        high = Math.min(Math.floor(Number.MAX_SAFE_INTEGER / output), high * 2);
      }
      while (low < high) {
        const mid = low + Math.ceil((high - low) / 2);
        if (affordable(mid)) low = mid;
        else high = mid - 1;
      }
      batches = low;
    } else batches = Math.ceil(requested / output);
    crafted = whole(batches * output, "Crafted quantity");
    ({ cost, rows, steps = [], exactCost } = costFor(batches));
  }
  const costValue = fraction(exactCost || cost),
    revenueValue = multiplyMoney(crafted, saleExact),
    revenue = moneyNumber(revenueValue),
    beforeValue = subtractMoney(revenueValue, costValue),
    profitBeforeFees = moneyNumber(beforeValue),
    fees = input.fees || {};
  const percent = fees.enabled
    ? finite(parseAmount(fees.percent || "0"), "Fee percentage")
    : 0;
  if (percent > 100) throw Error("Sell fee cannot exceed 100%.");
  const listings = fees.enabled
    ? whole(parseAmount(fees.listings || "1"), "Listing count")
    : 0;
  const flatValue = multiplyMoney(
      fees.enabled ? finite(parseAmount(fees.flat || "0"), "Listing fee") : 0,
      listings,
    ),
    flatFee = moneyNumber(flatValue),
    feeValue = addMoney(
      divideMoney(multiplyMoney(revenueValue, percent), 100),
      flatValue,
    ),
    feeCost = moneyNumber(feeValue),
    profitValue = subtractMoney(beforeValue, feeValue),
    profit = moneyNumber(profitValue),
    factor = divideMoney(subtractMoney(100, percent), 100);
  const breakEven =
    crafted && percent < 100
      ? derivedMoneyNumber(
          divideMoney(
            addMoney(costValue, flatValue),
            multiplyMoney(crafted, factor),
          ),
        )
      : null;
  return {
    recipeId: recipe.id,
    variant: recipe.variant,
    crafted,
    batches,
    requested,
    leftovers,
    cost,
    rows,
    steps,
    revenue,
    sale,
    feesEnabled: Boolean(fees.enabled),
    feeCost,
    flatFee,
    feePercent: percent,
    profitBeforeFees,
    profit,
    returnPercent: cost > 0 ? (profit / cost) * 100 : null,
    profitPerItem: crafted ? profit / crafted : null,
    breakEven,
    unspent: budget ? moneyNumber(subtractMoney(amount, costValue)) : 0,
    rounded: !budget && !materialOrder && crafted > requested,
    exact: {
      cost: exactString(costValue),
      revenue: exactString(revenueValue),
      feeCost: exactString(feeValue),
      profit: exactString(profitValue),
    },
  };
}
function targetPrice(result, returnPercent) {
  finite(returnPercent, "Target return");
  const factor = 1 - result.feePercent / 100;
  return result.crafted && factor > 0
    ? (result.cost * (1 + returnPercent / 100) + result.flatFee) /
        (result.crafted * factor)
    : null;
}

function chainCostHook(entries, choices) {
  const buyExact = (id, quantity) =>
    multiplyMoney(
      quantity,
      divideMoney(
        parseAmount(
          typeof entries[id] === "object" ? entries[id].value : entries[id],
        ),
        Number(entries[id]?.unit || 1),
      ),
    );
  function priceFor(id, required = true) {
    const p = entries[id];
    const value =
      parseAmount(typeof p === "object" ? p?.value : p) / Number(p?.unit || 1);
    if (!Number.isFinite(value) || value < 0) {
      if (!required) return null;
      throw new Error(`Enter a shared price for ${id.replace(/-/g, " ")}.`);
    }
    return value;
  }
  return function produce(
    recipe,
    batches,
    _prices,
    seen = /* @__PURE__ */ new Set(),
  ) {
    if (seen.has(recipe.outputId))
      throw new Error("This chain contains a cycle.");
    const next = /* @__PURE__ */ new Set([...seen, recipe.outputId]);
    const steps = [],
      leafRows = [];
    let exactTotal = fraction(0);
    for (const i of recipe.ingredients) {
      const quantity =
        recipe.specialRules === "wholeFuel"
          ? Math.ceil(i.count * batches)
          : i.count * batches;
      if (!Number.isSafeInteger(quantity))
        throw new Error("Ingredient quantity is too large.");
      const producer =
        ["craft", "auto"].includes(choices[i.id]) && producers[i.id]
          ? resolveRecipe(producers[i.id])
          : null;
      const buyPrice = priceFor(i.id, !producer);
      if (producer) {
        const childBatches = Math.ceil(quantity / producer.outputCount);
        let child;
        try {
          child = produce(producer, childBatches, {}, next);
        } catch (error) {
          if (choices[i.id] !== "auto" || buyPrice === null) throw error;
        }
        if (
          choices[i.id] === "auto" &&
          buyPrice !== null &&
          (!child ||
            subtractMoney(child.exactCost, buyExact(i.id, quantity))[0] >= 0n)
        ) {
          const exact = buyExact(i.id, quantity);
          exactTotal = addMoney(exactTotal, exact);
          leafRows.push({
            ...i,
            quantity,
            unitPrice: buyPrice,
            cost: moneyNumber(exact),
            exactCost: exactString(exact),
          });
          steps.push({
            name: i.name + " · Buy",
            quantity,
            needed: quantity,
            leftover: 0,
            cost: moneyNumber(exact),
            buyCost: moneyNumber(exact),
            route: "buy",
          });
          continue;
        }
        exactTotal = addMoney(exactTotal, child.exactCost || child.cost);
        leafRows.push(...child.rows);
        steps.push(...child.steps, {
          name: producer.name,
          quantity: childBatches * producer.outputCount,
          needed: quantity,
          leftover: childBatches * producer.outputCount - quantity,
          cost: child.cost,
          buyCost: buyPrice === null ? null : quantity * buyPrice,
        });
      } else {
        const row = {
          ...i,
          quantity,
          unitPrice: buyPrice,
          cost: moneyNumber(
            multiplyMoney(
              quantity,
              divideMoney(
                parseAmount(
                  typeof entries[i.id] === "object"
                    ? entries[i.id].value
                    : entries[i.id],
                ),
                Number(entries[i.id]?.unit || 1),
              ),
            ),
          ),
          exactCost: exactString(
            multiplyMoney(
              quantity,
              divideMoney(
                parseAmount(
                  typeof entries[i.id] === "object"
                    ? entries[i.id].value
                    : entries[i.id],
                ),
                Number(entries[i.id]?.unit || 1),
              ),
            ),
          ),
        };
        leafRows.push(row);
        exactTotal = addMoney(exactTotal, row.exactCost);
      }
    }
    const cost = moneyNumber(exactTotal);
    if (!Number.isFinite(cost) || cost > Number.MAX_SAFE_INTEGER)
      throw new Error("Chain cost is too large.");
    const grouped = /* @__PURE__ */ new Map();
    for (const r of leafRows) {
      const old = grouped.get(r.id);
      if (old) {
        old.quantity += r.quantity;
        old.exactCost = exactString(
          addMoney(old.exactCost || old.cost, r.exactCost || r.cost),
        );
        old.cost = moneyNumber(old.exactCost);
      } else grouped.set(r.id, { ...r });
    }
    return {
      cost,
      exactCost: exactString(exactTotal),
      rows: [...grouped.values()],
      steps,
    };
  };
}

var priceKey = (recipe) => recipe.id + ":" + (recipe.variant || "");
function loadExamples(state, now = /* @__PURE__ */ new Date().toISOString()) {
  for (const recipe of allRecipes()) {
    for (const i of recipe.ingredients)
      if (!state.prices[i.id]?.value)
        state.prices[i.id] = {
          value: i.example,
          unit: "1",
          updated: now,
          example: true,
        };
    const key = priceKey(recipe);
    if (!state.sells[key]?.value)
      state.sells[key] = {
        value: recipe.exampleSell,
        unit: "1",
        updated: now,
        example: true,
      };
  }
  for (const [id, data] of Object.entries(state.inputs)) {
    const sell = state.sells[id + ":" + (data.variant || "")];
    if (!data.sell && sell) {
      data.sell = sell.value;
      data.sellUnit = sell.unit;
    }
  }
  return state;
}
function clearExamples(state) {
  for (const kind of ["prices", "sells"])
    for (const [key, entry] of Object.entries(state[kind]))
      if (entry.example) {
        delete state[kind][key];
        if (kind === "sells") {
          const [id, variant] = key.split(":");
          const data = state.inputs[id];
          if (data && (data.variant || "") === variant) {
            data.sell = "";
            data.sellUnit = "1";
          }
        }
      }
}
function hasExamples(state) {
  return [...Object.values(state.prices), ...Object.values(state.sells)].some(
    (p) => p.example,
  );
}
const editSessions = new WeakMap();
function editPrice(
  state,
  kind,
  id,
  value,
  unit = "1",
  now = new Date().toISOString(),
) {
  return updatePrice(state, kind, id, value, unit, now, { coalesce: true });
}
function updatePrice(
  state,
  kind,
  id,
  value,
  unit = "1",
  now = /* @__PURE__ */ new Date().toISOString(),
  options = {},
) {
  const old = state[kind][id];
  let history = old?.history || [];
  if (!history.length && old?.value && old.updated)
    history = [
      {
        value: old.value,
        unit: old.unit,
        updated: old.updated,
        example: old.example,
      },
    ];
  if (
    Number.isFinite(parseAmount(value)) &&
    parseAmount(value) >= 0 &&
    (old?.value !== value || old?.unit !== unit)
  ) {
    const changes = editSessions.get(state) || new Map();
    editSessions.set(state, changes);
    const key = kind + ":" + id,
      last = changes.get(key),
      time = Date.parse(now),
      entry = { value, unit, updated: now, example: false };
    if (
      options.coalesce &&
      last !== undefined &&
      time - last >= 0 &&
      time - last < 3000 &&
      history.length
    )
      history = [...history.slice(0, -1), entry];
    else history = [...history, entry].slice(-50);
    if (options.coalesce) changes.set(key, time);
    else changes.delete(key);
  }
  state[kind][id] = { value, unit, updated: now, example: false, history };
  if (kind === "sells") {
    const [mode, variant] = id.split(":");
    const data = state.inputs[mode];
    if (data && (data.variant || "") === variant) {
      data.sell = value;
      data.sellUnit = unit;
    }
  }
  return state[kind][id];
}
function priceChange(entry) {
  const hist = entry.history || [];
  if (hist.length < 2) return null;
  const previous = hist[hist.length - 2],
    before = parseAmount(previous.value) / Number(previous.unit || 1),
    current = parseAmount(entry.value) / Number(entry.unit || 1);
  return before > 0 && Number.isFinite(current)
    ? ((current - before) / before) * 100
    : null;
}
function missingPrices(recipe, state) {
  const missing = recipe.ingredients
    .filter(
      (i) =>
        !Number.isFinite(parseAmount(state.prices[i.id]?.value)) ||
        parseAmount(state.prices[i.id]?.value) < 0,
    )
    .map((i) => ({ id: "book-" + i.id, name: i.name }));
  if (!Number.isFinite(parseAmount(state.sells[priceKey(recipe)]?.value)))
    missing.push({ id: "sale-" + priceKey(recipe), name: "Selling price" });
  return missing;
}

function dropTolerance(result) {
  return result.sale > 0 && result.breakEven !== null
    ? ((result.sale - result.breakEven) / result.sale) * 100
    : null;
}
function combineTrades(items) {
  const rows = /* @__PURE__ */ new Map(),
    totals = { cost: 0, revenue: 0, profit: 0, fees: 0 },
    exactTotals = {
      cost: fraction(0),
      revenue: fraction(0),
      profit: fraction(0),
      fees: fraction(0),
    };
  for (const item of items) {
    const r = item.result;
    for (const [key, field] of [
      ["cost", "cost"],
      ["revenue", "revenue"],
      ["profit", "profit"],
      ["fees", "feeCost"],
    ])
      exactTotals[key] = addMoney(
        exactTotals[key],
        r.exact?.[field] || r[field],
      );
    for (const row of r.rows) {
      const existing = rows.get(row.id);
      if (existing) {
        existing.quantity += row.quantity;
        existing.exactCost = exactString(
          addMoney(
            existing.exactCost || existing.cost,
            row.exactCost || row.cost,
          ),
        );
        existing.cost = moneyNumber(existing.exactCost);
      } else rows.set(row.id, { ...row });
    }
  }
  for (const key of Object.keys(totals))
    totals[key] = moneyNumber(exactTotals[key]);
  if (
    !Object.values(totals).every(
      (v) => Number.isFinite(v) && Math.abs(v) <= Number.MAX_SAFE_INTEGER,
    ) ||
    [...rows.values()].some((r) => !Number.isSafeInteger(r.quantity))
  )
    throw Error("Combined plan is too large.");
  return {
    ...totals,
    exact: Object.fromEntries(
      Object.entries(exactTotals).map(([key, v]) => [key, exactString(v)]),
    ),
    rows: [...rows.values()],
    items,
  };
}
function evaluatePlan(plan) {
  let remaining;
  return combineTrades(
    plan.items.map((item) => {
      const recipe = resolveRecipe(item.recipeId, item.variant);
      let data = item.input;
      if (data.inventoryEnabled) {
        remaining ||= { ...data.inventory };
        data = { ...data, inventory: remaining };
      }
      const result = calculate(
        recipe,
        data,
        normalizePrices(recipe, item.prices, data),
      );
      if (data.inventoryEnabled)
        for (const row of result.rows)
          remaining[row.id] = String(
            Math.max(
              0,
              parseAmount(remaining[row.id] || "0") - (row.ownedQuantity || 0),
            ),
          );
      return {
        ...item,
        recipe,
        result,
      };
    }),
  );
}
function bulkPlan(
  state,
  { budget, count = 3, cap = Infinity, fees = { enabled: false } },
) {
  if (
    !Number.isFinite(budget) ||
    budget < 0 ||
    budget > Number.MAX_SAFE_INTEGER
  )
    throw Error("Enter a nonnegative, supported budget.");
  if (!Number.isSafeInteger(count) || count < 1 || count > 10)
    throw Error("Choose between 1 and 10 recipes.");
  if (cap !== Infinity && (!Number.isFinite(cap) || cap <= 0))
    throw Error("Per-recipe spending cap must be greater than zero.");
  const candidates = [];
  for (const recipe of allRecipes())
    try {
      const sell = state.sells[priceKey(recipe)],
        prices = normalizePrices(recipe, state.prices);
      if (!sell) continue;
      const amount =
        recipe.specialRules === "materialOrder"
          ? recipe.ingredients[0].count * recipe.shulkerCapacity
          : recipe.shulkerCapacity;
      const result = calculate(
        recipe,
        { amount: String(amount), sell: sell.value, sellUnit: sell.unit, fees },
        prices,
      );
      if (result.returnPercent > 0)
        candidates.push({
          recipe,
          sell,
          prices,
          returnPercent: result.returnPercent,
        });
    } catch {}
  candidates.sort((a, b) => b.returnPercent - a.returnPercent);
  const selected = candidates.slice(0, count),
    items = [];
  let remaining = budget;
  for (const [index, candidate] of selected.entries()) {
    const allocation = Math.min(cap, remaining / (selected.length - index));
    const input = {
      amount: String(allocation),
      orderMode: "budget",
      quantityUnit: "1",
      sell: candidate.sell.value,
      sellUnit: candidate.sell.unit,
      fees,
    };
    const result = calculate(candidate.recipe, input, candidate.prices);
    if (result.crafted && result.profit > 0) {
      remaining -= result.cost;
      items.push({
        recipeId: candidate.recipe.id,
        variant: candidate.recipe.variant,
        recipe: candidate.recipe,
        input,
        prices: state.prices,
        result,
      });
    }
  }
  const combined = combineTrades(items);
  return { ...combined, unspent: budget - combined.cost };
}

async function encodePayload(payload) {
  const raw = JSON.stringify(payload);
  if (typeof CompressionStream === "undefined")
    return "j" + encodeURIComponent(raw);
  const bytes = new Uint8Array(
    await new Response(
      new Blob([raw]).stream().pipeThrough(new CompressionStream("gzip")),
    ).arrayBuffer(),
  );
  return (
    "z" +
    btoa(Array.from(bytes, (b) => String.fromCharCode(b)).join(""))
      .replaceAll("+", "-")
      .replaceAll("/", "_")
      .replace(/=+$/, "")
  );
}
async function decodePayload(encoded) {
  if (encoded.length > 64e3) throw Error("Link is too large.");
  if (encoded[0] === "j")
    return JSON.parse(decodeURIComponent(encoded.slice(1)));
  if (encoded[0] !== "z" || typeof DecompressionStream === "undefined")
    throw Error("Use the JSON file in this browser.");
  const binary = atob(
    encoded.slice(1).replaceAll("-", "+").replaceAll("_", "/"),
  );
  const stream = new Blob([Uint8Array.from(binary, (c) => c.charCodeAt(0))])
    .stream()
    .pipeThrough(new DecompressionStream("gzip"));
  const reader = stream.getReader();
  let size = 0,
    parts = [];
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      size += value.byteLength;
      if (size > 2e6) throw Error("Expanded link is too large.");
      parts.push(value);
    }
  } finally {
    await reader.cancel();
  }
  return JSON.parse(await new Blob(parts).text());
}
export {
  fraction,
  addMoney,
  subtractMoney,
  multiplyMoney,
  divideMoney,
  moneyNumber,
  exactString,
  editPrice,
  allRecipes,
  bulkPlan,
  calculate,
  chainCostHook,
  clearExamples,
  combineTrades,
  decodePayload,
  dropTolerance,
  encodePayload,
  evaluatePlan,
  formatMoney,
  hasExamples,
  intermediateRecipes,
  loadExamples,
  materials,
  missingPrices,
  money,
  normalizePrices,
  number,
  parseAmount,
  priceChange,
  priceKey,
  producers,
  productionCost,
  recipes,
  resolveRecipe,
  setCompactMoney,
  targetPrice,
  updatePrice,
  validateAmount,
};

function inventoryCost(result, stock, prices) {
  let exact = fraction(0);
  const rows = result.rows.map((row) => {
    const owned = Math.min(
      row.quantity,
      whole(parseAmount(stock[row.id] || "0"), "Owned material quantity"),
    );
    const missing = row.quantity - owned;
    if (missing && prices[MISSING_PRICES]?.has(row.id))
      throw Error("Enter a price for missing " + row.name + ".");
    const cost = row.quantity
      ? multiplyMoney(
          divideMoney(row.exactCost || row.cost, row.quantity),
          missing,
        )
      : fraction(0);
    exact = addMoney(exact, cost);
    return {
      ...row,
      requiredQuantity: row.quantity,
      ownedQuantity: owned,
      quantity: missing,
      cost: moneyNumber(cost),
      exactCost: exactString(cost),
    };
  });
  return {
    ...result,
    rows,
    cost: moneyNumber(exact),
    exactCost: exactString(exact),
  };
}
function actualTradeProfit(trade) {
  if (trade.actualSell === undefined || trade.actualSell === "") return null;
  const revenue = multiplyMoney(
    whole(trade.quantity, "Sold quantity"),
    finite(parseAmount(trade.actualSell), "Actual sold price"),
  );
  const fees = trade.snapshot?.fees;
  const fee = fees?.enabled
    ? addMoney(
        divideMoney(
          multiplyMoney(
            revenue,
            finite(parseAmount(fees.percent || "0"), "Sell fee"),
          ),
          100,
        ),
        multiplyMoney(
          finite(parseAmount(fees.flat || "0"), "Listing fee"),
          whole(parseAmount(fees.listings || "1"), "Listing count"),
        ),
      )
    : fraction(trade.fees || 0);
  return moneyNumber(
    subtractMoney(subtractMoney(revenue, trade.exact?.cost || trade.cost), fee),
  );
}
function rankingValue(result, mode, rate) {
  if (mode === "returnPercent") return result.returnPercent;
  if (mode === "profitHour") {
    const hourly = parseAmount(rate || "");
    return Number.isFinite(hourly) && hourly > 0
      ? result.profitPerItem * hourly
      : null;
  }
  return result[mode] ?? null;
}
function snapshotBook(state, name, id, date = new Date().toISOString()) {
  if (!name.trim()) throw Error("Name this price snapshot.");
  const copy = (entries) =>
    Object.fromEntries(
      Object.entries(entries).map(([key, p]) => [
        key,
        {
          value: p.value,
          unit: p.unit,
          updated: p.updated,
          example: p.example,
        },
      ]),
    );
  return {
    id,
    name: name.trim().slice(0, 200),
    date,
    prices: copy(state.prices),
    sells: copy(state.sells),
  };
}
function bookDiff(before, after) {
  const changes = [];
  for (const kind of ["prices", "sells"])
    for (const id of new Set([
      ...Object.keys(before[kind] || {}),
      ...Object.keys(after[kind] || {}),
    ])) {
      const a = before[kind]?.[id],
        b = after[kind]?.[id];
      const price = (p) =>
        p && p.value !== "" ? parseAmount(p.value) / Number(p.unit || 1) : null;
      const old = price(a),
        value = price(b);
      if (Object.is(old, value)) continue;
      changes.push({
        kind,
        id,
        before: old,
        after: value,
        change: old > 0 && value !== null ? ((value - old) / old) * 100 : null,
      });
    }
  return changes;
}
function parseBulkPrices(text) {
  const aliases = new Map();
  for (const item of materials)
    for (const label of [item.id, item.name])
      aliases.set(label.toLowerCase(), ["prices", item.id, item.name]);
  for (const recipe of allRecipes())
    for (const label of [priceKey(recipe), recipe.product])
      aliases.set("sell:" + label.toLowerCase(), [
        "sells",
        priceKey(recipe),
        recipe.product,
      ]);
  const rows = [],
    errors = [],
    seen = new Set();
  if (text.length > 100000)
    return { rows, errors: ["Paste is too large (100 KB maximum)."] };
  for (const [index, line] of text.split(/\r?\n/).entries()) {
    if (!line.trim()) continue;
    try {
      let item,
        value,
        unit = "1";
      if (line.includes(",")) {
        const cells =
          line
            .match(/(?:"(?:[^"]|"")*"|[^,]*)(?:,|$)/g)
            ?.filter(Boolean)
            .map((c) =>
              c
                .replace(/,$/, "")
                .trim()
                .replace(/^"|"$/g, "")
                .replace(/""/g, '"'),
            ) || [];
        [item, value, unit = "1"] = cells;
        if (cells.length > 3) throw Error("Use item,price,unit.");
      } else {
        const match = line.trim().match(/^(.*?)\s+([^\s]+)$/);
        if (!match) throw Error("Use item price or item,price,unit.");
        [, item, value] = match;
      }
      if (/^(item|material)$/i.test(item) && /^price$/i.test(value)) continue;
      const record = aliases.get(item.trim().toLowerCase());
      if (!record) throw Error("Unknown item: " + item);
      const units = { item: "1", stack: "64", shulker: "1728" };
      unit = units[unit.toLowerCase()] || unit;
      if (!["1", "64", "1728"].includes(unit))
        throw Error("Unit must be 1, 64, or 1728.");
      finite(parseAmount(value), "Price");
      const key = record[0] + ":" + record[1];
      if (seen.has(key)) throw Error("Duplicate item: " + item);
      seen.add(key);
      rows.push({
        kind: record[0],
        id: record[1],
        name: record[2],
        value,
        unit,
      });
    } catch (error) {
      errors.push("Line " + (index + 1) + ": " + error.message);
    }
  }
  if (!rows.length && !errors.length)
    errors.push("Paste at least one item price.");
  return { rows, errors };
}
function discordPlan(plan, result) {
  const plain = (value) =>
    String(value)
      .replace(/[\r\n\x60]/g, " ")
      .replace(/@/g, "＠");
  return (
    "**" +
    plain(plan.name) +
    "**\nPurchase: " +
    money(result.cost) +
    " · Revenue: " +
    money(result.revenue) +
    " · Profit: " +
    money(result.profit) +
    "\nShopping list\n" +
    result.rows
      .filter((r) => r.quantity)
      .map(
        (r) =>
          (plan.checked?.includes(r.id) ? "☑" : "☐") +
          " " +
          number(r.quantity) +
          " " +
          plain(r.name) +
          " — " +
          money(r.cost),
      )
      .join("\n")
  );
}
export {
  actualTradeProfit,
  rankingValue,
  snapshotBook,
  bookDiff,
  parseBulkPrices,
  discordPlan,
};
