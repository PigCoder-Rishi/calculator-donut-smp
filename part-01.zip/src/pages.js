import {
  allRecipes,
  parseAmount,
  money,
  number,
  calculate,
  normalizePrices,
  loadExamples,
  clearExamples,
  hasExamples,
  missingPrices,
  setCompactMoney,
  priceChange,
  materials as materials2,
  editPrice as updatePrice,
  resolveRecipe as resolveRecipe3,
  producers as producers3,
  chainCostHook,
  bulkPlan,
  evaluatePlan,
  targetPrice as targetPrice4,
  actualTradeProfit,
  rankingValue,
  snapshotBook,
  bookDiff,
  parseBulkPrices,
  discordPlan,
} from "./core.js";
import {
  node,
  $,
  button,
  makeSelect,
  amountField,
  table,
  download as download2,
  notify,
  metric as metric3,
  clipboard,
} from "./widgets.js";
import {
  state,
  storageBytes,
  persistence,
  pruneHistory,
  input,
  save,
  recipeKey,
  stale,
  hooks,
  sanitizeState,
  replaceState as replaceState3,
  currentRecipe as currentRecipe3,
} from "./state.js";
import { shareBook, bookImport, sharePayload, previewBook } from "./share.js";
import { lineChart } from "./charts.js";

var leaderSort = "profitPerItem";
var minimumReturn = "";
var maximumCapital = "",
  leaderView = "all";
function renderLeaderboard() {
  const page = $("leaderboard-page");
  page.replaceChildren(
    node("h1", "Best Profit"),
    node(
      "p",
      "Ranks saved selling prices against your shared material prices. Estimates use one full output shulker and the current fee settings. Missing prices are never guessed.",
    ),
  );
  const controls = node("div", null, { class: "two-columns" });
  controls.append(
    makeSelect(
      "rank-sort",
      "Sort by",
      [
        ["profitPerItem", "Profit per item"],
        ["returnPercent", "Return (%)"],
        ["stackProfit", "Profit per stack"],
        ["shulkerProfit", "Profit per shulker"],
        ["profitHour", "Profit per hour"],
      ],
      leaderSort,
      (v) => {
        leaderSort = v;
        renderLeaderboard();
      },
    ),
    amountField(
      "minimum-return",
      "Minimum return (%)",
      minimumReturn,
      (v) => {
        minimumReturn = v;
        renderLeaderboardRows();
      },
      { optional: true },
    ),
  );
  controls.append(
    amountField(
      "maximum-capital",
      "Maximum purchase capital ($, per output shulker)",
      maximumCapital,
      (v) => {
        maximumCapital = v;
        renderLeaderboardRows();
      },
      { optional: true },
    ),
    makeSelect(
      "rank-view",
      "Recipes",
      [
        ["all", "All recipes"],
        ["favorites", "Favorites"],
        ["recent", "Recently used"],
      ],
      leaderView,
      (v) => {
        leaderView = v;
        renderLeaderboardRows();
      },
    ),
  );
  page.append(
    node(
      "p",
      "Profit per hour uses the output/hour you enter in each calculator. No production speed is guessed.",
      { class: "hint" },
    ),
  );
  page.append(controls, node("div", null, { id: "ranking" }));
  renderLeaderboardRows();
}
function renderLeaderboardRows() {
  const rows = [],
    missing = [];
  let filter = parseAmount(minimumReturn);
  if (!Number.isFinite(filter)) filter = -Infinity;
  for (const recipe of allRecipes()) {
    const key = recipeKey(recipe);
    if (leaderView === "favorites" && !state.favorites.includes(key)) continue;
    if (leaderView === "recent" && !state.recent.includes(key)) continue;
    try {
      const sell = state.sells[recipeKey(recipe)];
      if (!sell?.value) throw Error();
      const prices = normalizePrices(recipe, state.prices);
      const quantity =
        recipe.specialRules === "materialOrder"
          ? recipe.shulkerCapacity * recipe.ingredients[0].count
          : recipe.shulkerCapacity;
      const r = calculate(
        recipe,
        {
          amount: String(quantity),
          sell: sell.value,
          sellUnit: sell.unit,
          fees: input().fees,
        },
        prices,
      );
      if ((r.returnPercent ?? -Infinity) < filter) continue;
      if (
        maximumCapital.trim() &&
        (!Number.isFinite(parseAmount(maximumCapital)) ||
          r.cost > parseAmount(maximumCapital))
      )
        continue;
      const stackProfit = recipe.stackable ? r.profitPerItem * 64 : null;
      rows.push({
        recipe,
        ...r,
        profitHour: rankingValue(
          r,
          "profitHour",
          state.inputs[recipe.id]?.throughput,
        ),
        stackProfit,
        shulkerProfit: r.profitPerItem * recipe.shulkerCapacity,
        isStale:
          recipe.ingredients.some((i) => stale(state.prices[i.id])) ||
          stale(sell),
      });
    } catch {
      missing.push({ recipe, fields: missingPrices(recipe, state) });
    }
  }
  rows.sort(
    (a, b) => (b[leaderSort] ?? -Infinity) - (a[leaderSort] ?? -Infinity),
  );
  const root = $("ranking");
  root.replaceChildren(
    table(
      [
        "Rank",
        "Recipe",
        "Profit / item",
        "Return",
        "Profit / stack",
        "Profit / shulker",
        "Profit / hour",
        "Favorite",
      ],
      rows.map((r, index) => [
        index + 1,
        r.recipe.product +
          (r.isStale ? " \xB7 stale prices" : "") +
          (r.returnPercent > 0 && r.returnPercent < 10
            ? " \xB7 thin margin"
            : ""),
        money(r.profitPerItem),
        r.returnPercent === null ? "\u2014" : number(r.returnPercent) + "%",
        money(r.stackProfit),
        money(r.shulkerProfit),
        money(r.profitHour),
        favoriteButton(r.recipe),
      ]),
    ),
  );
  root.append(
    node(
      "p",
      rows.length
        ? `${rows.length} ranked. Top three highlighted.`
        : "No complete saved prices yet. Fill in a calculator and selling price first.",
    ),
  );
  const fee = input().fees;
  root.append(
    node(
      "p",
      fee?.enabled
        ? `Fee settings from the current calculator: ${fee.percent}% of revenue, ${money(parseAmount(fee.flat || "0"))} per listing \xD7 ${fee.listings}.`
        : "Fees are disabled in the current calculator; this ranking is before fees.",
      { class: "hint" },
    ),
  );
  if (hasExamples(state))
    root.prepend(
      node(
        "p",
        "EXAMPLE DATA \u2014 placeholder prices, not live market values.",
        { class: "example-banner" },
      ),
      button("Clear example prices", () => {
        clearExamples(state);
        save();
        renderLeaderboard();
      }),
    );
  if (!rows.length)
    root.append(
      button(
        "Load example prices",
        () => {
          loadExamples(state);
          save();
          renderLeaderboard();
        },
        true,
      ),
    );
  if (missing.length) {
    root.append(node("h2", "Complete missing prices"));
    for (const item of missing) {
      const row = node("div", null, { class: "missing-row" });
      row.append(node("strong", item.recipe.product + ": "));
      for (const field of item.fields)
        row.append(
          button(field.name, () => {
            hooks.showPage("prices");
            document.getElementById(field.id)?.focus();
            document
              .getElementById(field.id)
              ?.scrollIntoView?.({ block: "center" });
          }),
        );
      if (!item.fields.length)
        row.append(node("span", "Check invalid price or fee values."));
      root.append(row);
    }
  }
}

function renderPrices() {
  const page = $("prices-page");
  page.replaceChildren(
    node("h1", "Shared Price Book"),
    node(
      "p",
      "Edit a material once to update every calculator that uses it. All prices are yours; no market data is fetched.",
    ),
  );
  page.append(
    node(
      "p",
      "Device data: " +
        number(storageBytes() / 1024) +
        " KB serialized" +
        (persistence.problem
          ? " · storage warning: " + persistence.problem.kind
          : ""),
      { id: "storage-size", class: "hint" },
    ),
  );
  const pruning = node("details");
  pruning.append(
    node("summary", "Prune saved trade history"),
    node(
      "p",
      "Export your data first. This keeps only the newest 1,000 trades and removes older entries.",
    ),
    button("Keep newest 1,000 trades", () => {
      pruneHistory(1000);
      notify("History pruned to " + state.history.length + " trades.");
      renderPrices();
    }),
  );
  page.append(pruning);
  renderBookTools(page);
  page.append(
    makeSelect(
      "compact-money",
      "Money display",
      [
        ["full", "Full amounts"],
        ["compact", "Compact (k / m / b)"],
      ],
      state.compactMoney ? "compact" : "full",
      (v) => {
        state.compactMoney = v === "compact";
        setCompactMoney(state.compactMoney);
        save();
        hooks.recalculate();
        renderPrices();
      },
    ),
  );
  page.append(
    button("Share price book", () => shareBook()),
    button("Export price book JSON", () =>
      download2(
        "donut-price-book.json",
        JSON.stringify(
          {
            type: "book",
            version: 4,
            prices: state.prices,
            sells: state.sells,
          },
          null,
          2,
        ),
        "application/json",
      ),
    ),
    bookImport(),
  );
  page.append(
    button("Load example prices", () => {
      loadExamples(state);
      save();
      renderPrices();
    }),
    button("Clear example prices", () => {
      clearExamples(state);
      save();
      renderPrices();
    }),
  );
  if (hasExamples(state))
    page.append(
      node("p", "Example values are placeholders, not current server prices.", {
        class: "example-banner",
      }),
    );
  page.append(
    amountField(
      "stale-days",
      "Warn when prices are older than (days)",
      String(state.staleDays),
      (v) => {
        const n = parseAmount(v);
        if (Number.isSafeInteger(n) && n >= 1 && n <= 365) {
          state.staleDays = n;
          save();
        }
      },
      { whole: true },
    ),
  );
  const grid = node("div", null, { class: "price-grid" });
  for (const material of materials2) {
    const entry = state.prices[material.id] || { value: "", unit: "1" };
    const card = node("section", null, { class: "card" });
    const stamp = node(
      "p",
      entry.updated
        ? "Updated " + new Date(entry.updated).toLocaleString()
        : "No saved price",
      { class: "hint" },
    );
    if (stale(entry))
      stamp.append(document.createTextNode(" \xB7 Price may be stale"));
    if (entry.example) stamp.append(document.createTextNode(" \xB7 EXAMPLE"));
    card.append(
      amountField(
        "book-" + material.id,
        material.name + " ($)",
        entry.value,
        (v) => {
          updatePrice(
            state,
            "prices",
            material.id,
            v,
            state.prices[material.id]?.unit || "1",
          );
          stamp.textContent =
            "Updated " + /* @__PURE__ */ new Date().toLocaleString();
          save();
        },
        {
          units: [
            ["1", "Per item"],
            ["64", "Per stack"],
            ["1728", "Per shulker"],
          ],
          unit: entry.unit,
          onUnit: (v) => {
            updatePrice(
              state,
              "prices",
              material.id,
              state.prices[material.id]?.value || "",
              v,
            );
            save();
          },
        },
      ),
      stamp,
    );
    card.append(priceHistory(entry));
    grid.append(card);
  }
  page.append(grid);
  page.append(
    node("h2", "Sell Prices"),
    node("p", "Set sale prices for each finished recipe or variant here."),
  );
  const sells = node("div", null, { class: "price-grid" });
  for (const recipe of allRecipes()) {
    const key = recipeKey(recipe),
      entry = state.sells[key] || { value: "", unit: "1" },
      card = node("section", null, { class: "card" });
    const stamp = node(
      "p",
      (entry.updated
        ? "Updated " + new Date(entry.updated).toLocaleString()
        : "No saved price") +
        (entry.example ? " \xB7 EXAMPLE" : "") +
        (stale(entry) ? " \xB7 Price may be stale" : ""),
      { class: "hint" },
    );
    card.append(
      amountField(
        "sale-" + key,
        recipe.product + " selling price ($)",
        entry.value,
        (v) => {
          updatePrice(state, "sells", key, v, state.sells[key]?.unit || "1");
          stamp.textContent =
            "Updated " + /* @__PURE__ */ new Date().toLocaleString();
          save();
        },
        {
          units: recipe.stackable
            ? [
                ["1", "Per item"],
                ["64", "Per stack"],
                ["1728", "Per shulker"],
              ]
            : void 0,
          unit: entry.unit,
          onUnit: (v) => {
            updatePrice(state, "sells", key, state.sells[key]?.value || "", v);
            save();
          },
        },
      ),
      stamp,
    );
    card.append(priceHistory(entry));
    sells.append(card);
  }
  page.append(sells);
}
function priceHistory(entry) {
  const wrap = node("div"),
    change = priceChange(entry);
  if (change !== null)
    wrap.append(
      node("p", "Changed " + number(change) + "% since last update", {
        class: "hint",
      }),
    );
  const history = entry.history || [];
  if (!history.length) {
    wrap.append(
      node("p", "Price history appears after your first update.", {
        class: "hint",
      }),
    );
    return wrap;
  }
  wrap.append(
    lineChart(
      history.map((h, index) => ({
        x: index + 1,
        y: parseAmount(h.value) / Number(h.unit || 1),
      })),
      { title: "Price per item history", xLabel: "Update" },
    ),
  );
  const details = node("details");
  details.append(
    node("summary", "Recent price updates"),
    table(
      ["Updated", "Price / item"],
      history
        .slice(-5)
        .map((h) => [
          new Date(h.updated).toLocaleString(),
          money(parseAmount(h.value) / Number(h.unit || 1)),
        ]),
    ),
  );
  wrap.append(details);
  return wrap;
}

var getResult = (...args) => hooks.getResult(...args);
var recalculate = (...args) => hooks.recalculate(...args);
var historyFilter = "All sessions";
var historyUndo = null;
function safeActual(trade) {
  try {
    return actualTradeProfit(trade);
  } catch {
    return null;
  }
}
function tradeActions(trade) {
  const actions = node("div", null, { class: "toolbar" });
  actions.append(
    button("Edit " + trade.name, () => editTrade(trade)),
    button("Delete " + trade.name, () => {
      historyUndo = structuredClone(state.history);
      state.history = state.history.filter((t) => t.id !== trade.id);
      save();
      renderHistory();
      notify("Trade deleted. Undo is available until the next history change.");
    }),
  );
  return actions;
}
function editTrade(trade) {
  const root = $("history-editor");
  root.replaceChildren(
    node("h2", "Edit saved trade: " + trade.name),
    node(
      "p",
      "The original calculation remains the estimate. Actual price assumes the full saved quantity sold; percentage fees are recalculated.",
    ),
  );
  const session = node("input", null, { id: "edit-session", maxlength: 200 }),
    notes = node("textarea", null, { id: "edit-notes", maxlength: 2000 }),
    tags = node("input", null, { id: "edit-tags", maxlength: 1000 });
  session.value = trade.session;
  notes.value = trade.notes || "";
  tags.value = trade.tags?.join(", ") || "";
  root.append(
    node("label", "Session", { for: "edit-session" }),
    session,
    node("label", "Notes", { for: "edit-notes" }),
    notes,
    node("label", "Tags (comma separated)", { for: "edit-tags" }),
    tags,
  );
  let actual = trade.actualSell || "";
  root.append(
    amountField(
      "edit-actual",
      "Actual sold price ($ per item)",
      actual,
      (v) => (actual = v),
      { optional: true },
    ),
    button("Save history changes", () => {
      try {
        actualTradeProfit({ ...trade, actualSell: actual });
      } catch (error) {
        notify(error.message);
        return;
      }
      historyUndo = structuredClone(state.history);
      Object.assign(trade, {
        session: session.value.trim() || "Default",
        notes: notes.value,
        tags: tags.value
          .split(",")
          .map((v) => v.trim())
          .filter(Boolean)
          .slice(0, 20)
          .map((v) => v.slice(0, 50)),
        actualSell: actual,
      });
      save();
      renderHistory();
      notify("History changes saved.");
    }),
    button("Cancel history edit", () => root.replaceChildren()),
  );
  session.focus();
  root.scrollIntoView?.({ block: "nearest" });
}
function favoriteButton(recipe) {
  const key = recipeKey(recipe),
    selected = state.favorites.includes(key),
    b = button(
      (selected ? "Unfavorite " : "Favorite ") + recipe.product,
      () => {
        state.favorites = selected
          ? state.favorites.filter((v) => v !== key)
          : [...state.favorites, key];
        save();
        renderLeaderboardRows();
      },
    );
  b.setAttribute("aria-pressed", String(selected));
  return b;
}
function renderBookTools(page) {
  const bulk = node("details");
  bulk.append(
    node("summary", "Bulk price paste"),
    node(
      "p",
      "Paste item price lines or CSV: item,price,unit. Units: 1, 64, 1728. Use sell:Chests for selling prices. All lines must be valid before applying.",
    ),
  );
  const text = node("textarea", null, {
      id: "bulk-prices",
      rows: 5,
      placeholder: "Spruce logs 100\nbone,2.5k,64",
    }),
    preview = node("div", null, { id: "bulk-preview" });
  bulk.append(
    node("label", "Prices to paste", { for: "bulk-prices" }),
    text,
    button("Preview pasted prices", () => {
      const parsed = parseBulkPrices(text.value);
      preview.replaceChildren(
        node("h2", "Preview price changes"),
        table(
          ["Item", "Saved price", "New price", "Unit"],
          parsed.rows.map((r) => [
            r.name,
            state[r.kind][r.id]?.value || "—",
            r.value,
            r.unit,
          ]),
        ),
      );
      for (const error of parsed.errors)
        preview.append(node("p", error, { class: "error" }));
      const apply = button("Apply pasted prices", () => {
        for (const r of parsed.rows) {
          updatePrice(state, r.kind, r.id, r.value, r.unit);
          if (r.kind === "sells")
            for (const [id, data] of Object.entries(state.inputs))
              if (id + ":" + (data.variant || "") === r.id) {
                data.sell = r.value;
                data.sellUnit = r.unit;
              }
        }
        save();
        hooks.renderForm();
        renderPrices();
        notify(parsed.rows.length + " prices applied.");
      });
      apply.disabled = Boolean(parsed.errors.length);
      preview.append(
        apply,
        button("Cancel price paste", () => preview.replaceChildren()),
      );
    }),
    preview,
  );
  page.append(bulk);
  const snapshots = node("details");
  snapshots.append(
    node("summary", "Named price snapshots"),
    node(
      "p",
      "Keep up to 20 named price books without duplicating their history. Compare normalized per-item prices, or preview a restore.",
    ),
  );
  const name = node("input", null, { id: "snapshot-name", maxlength: 200 });
  snapshots.append(
    node("label", "Snapshot name", { for: "snapshot-name" }),
    name,
    button("Save price snapshot", () => {
      try {
        state.bookSnapshots.push(
          snapshotBook(state, name.value, crypto.randomUUID()),
        );
        state.bookSnapshots = state.bookSnapshots.slice(-20);
        save();
        renderPrices();
        notify("Price snapshot saved.");
      } catch (error) {
        notify(error.message);
      }
    }),
  );
  for (const saved of state.bookSnapshots)
    snapshots.append(
      node("p", saved.name + " · " + new Date(saved.date).toLocaleString()),
      button("Preview restore " + saved.name, () =>
        previewBook({
          version: 4,
          type: "book",
          prices: saved.prices,
          sells: saved.sells,
        }),
      ),
      button("Delete snapshot " + saved.name, () => {
        state.bookSnapshots = state.bookSnapshots.filter(
          (p) => p.id !== saved.id,
        );
        save();
        renderPrices();
      }),
    );
  if (state.bookSnapshots.length) {
    const options = [
      ["current", "Current prices"],
      ...state.bookSnapshots.map((p) => [p.id, p.name]),
    ];
    let before = state.bookSnapshots[0].id,
      after = "current";
    const differences = node("div", null, { id: "snapshot-diff" }),
      show = () => {
        const book = (id) =>
          id === "current"
            ? state
            : state.bookSnapshots.find((p) => p.id === id);
        const diff = bookDiff(book(before), book(after));
        differences.replaceChildren(
          node("p", diff.length + " price changes"),
          table(
            ["Item", "Before / item", "After / item", "Change"],
            diff.map((r) => [
              r.kind + ": " + r.id,
              money(r.before),
              money(r.after),
              r.change === null ? "—" : number(r.change) + "%",
            ]),
          ),
        );
      };
    snapshots.append(
      makeSelect("snapshot-before", "Compare from", options, before, (v) => {
        before = v;
        show();
      }),
      makeSelect("snapshot-after", "Compare to", options, after, (v) => {
        after = v;
        show();
      }),
      differences,
    );
    show();
  }
  page.append(snapshots);
}
function saveTrade() {
  recalculate();
  const r = getResult();
  if (!r) {
    notify("Complete a valid calculation before saving a trade.");
    return;
  }
  const recipe = currentRecipe3();
  state.history.push({
    id: crypto.randomUUID?.() || String(Date.now()),
    date: /* @__PURE__ */ new Date().toISOString(),
    session: state.session,
    name: recipe.product,
    recipeId: recipe.id,
    variant: recipe.variant,
    quantity: r.crafted,
    profit: r.profit,
    profitBeforeFees: r.profitBeforeFees,
    fees: r.feeCost,
    cost: r.cost,
    revenue: r.revenue,
    snapshot: structuredClone(input()),
    exact: r.exact,
    notes: "",
    tags: [],
    actualSell: "",
  });
  save();
  notify("Trade saved to " + state.session + ".");
}
function renderHistory() {
  const page = $("history-page");
  page.replaceChildren(
    node("h1", "Trade History"),
    node(
      "p",
      "Saved trades are estimates, not confirmed sales. Create a session to group a run of trades.",
    ),
  );
  const toolbar = node("div", null, { class: "toolbar" }),
    session = node("input", null, {
      "aria-label": "Session name",
      maxlength: 200,
    });
  session.value = state.session;
  toolbar.append(
    session,
    button("Set session", () => {
      state.session = session.value.trim() || "Default";
      save();
      renderHistory();
    }),
    button("Export JSON", () =>
      download2(
        "donut-trades.json",
        JSON.stringify(state, null, 2),
        "application/json",
      ),
    ),
    button("Export CSV", () => {
      const cells = (v) => '"' + String(v).replace(/"/g, '""') + '"';
      const safe = (v) =>
        typeof v === "string" && /^[=+\-@\t\r]/.test(v) ? "'" + v : v;
      const lines = [
        [
          "Date",
          "Session",
          "Recipe",
          "Quantity",
          "Cost",
          "Revenue",
          "Fees",
          "Profit",
          "Actual sold price per item",
          "Actual profit",
          "Notes",
          "Tags",
        ],
        ...state.history.map((t) => [
          t.date,
          t.session,
          t.name,
          t.quantity,
          t.cost,
          t.revenue,
          t.fees || 0,
          t.profit,
          t.actualSell || "",
          safeActual(t) ?? "",
          t.notes || "",
          t.tags?.join(", ") || "",
        ]),
      ].map((row) => row.map((v) => cells(safe(v))).join(","));
      download2("donut-trades.csv", lines.join("\r\n"), "text/csv");
    }),
  );
  const upload = node("input", null, {
    type: "file",
    accept: ".json,application/json",
    id: "import-data",
  });
  const importLabel = node("label", "Import JSON", { for: "import-data" });
  upload.addEventListener("change", async () => {
    try {
      const file = upload.files[0];
      if (!file) return;
      if (file.size > 5e6)
        throw Error("Import file is too large (5 MB maximum).");
      const imported = sanitizeState(JSON.parse(await file.text()));
      pendingImport = imported;
      renderImportPreview();
    } catch (error) {
      notify("Import failed: " + error.message);
    }
  });
  toolbar.append(importLabel, upload);
  const undoButton = button("Undo last history change", () => {
    if (!historyUndo) return;
    state.history = historyUndo;
    historyUndo = null;
    save();
    renderHistory();
  });
  undoButton.disabled = !historyUndo;
  toolbar.append(undoButton);
  page.append(toolbar, node("div", null, { id: "import-preview" }));
  const sessions = [
    "All sessions",
    ...new Set(state.history.map((t) => t.session)),
  ];
  page.append(
    makeSelect(
      "history-filter",
      "Session",
      sessions.map((s) => [s, s]),
      historyFilter,
      (v) => {
        historyFilter = v;
        renderHistory();
      },
    ),
  );
  const trades = state.history
    .filter(
      (t) => historyFilter === "All sessions" || t.session === historyFilter,
    )
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  if (!trades.length)
    page.append(
      node(
        "p",
        "No trades saved yet. Calculate a trade and choose Save this trade.",
        { class: "empty-state" },
      ),
    );
  const totals = node("div", null, { class: "card" });
  metric3("Saved trades", number(trades.length), totals);
  metric3(
    "Total estimated profit",
    money(trades.reduce((s, t) => s + t.profit, 0)),
    totals,
  );
  metric3(
    "Total material cost",
    money(trades.reduce((s, t) => s + t.cost, 0)),
    totals,
  );
  page.append(totals);
  let cumulative = 0;
  page.append(
    lineChart(
      trades.map((t, index) => ({ x: index + 1, y: (cumulative += t.profit) })),
      { title: "Cumulative estimated profit", xLabel: "Saved trade number" },
    ),
  );
  const best = [...trades].sort((a, b) => b.profit - a.profit).slice(0, 3),
    worst = [...trades].sort((a, b) => a.profit - b.profit).slice(0, 3);
  page.append(
    node("h2", "Best / worst trades"),
    table(
      ["Best trade", "Profit", "Worst trade", "Profit"],
      Array.from({ length: Math.max(best.length, worst.length) }, (_, i) => [
        best[i]?.name || "\u2014",
        money(best[i]?.profit),
        worst[i]?.name || "\u2014",
        money(worst[i]?.profit),
      ]),
    ),
  );
  page.append(
    table(
      [
        "Date",
        "Session",
        "Recipe",
        "Quantity",
        "Estimated profit",
        "Actual profit",
        "Difference",
        "Notes / tags",
        "Actions",
      ],
      trades.map((t) => [
        new Date(t.date).toLocaleString(),
        t.session,
        t.name,
        number(t.quantity),
        money(t.profit),
        money(safeActual(t)),
        money(safeActual(t) === null ? null : safeActual(t) - t.profit),
        (t.notes || "") + (t.tags?.length ? " · " + t.tags.join(", ") : ""),
        tradeActions(t),
      ]),
    ),
  );
  page.append(node("div", null, { id: "history-editor" }));
}
var pendingImport;
function renderImportPreview() {
  const root = $("import-preview");
  root.replaceChildren(
    node(
      "p",
      `Import ${pendingImport.history.length} trades and ${Object.keys(pendingImport.prices).length} shared prices? This replaces saved app data. Export first if you want a backup.`,
    ),
    button("Replace with imported data", () => {
      replaceState3(pendingImport);
      pendingImport = null;
      renderHistory();
      notify("Imported data saved.");
    }),
    button("Cancel import", () => {
      pendingImport = null;
      root.replaceChildren();
    }),
  );
}

var renderResult = (...args) => hooks.renderResult(...args);
function renderChains() {
  const page = $("chains-page");
  page.replaceChildren(
    node("h1", "Crafting Chains"),
    node(
      "p",
      "Choose a finished recipe in Calculator, then choose whether to buy or craft intermediate materials. Uses shared material prices and the current quantity, budget, selling price, and fees.",
    ),
  );
  const recipe = currentRecipe3(),
    choices = (state.chains[recipeKey(recipe)] ||= {});
  const candidates = /* @__PURE__ */ new Set();
  function visit(r) {
    for (const i of r.ingredients)
      if (producers3[i.id] && !candidates.has(i.id)) {
        candidates.add(i.id);
        visit(resolveRecipe3(producers3[i.id]));
      }
  }
  visit(recipe);
  if (!candidates.size)
    page.append(
      node(
        "p",
        "This recipe has no supported intermediate craft. Try Spruce slabs, End crystals, or Book & Quill (buy books).",
      ),
    );
  for (const id of candidates)
    page.append(
      makeSelect(
        "source-" + id,
        id.replace(/-/g, " ") + " source",
        [
          ["buy", "Buy at shared price"],
          ["craft", "Craft from raw materials"],
          ["auto", "Cheapest buy or craft"],
        ],
        choices[id] || "buy",
        (v) => {
          choices[id] = v;
          save();
          renderChains();
        },
      ),
    );
  const needed = /* @__PURE__ */ new Map();
  function collect(r) {
    for (const i of r.ingredients) {
      needed.set(i.id, i);
      if (["craft", "auto"].includes(choices[i.id]) && producers3[i.id])
        collect(resolveRecipe3(producers3[i.id]));
    }
  }
  collect(recipe);
  page.append(
    button("Cheapest route", () => {
      for (const id of candidates) choices[id] = "auto";
      save();
      renderChains();
    }),
    node(
      "p",
      "Compares whole batches for this quantity. Auto uses the available alternative when one price is missing. Routes use market prices; inventory is applied to the chosen route afterward.",
      { class: "hint" },
    ),
  );
  const fields = node("div", null, { class: "price-grid" });
  for (const i of needed.values()) {
    const entry = state.prices[i.id] || { value: "", unit: "1" };
    fields.append(
      amountField(
        "chain-price-" + i.id,
        i.name + " ($ per item)",
        entry.value,
        (v) => {
          updatePrice(
            state,
            "prices",
            i.id,
            v,
            state.prices[i.id]?.unit || "1",
          );
          save();
          clearTimeout(chainTimer);
          chainTimer = setTimeout(renderChainsResult, 200);
        },
        {
          units: [
            ["1", "Per item"],
            ["64", "Per stack"],
            ["1728", "Per shulker"],
          ],
          unit: entry.unit,
          onUnit: (v) => {
            updatePrice(
              state,
              "prices",
              i.id,
              state.prices[i.id]?.value || "",
              v,
            );
            save();
            renderChainsResult();
          },
        },
      ),
    );
  }
  page.append(fields, node("div", null, { id: "chain-result", class: "card" }));
  renderChainsResult();
}
var chainTimer;
function renderChainsResult() {
  const root = $("chain-result");
  if (!root) return;
  try {
    const recipe = currentRecipe3(),
      choices = state.chains[recipeKey(recipe)] || {};
    const prices = normalizePrices(
      recipe,
      Object.fromEntries(
        recipe.ingredients.map((i) => [
          i.id,
          ["craft", "auto"].includes(choices[i.id])
            ? { value: "0", unit: "1" }
            : state.prices[i.id],
        ]),
      ),
    );
    const r = calculate(
      recipe,
      input(),
      prices,
      chainCostHook(state.prices, choices),
    );
    renderResult(r, root);
    root.append(node("h2", "Intermediate steps: buy vs. craft"));
    if (!r.steps.length)
      root.append(
        node("p", "All ingredients are purchased at their shared prices."),
      );
    for (const step of r.steps) {
      const box = node("div", null, { class: "recipe" });
      box.append(
        node("strong", step.name),
        node(
          "p",
          `${number(step.quantity)} made; ${number(step.needed)} used; ${number(step.leftover)} leftover. Craft cost ${money(step.cost)} \xB7 Buy cost ${money(step.buyCost)}.`,
        ),
      );
      root.append(box);
    }
  } catch (error) {
    root.replaceChildren(node("p", error.message));
  }
}

var renderResult2 = (...args) => hooks.renderResult(...args);
var compareA;
var compareB;
var compareRank = "profit";
function scenarioFromCurrent() {
  return {
    recipeId: state.mode,
    variant: input().variant,
    data: structuredClone(input()),
    prices: structuredClone(state.prices),
    sale: structuredClone(state.sells[recipeKey(currentRecipe3())] || {}),
  };
}
function renderCompare() {
  compareA ||= scenarioFromCurrent();
  compareB ||= scenarioFromCurrent();
  const page = $("compare-page");
  page.replaceChildren(
    node("h1", "Compare two trades"),
    node(
      "p",
      "Adjust suppliers, quantities, selling prices, or book sources independently. Scenario changes do not overwrite your price book.",
    ),
  );
  page.append(
    button("Use current calculator for both", () => {
      compareA = scenarioFromCurrent();
      compareB = scenarioFromCurrent();
      renderCompare();
    }),
  );
  page.append(
    makeSelect(
      "compare-rank",
      "Compare by",
      [
        ["profit", "Total profit"],
        ["returnPercent", "Return (%)"],
        ["profitHour", "Profit per hour"],
      ],
      compareRank,
      (v) => {
        compareRank = v;
        renderCompareResults();
      },
    ),
  );
  const grid = node("div", null, { class: "two-columns" }),
    winner = node("p", null, { id: "comparison-winner", role: "status" });
  page.append(winner, grid);
  for (const [key, scenario] of [
    ["A", compareA],
    ["B", compareB],
  ]) {
    const box = node("section", null, {
      class: "card",
      id: "scenario-" + key,
    });
    box.append(node("h2", "Scenario " + key));
    const options = allRecipes().map((r) => [recipeKey(r), r.product]);
    box.append(
      makeSelect(
        "compare-recipe-" + key,
        "Recipe / variant",
        options,
        scenario.recipeId + ":" + (scenario.variant || ""),
        (v) => {
          [scenario.recipeId, scenario.variant] = v.split(":");
          renderCompare();
        },
      ),
    );
    const recipe = resolveRecipe3(scenario.recipeId, scenario.variant);
    box.append(
      makeSelect(
        "compare-order-" + key,
        "Order by",
        [
          ["quantity", "Quantity"],
          ["budget", "Budget"],
        ],
        scenario.data.orderMode,
        (v) => {
          scenario.data.orderMode = v;
          renderCompare();
        },
      ),
    );
    for (const [field, label] of [
      ["amount", "Quantity or budget"],
      ["sell", "Selling price"],
      ["throughput", "Output per hour"],
    ])
      box.append(
        amountField(
          "compare-" + field + "-" + key,
          label,
          scenario.data[field],
          (v) => {
            scenario.data[field] = v;
            if (field === "sell")
              scenario.sale = {
                value: v,
                unit: scenario.data.sellUnit,
                updated: /* @__PURE__ */ new Date().toISOString(),
              };
            renderCompareResults();
          },
        ),
      );
    for (const i of recipe.ingredients) {
      const entry = scenario.prices[i.id] || { value: "", unit: "1" };
      box.append(
        amountField(
          "compare-price-" + key + "-" + i.id,
          i.name + " cost ($)",
          entry.value,
          (v) => {
            scenario.prices[i.id] = {
              value: v,
              unit: scenario.prices[i.id]?.unit || "1",
            };
            renderCompareResults();
          },
          {
            units: [
              ["1", "Per item"],
              ["64", "Per stack"],
              ["1728", "Per shulker"],
            ],
            unit: entry.unit,
            onUnit: (v) => {
              scenario.prices[i.id] = { ...entry, unit: v };
              renderCompareResults();
            },
          },
        ),
      );
    }
    box.append(
      node(
        "p",
        "Quantity and sale units, fees, and order-cost override are copied from Calculator. Use \u201CUse current calculator for both\u201D to refresh them.",
        { class: "hint" },
      ),
      node("div", null, { id: "compare-result-" + key }),
    );
    grid.append(box);
  }
  renderCompareResults();
}
function renderCompareResults() {
  const results = [];
  for (const [key, s] of [
    ["A", compareA],
    ["B", compareB],
  ]) {
    try {
      const recipe = resolveRecipe3(s.recipeId, s.variant),
        r = calculate(
          recipe,
          s.data,
          normalizePrices(recipe, s.prices, s.data),
        );
      renderResult2(r, $("compare-result-" + key), {
        prices: s.prices,
        sell: s.sale,
      });
      results.push([key, r, rankingValue(r, compareRank, s.data.throughput)]);
    } catch (error) {
      $("compare-result-" + key).replaceChildren(node("p", error.message));
    }
  }
  if (results.length === 2) {
    const [a, b] = results;
    if (a[2] === null || b[2] === null) {
      $("comparison-winner").textContent =
        "This ranking needs a positive cost or output/hour in both scenarios.";
      for (const key of ["A", "B"])
        $("scenario-" + key).classList.remove("winner");
      return;
    }
    const winner = a[2] === b[2] ? "Tie" : a[2] > b[2] ? "A" : "B";
    $("comparison-winner").textContent =
      winner === "Tie"
        ? "Both scenarios tie for " + compareRank + "."
        : `Scenario ${winner} ranks higher by ${compareRank === "returnPercent" ? number(Math.abs(a[2] - b[2])) + " percentage points" : money(Math.abs(a[2] - b[2]))} (${compareRank === "profitHour" ? "profit per hour" : compareRank === "profit" ? "total profit" : "return"}).`;
    for (const key of ["A", "B"])
      $("scenario-" + key).classList.toggle("winner", key === winner);
  } else
    $("comparison-winner").textContent = "Complete both scenarios to compare.";
}

var draft = { id: "", name: "My crafting plan", items: [] };
var budget = "";
var count = "3";
var cap = "";
function snapshot() {
  const recipe = currentRecipe3();
  return {
    recipeId: recipe.id,
    variant: recipe.variant,
    input: structuredClone(input()),
    prices: structuredClone(state.prices),
  };
}
function addCurrentTrade() {
  if (!hooks.getResult()) {
    notify("Complete a valid trade first.");
    return;
  }
  if (draft.items.length >= 50) {
    notify("A plan can contain up to 50 trades.");
    return;
  }
  draft.items.push(snapshot());
  hooks.showPage("plans");
}
function renderPlans() {
  const page = $("plans-page");
  page.replaceChildren(
    node("h1", "Shopping list & plans"),
    node(
      "p",
      "Split a material budget across profitable recipes with complete saved prices. Suggestions use return on cost and the current calculator\u2019s fees. Each chosen recipe receives an equal share of the remaining budget, up to your cap. All output is assumed sold.",
    ),
  );
  if (hasExamples(state))
    page.append(
      node(
        "p",
        "EXAMPLE DATA: suggestions may use placeholder prices. Replace them with your server prices.",
        { class: "example-banner" },
      ),
    );
  page.append(
    amountField(
      "plan-budget",
      "Total material budget ($)",
      budget,
      (v) => (budget = v),
    ),
    amountField(
      "plan-count",
      "Maximum recipes (1\u201310)",
      count,
      (v) => (count = v),
      { whole: true },
    ),
    amountField(
      "plan-cap",
      "Maximum spend per recipe ($, optional)",
      cap,
      (v) => (cap = v),
      { optional: true },
    ),
    button(
      "Suggest budget plan",
      () => {
        try {
          const result = bulkPlan(state, {
            budget: parseAmount(budget),
            count: parseAmount(count),
            cap: cap.trim() ? parseAmount(cap) : Infinity,
            fees: input().fees,
          });
          draft = {
            id: "",
            name: "Budget plan",
            items: result.items.map(
              ({ recipeId, variant, input: input8, prices }) => ({
                recipeId,
                variant,
                input: structuredClone(input8),
                prices: structuredClone(prices),
              }),
            ),
          };
          renderPlans();
          notify(
            result.items.length
              ? money(result.unspent) + " remains unspent."
              : "No affordable profitable recipes with complete prices.",
          );
        } catch (e) {
          notify(e.message);
        }
      },
      true,
    ),
  );
  const name = node("input", null, {
    id: "plan-name",
    type: "text",
    maxlength: 200,
  });
  name.value = draft.name;
  name.addEventListener("input", () => (draft.name = name.value));
  const label = node("label", "Plan name", { for: "plan-name" });
  page.append(label, name);
  if (draft.items.length) {
    try {
      const totals = evaluatePlan(draft);
      page.append(
        node("h2", draft.name || "Untitled plan", { class: "print-plan-name" }),
      );
      showTotals(page, totals);
      const checklist = node("section", null, { class: "card plan-checklist" });
      checklist.append(node("h2", "Shopping checklist"));
      for (const row of totals.rows.filter((r) => r.quantity)) {
        const control = node("input", null, {
          type: "checkbox",
          id: "shopping-" + row.id,
        });
        control.checked = draft.checked?.includes(row.id) || false;
        control.addEventListener("change", () => {
          draft.checked = control.checked
            ? [...new Set([...(draft.checked || []), row.id])]
            : (draft.checked || []).filter((id) => id !== row.id);
          if (draft.id) {
            const saved = state.plans.find((p) => p.id === draft.id);
            if (saved) saved.checked = [...draft.checked];
            save();
          }
        });
        const label = node(
          "label",
          number(row.quantity) + " " + row.name + " · " + money(row.cost),
          { for: control.id },
        );
        label.prepend(control);
        checklist.append(label);
      }
      page.append(
        checklist,
        button("Print shopping list", () => window.print()),
        button("Copy as Discord text", async () => {
          try {
            await clipboard(discordPlan(draft, totals));
            notify("Shopping list copied.");
          } catch (error) {
            notify(error.message);
          }
        }),
      );
    } catch (e) {
      page.append(node("p", e.message, { class: "error" }));
    }
    draft.items.forEach((item, i) => {
      const row = node("div", null, { class: "toolbar" });
      row.append(
        node(
          "span",
          item.recipeId +
            " \xB7 " +
            item.input.amount +
            " (" +
            (item.input.orderMode || "quantity") +
            ")",
        ),
        button("Remove trade " + (i + 1), () => {
          draft.items.splice(i, 1);
          renderPlans();
        }),
      );
      page.append(row);
    });
  } else
    page.append(
      node(
        "p",
        "Your plan is empty. Add a completed calculator trade or suggest a budget plan.",
        { class: "empty-state" },
      ),
    );
  page.append(
    button("Save plan", () => {
      if (!draft.items.length) {
        notify("Add at least one trade.");
        return;
      }
      draft.id = draft.id || crypto.randomUUID();
      draft.date = /* @__PURE__ */ new Date().toISOString();
      const index = state.plans.findIndex((p) => p.id === draft.id);
      if (index >= 0) state.plans[index] = structuredClone(draft);
      else state.plans.push(structuredClone(draft));
      state.plans = state.plans.slice(-100);
      save();
      renderPlans();
      notify("Plan saved.");
    }),
    button("New plan", () => {
      draft = { id: "", name: "My crafting plan", items: [] };
      renderPlans();
    }),
    button("Share plan", () =>
      sharePayload({ version: 4, type: "plan", plan: draft }),
    ),
    button("Export plan JSON", () =>
      download2(
        "donut-plan.json",
        JSON.stringify({ version: 4, type: "plan", plan: draft }, null, 2),
        "application/json",
      ),
    ),
  );
  page.append(node("h2", "Saved plans"));
  if (!state.plans.length)
    page.append(
      node("p", "Saved plans appear here. Each retains its original prices.", {
        class: "empty-state",
      }),
    );
  for (const plan of state.plans)
    page.append(
      button(plan.name || "Untitled plan", () => {
        draft = structuredClone(plan);
        renderPlans();
      }),
      button("Delete " + plan.name, () => {
        state.plans = state.plans.filter((p) => p.id !== plan.id);
        save();
        renderPlans();
      }),
    );
  const file = node("input", null, {
    type: "file",
    accept: ".json,application/json",
    "aria-label": "Import plan JSON",
  });
  file.addEventListener("change", async () => {
    try {
      const f = file.files[0];
      if (!f) return;
      if (f.size > 2e6) throw Error("File is too large.");
      const p = JSON.parse(await f.text());
      const { sanitizeState: sanitizeState2 } = await import("./state.js");
      if (p.type !== "plan") throw Error("Choose a plan file.");
      const clean = sanitizeState2({ version: p.version, plans: [p.plan] });
      if (!clean.plans[0]) throw Error("Invalid plan.");
      previewPlan(clean.plans[0]);
    } catch (e) {
      notify(e.message);
    }
  });
  page.append(file);
}
function showTotals(parent, result) {
  const names = [
    ...new Set(
      result.items.flatMap((i) =>
        i.result.rows.filter((r) => stale(i.prices[r.id])).map((r) => r.name),
      ),
    ),
  ];
  if (names.length)
    parent.append(
      node("p", "Stale material prices: " + names.join(", "), {
        class: "stale-warning",
      }),
    );
  const card = node("section", null, { class: "card" });
  metric3("Combined purchase cost", money(result.cost), card);
  metric3("Combined revenue", money(result.revenue), card);
  metric3("Combined profit after fees", money(result.profit), card);
  card.append(
    table(
      ["Material", "Items", "Stacks (64)", "Shulkers (1728)", "Cost"],
      result.rows.map((r) => [
        r.name,
        number(r.quantity),
        number(r.quantity / 64),
        number(r.quantity / 1728),
        money(r.cost),
      ]),
    ),
  );
  parent.append(card);
}
function previewPlan(plan) {
  const panel = node("section", null, { class: "card import-preview" });
  panel.append(node("h2", "Preview shared plan: " + plan.name));
  try {
    showTotals(panel, evaluatePlan(plan));
    panel.append(
      button(
        "Use this plan",
        () => {
          draft = structuredClone(plan);
          draft.id = "";
          renderPlans();
        },
        true,
      ),
    );
  } catch (e) {
    panel.append(node("p", e.message));
  }
  panel.append(button("Cancel import", () => panel.remove()));
  $("plans-page").prepend(panel);
}
hooks.previewPlan = previewPlan;

var getResult2 = (...args) => hooks.getResult(...args);
function renderSensitivity() {
  const root = $("sensitivity"),
    r = getResult2();
  root.replaceChildren();
  if (!r) return;
  const card = node("section", null, { class: "card" });
  card.append(node("h2", "What if prices change?"));
  const controls = node("div", null, { class: "two-columns" }),
    graphs = node("div", null, { class: "two-columns" }),
    target = node("p");
  let sellPercent = 100,
    buyPercent = 100;
  const sellOutput = node("p"),
    buyOutput = node("p");
  const feeFactor = 1 - r.feePercent / 100;
  const sellProfit = (percent) =>
    ((r.revenue * percent) / 100) * feeFactor - r.cost - r.flatFee;
  const buyProfit = (percent) =>
    r.revenue * feeFactor - (r.cost * percent) / 100 - r.flatFee;
  function slider(id, label, onChange, output) {
    const f = node("div");
    f.append(node("label", label, { for: id }));
    const s = node("input", null, {
      id,
      type: "range",
      min: 0,
      max: 200,
      step: 1,
    });
    s.value = "100";
    s.addEventListener("input", () => onChange(Number(s.value)));
    f.append(s, output);
    return f;
  }
  controls.append(
    slider(
      "sell-slider",
      "Selling price (% of current)",
      (v) => {
        sellPercent = v;
        sellOutput.textContent = `${v}% \xB7 ${money((r.sale * v) / 100)} / item \xB7 profit ${money(sellProfit(v))}`;
        drawGraphs();
      },
      sellOutput,
    ),
    slider(
      "buy-slider",
      "Material cost (% of current)",
      (v) => {
        buyPercent = v;
        buyOutput.textContent = `${v}% \xB7 total cost ${money((r.cost * v) / 100)} \xB7 profit ${money(buyProfit(v))}`;
        drawGraphs();
      },
      buyOutput,
    ),
  );
  sellOutput.textContent =
    "100% \xB7 " + money(r.sale) + " / item \xB7 profit " + money(r.profit);
  buyOutput.textContent =
    "100% \xB7 total cost " + money(r.cost) + " \xB7 profit " + money(r.profit);
  const points = Array.from({ length: 21 }, (_, i) => i * 10);
  function drawGraphs() {
    graphs.replaceChildren(
      lineChart(
        points.map((x) => ({ x, y: sellProfit(x) })),
        {
          title: "Profit versus selling price",
          xLabel: "Selling price (% of current)",
          marker:
            r.sale && r.breakEven !== null
              ? (r.breakEven / r.sale) * 100
              : null,
          selected: { x: sellPercent, y: sellProfit(sellPercent) },
        },
      ),
      lineChart(
        points.map((x) => ({ x, y: buyProfit(x) })),
        {
          title: "Profit versus material cost",
          xLabel: "Material cost (% of current)",
          marker: r.cost
            ? ((r.revenue * feeFactor - r.flatFee) / r.cost) * 100
            : null,
          selected: { x: buyPercent, y: buyProfit(buyPercent) },
        },
      ),
    );
  }
  drawGraphs();
  card.append(
    controls,
    graphs,
    amountField(
      "target-return",
      "Price needed for target return (%)",
      "25",
      (v) => {
        const pct = parseAmount(v);
        target.textContent =
          Number.isFinite(pct) && pct >= 0
            ? "Required sale price per item: " + money(targetPrice4(r, pct))
            : "Enter a nonnegative return percentage.";
      },
    ),
    target,
  );
  target.textContent =
    "Required sale price per item for 25% return: " +
    money(targetPrice4(r, 25));
  const throughput = parseAmount(input().throughput || "");
  if (
    Number.isFinite(throughput) &&
    throughput >= 0 &&
    r.profitPerItem !== null
  )
    metric3(
      "Estimated profit per hour",
      money(throughput * r.profitPerItem),
      card,
    );
  root.append(card);
}
export {
  addCurrentTrade,
  previewPlan,
  renderChains,
  renderCompare,
  renderHistory,
  renderLeaderboard,
  renderPlans,
  renderPrices,
  renderSensitivity,
  saveTrade,
};
