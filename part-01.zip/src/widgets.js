import { parseAmount, validateAmount, number } from "./core.js";

function node(tag, text, attrs = {}) {
  const element = document.createElement(tag);
  if (text !== void 0 && text !== null) element.textContent = text;
  for (const [key, value] of Object.entries(attrs))
    if (value !== void 0) element.setAttribute(key, String(value));
  return element;
}
var $ = (id) => document.getElementById(id);
function notify(message) {
  const host = $("notice");
  if (!host) return;
  const toast = node("div", null, { class: "toast" });
  toast.append(
    node("span", message),
    button("Dismiss", () => toast.remove()),
  );
  host.append(toast);
  while (host.children.length > 5) host.children[0].remove();
  const timer = setTimeout(() => toast.remove(), 8e3);
  timer.unref?.();
}
function makeSelect(id, label, options, value, onChange) {
  const field = node("div", null, { class: "field" }),
    select = node("select", null, { id });
  field.append(node("label", label, { for: id }));
  options.forEach(([v, t]) => select.append(node("option", t, { value: v })));
  select.value = value;
  select.addEventListener("change", () => onChange(select.value));
  field.append(select);
  return field;
}
function amountField(
  id,
  label,
  value,
  onInput,
  { whole = false, units, unit = "1", onUnit, optional = false } = {},
) {
  const field = node("div", null, { class: "field" }),
    row = node("div", null, { class: "row" });
  const control = node("input", null, {
    id,
    type: "text",
    inputmode: "text",
    autocomplete: "off",
    placeholder: "e.g. 100, 2.5k, 1m",
    "aria-describedby": `${id}-preview ${id}-error`,
  });
  control.value = value ?? "";
  const preview = node("div", null, { id: `${id}-preview`, class: "hint" }),
    error = node("div", null, { id: `${id}-error`, class: "error" });
  function check(touched = false) {
    const raw = control.value;
    error.textContent =
      raw.trim() || touched
        ? validateAmount(raw, { whole, required: !optional })
        : "";
    control.setAttribute("aria-invalid", String(Boolean(error.textContent)));
    preview.textContent = Number.isFinite(parseAmount(raw))
      ? "= " + number(parseAmount(raw))
      : "";
  }
  control.addEventListener("input", () => {
    check(true);
    onInput(control.value);
  });
  check();
  row.append(control);
  if (units) {
    const select = node("select", null, { "aria-label": label + " unit" });
    units.forEach(([v, t]) => select.append(node("option", t, { value: v })));
    select.value = unit;
    select.addEventListener("change", () => onUnit(select.value));
    row.append(select);
  }
  field.append(node("label", label, { for: id }), row, preview, error);
  return field;
}
function button(text, action, primary = false) {
  const b = node("button", text, {
    type: "button",
    class: primary ? "primary" : "",
  });
  b.addEventListener("click", action);
  return b;
}
function metric(label, value, parent) {
  const row = node("div", null, { class: "metric" });
  row.append(node("span", label), node("strong", value));
  parent.append(row);
}
function download(filename, text, type) {
  const blob = new Blob([text], { type });
  const url = URL.createObjectURL(blob);
  const a = node("a", filename, { href: url, download: filename });
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 1e3);
}
function table(headers, rows) {
  const wrap = node("div", null, {
      class: "table-wrap",
      tabindex: 0,
      role: "region",
      "aria-label": headers.join(", ") + " table",
    }),
    t = node("table"),
    head = node("thead"),
    tr = node("tr");
  headers.forEach((h) => tr.append(node("th", h, { scope: "col" })));
  head.append(tr);
  t.append(head);
  const body = node("tbody");
  rows.forEach((cells, index) => {
    const r = node("tr", null, { class: index < 3 ? "top-three" : "" });
    cells.forEach((c) => {
      const td = node("td");
      td.append(c instanceof Node ? c : document.createTextNode(String(c)));
      r.append(td);
    });
    body.append(r);
  });
  t.append(body);
  wrap.append(t);
  return wrap;
}
async function clipboard(text) {
  try {
    await navigator.clipboard.writeText(text);
    notify("Copied to clipboard.");
  } catch {
    notify("Clipboard access unavailable. Copy from the text box below.");
    const box = node("textarea", null, {
      "aria-label": "Text to copy",
      rows: 6,
    });
    box.value = text;
    $("notice").append(box);
    box.focus();
    box.select();
  }
}

var paths = {
  block: "M4 4h16v16H4z M4 10h16 M10 4v6 M14 10v10",
  log: "M5 3h14v18H5z M8 3v18 M16 3v18 M5 8h14 M5 16h14",
  plank: "M3 5h18v14H3z M3 10h18 M3 14h18 M8 5v5 M16 10v4 M10 14v5",
  chest: "M3 6h18v15H3z M3 11h18 M10 10h4v5h-4z M5 3h14v3",
  bone: "M3 5h4v3l9 8h3v4h-4v-3L6 9H3z",
  book: "M3 4h8l1 2 1-2h8v16h-8l-1 1-1-1H3z M12 6v15 M6 8h3 M15 8h3 M6 12h3 M15 12h3",
  feather: "M5 21 18 5 M8 15V9l6-6h7v7l-6 6H8",
  drop: "M12 2 4 13v5l4 4h8l4-4v-5z",
  paper: "M5 2h10l4 4v16H5z M15 2v5h4 M8 11h8 M8 15h8 M8 19h5",
  hide: "M4 3h5l3 3 3-3h5l-2 7 3 7-5 4H8l-5-4 3-7z",
  gem: "M6 3h12l5 7-11 12L1 10z M1 10h22 M6 3l6 19 6-19",
  stick: "M17 2h4v4L7 22H3v-4z",
  crystal: "M12 2 5 8v9l7 5 7-5V8z M5 8l7 4 7-4 M12 12v10",
  glass: "M3 3h18v18H3z M7 15l8-8 M12 17l5-5",
  eye: "M2 10l5-5h10l5 5v4l-5 5H7l-5-5z M9 8h6v8H9z",
  anchor: "M3 3h18v18H3z M6 6h12v4H6z M7 14h10v4H7z",
  glow: "M3 3h18v18H3z M7 6h4v4H7z M13 12h5v5h-5z M5 16h4v3H5",
  slab: "M2 11h20v9H2z M2 15h20 M8 11v4 M15 15v5",
  helmet: "M3 20V9l4-6h10l4 6v11h-5v-7H8v7z M8 6h8",
  shell: "M6 3h12l4 8-4 10H6L2 11z M7 7h10v8H7z",
  wall: "M2 4h7v5h6V4h7v18h-7v-7H9v7H2z",
  sand: "M3 3h18v18H3z M6 6h3 M13 8h4 M7 13h4 M15 17h3 M4 18h3",
  coal: "M7 2h10l5 8-3 10H5L2 10z M7 7h8 M5 13h6",
  default: "M4 4h16v16H4z M8 8h8v8H8z",
};
function itemIcon(key = "default") {
  const ns = "http://www.w3.org/2000/svg",
    svg = document.createElementNS(ns, "svg"),
    path = document.createElementNS(ns, "path");
  svg.setAttribute("viewBox", "0 0 24 24");
  svg.setAttribute("aria-hidden", "true");
  svg.setAttribute("class", "item-icon icon-" + key);
  path.setAttribute("d", paths[key] || paths.default);
  path.setAttribute("fill", "none");
  path.setAttribute("stroke", "currentColor");
  path.setAttribute("stroke-width", "1.8");
  path.setAttribute("stroke-linejoin", "miter");
  svg.append(path);
  return svg;
}
export {
  $,
  amountField,
  button,
  clipboard,
  download,
  itemIcon,
  makeSelect,
  metric,
  node,
  notify,
  table,
};
