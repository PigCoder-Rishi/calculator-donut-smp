# Donut SMP · Profit Calculators

A static Minecraft crafting-profit PWA with vanilla JavaScript and no runtime dependencies. User-entered prices stay on the device. No backend, analytics, scraping, or live market requests.

## Develop and build

Use Node 22.19+ or Node 24:

```sh
npm ci --prefix tools
node tools/node_modules/@playwright/test/cli.js install chromium
npm start
```

Open http://localhost:8080. The server serves **only `dist`**, with Vercel's CSP headers. After source changes, rebuild and restart. `npm run build` produces minified, hashed JavaScript/CSS. Vercel builds into `dist`; `/donut-profit-calculator.html` redirects to `/`.

| Folder            | Contents                                                                                             |
| ----------------- | ---------------------------------------------------------------------------------------------------- |
| `src`             | Eight logical JS files: core, state, widgets, UI, pages, charts, share, startup recovery; stylesheet |
| `public`          | Recompressed images, manifest, noscript style, service-worker template                               |
| `data`            | The 18 additional recipes in `recipes.json`                                                          |
| `tests`           | Original baseline, unit/property/UI/offline/Playwright tests and recipe checksum                     |
| `tools`           | Own package/lockfile and development dependencies; build, server, audits, lint and size tools        |
| `dist`, `reports` | Generated output and test/audit artifacts; not committed                                             |

Secondary pages execute on demand. Charts load with their pages; sensitivity loads when opened. The build generates the worker's content-based cache version and precache list. Cached assets use stale-while-revalidate; offline navigation falls back to the cached app. The social banner is not precached. Offline use requires a successful initial online visit.

## Trading tools

- **Calculator:** quantity/budget, item/stack/shulker units, `k/m/b`, fees, break-even, sensitivity, target return and user-entered output/hour. Inventory charges only missing materials, including whole charcoal. Owned materials have zero purchase cost; opportunity cost is excluded and stock is not automatically consumed.
- **Best Profit:** profit/item, stack, shulker, return percentage or hourly profit; purchase-capital filter, favorites and recently used. Estimates use one output shulker and current fees. Missing prices/hourly rates are not guessed. Capital excludes fees deducted from sales.
- **Price Book:** shared costs, per-variant sale prices, stale warnings, coalesced histories, storage size, explicit pruning, validated bulk paste with preview, and up to 20 named snapshots with normalized price differences and confirmed restore.
- **History:** sessions, estimates/charts, editable session/notes/tags/actual sale price, actual-versus-estimated profit, delete/one-level undo, CSV and JSON backups. Actual price is per item, assumes the full saved quantity sold and recalculates percentage fees. Original estimates remain intact. Older trades without fee settings retain their recorded fee amount.
- **Chains:** manual buy/craft or cheapest choice for supported intermediates (books, spruce planks, glass). Auto compares whole batches for the actual quantity and budget, using an available priced alternative. Routes use market costs; inventory applies afterward. Mixed buy-and-craft routes and sale of leftovers are not optimized.
- **Compare:** independent scenarios ranked by total profit, return percentage or profit/hour, with explicit production rates.
- **Plans:** calculator trades or capped budget suggestions, original price snapshots, exact totals, shopping checklist, print view and Discord text. A single inventory pool is consumed across inventory-enabled plan trades, so stock is not counted twice. Budget suggestions use market costs. Save new plans to persist their checklist; saved-plan checklist changes persist automatically.

The dismissed welcome keeps the hero/recipe grid compact. Search survives switching calculators. Mobile has three primary tabs and a keyboard-accessible More menu. Themes, accessible chart values and reduced motion are supported.

All crafted output is assumed sold, including rounded batches. Charcoal smelts up to eight sand continuously; anchors are uncharged. Enchantments, furnace purchases, unsold output and server-specific recipe changes are excluded. Production speed comes from your output/hour.

Keyboard: `/` focuses quantity; `Enter` saves only from quantity/material-price/sell inputs; `1`–`7` switch sections; `?` opens help; `Escape` closes help/More. Arrow keys/Home/End navigate tabs, menus and charts.

## Money, storage and sharing

Totals use reduced **BigInt rational arithmetic**, including stack/shulker divisions, costs, revenues, fees and plan sums. Numbers are used at the presentation boundary. Independent BigInt property tests cover decimal cancellation. Invalid quantities/totals outside the safe integer range are rejected.

Version **4** saves under `donut-profit-v4`. If absent, versions 2/3 load from `donut-profit-v3` or `donut-profit-v2` and migrate through sanitation. Legacy keys remain backups. Saves debounce 500 ms and flush on page exit. Consecutive valid price edits within three seconds coalesce. Limits: 10,000 trades, 50 history entries/price, 100 plans with 50 trades each, and 20 snapshots. Explicit pruning keeps the newest 1,000 trades. Quota/unavailability warnings preserve in-memory work for export. Corrupt startup data has Export / confirmed Reset / Reload recovery.

New trade/book/plan links use compressed `#data=` (plain encoding when compression is unavailable). Legacy `#trade=` links convert and **preview before applying**. Oversized links export JSON. Prices merge only after confirmation; full-state imports preview replacement.

## Recipe verification

The 18 additions were verified once against the official [Minecraft Java 1.21.4 client archive](https://piston-data.mojang.com/v1/objects/a7e5a6024bfd3cd614625aa05629adf760020304/client.jar). `tests/recipe-checksum.json` retains its SHA-256 and the recipe-schema checksum instead of large extracted sources. Tests verify the checksum, ingredient counts, outputs and fixed-cost cases. The 88 original baselines remain unchanged.

## Checks and CI

```sh
npm test
npm run test:ui
npm run test:e2e
npm run test:lighthouse
npm run test:offline
npm run test:size
npm run lint
npm run format:check
```

`npm run verify` builds and runs the five requested suites sequentially. After building, `node tools/verify.js step-name` records output in `reports/step-name.json`. `npm run format` formats editable source/tests; `format:check` also covers recipe data, static assets and CI configuration.

GitHub Actions runs all five suites, ESLint, Prettier and size budgets on pushes/PRs, retaining reports/traces/screenshots on failure. Browser tests cover desktop/mobile, both themes, all seven pages, keyboard/CSP/offline behavior, recovery, migrations and trading workflows. Axe violations fail the gate. Lighthouse fails below 90 in any available category. Modern Lighthouse has no numeric PWA category; manifest, worker control, cached images and offline behavior have separate checks.

Budgets: initial JS **under 60 KB gzipped**, images **under 500 KB total**, social banner **under 300 KB**. Measurements are approximately 22.5 KB initial JS and 29.6 KB total images; `reports/build.json` and `npm run test:size` give exact output.

## Upgrade assessment

Self-assessment: **930/1000**, using the rubric below, not an independent review. All five suites ran before and after each numbered step. `tests/upgrade-checks.md` records final evidence and limitations.

| Area                    | /100 | Evidence / remaining gap                                                              |
| ----------------------- | ---: | ------------------------------------------------------------------------------------- |
| Calculation correctness |   98 | 88 baselines, independent BigInt and inventory/route tests                            |
| Performance and sizes   |   98 | Lighthouse gates; JS/images far below budgets                                         |
| Maintainability         |   90 | Eight modules, isolated tools; secondary pages share one logical file                 |
| Persistence/recovery    |   92 | Migrations, quota, corruption, pruning and debounce; localStorage remains synchronous |
| Accessibility           |   95 | Axe, keyboard, themes/mobile; no manual screen-reader audit                           |
| UX                      |   90 | Compact layout, persistent search, More menu; Chromium screenshots                    |
| Trading features        |   94 | Requested tools tested; route optimization limited to supported intermediates         |
| Offline/PWA             |   90 | Real Chromium offline reload plus simulation; no OS installation QA                   |
| Privacy/security        |   96 | Strict CSP, safe DOM, no backend/analytics; development-only dependencies             |
| CI/docs                 |   87 | Complete workflow/docs; hosted CI and production audit not exercised here             |

No requested implementation was skipped. Verification not performed: hosted GitHub Actions, Vercel production audit, Firefox/Safari, manual screen-reader and OS-level PWA installation checks. No production deployment or external publication was made.
