import fs from "node:fs/promises";
import path from "node:path";
import crypto from "node:crypto";
import { build } from "esbuild";
import { gzipSync } from "node:zlib";
const root = path.resolve(import.meta.dirname, ".."),
  dist = path.join(root, "dist");
if (path.dirname(dist) !== root) throw Error("Unexpected build output path.");
await fs.rm(dist, { recursive: true, force: true });
await fs.mkdir(dist, { recursive: true });
const result = await build({
  absWorkingDir: root,
  entryPoints: ["src/bootstrap.js", "src/styles.css"],
  outdir: dist,
  entryNames: "assets/[name]-[hash]",
  chunkNames: "assets/chunk-[hash]",
  bundle: true,
  splitting: true,
  minify: true,
  format: "esm",
  platform: "browser",
  target: "es2022",
  tsconfigRaw: {},
  metafile: true,
  plugins: [
    {
      name: "workspace-files",
      setup(b) {
        b.onResolve({ filter: /^(\.\.?\/|src\/)/ }, (args) => ({
          path: path.resolve(args.resolveDir || root, args.path),
          namespace: "workspace",
        }));
        b.onLoad({ filter: /.*/, namespace: "workspace" }, async (args) => ({
          contents: await fs.readFile(args.path, "utf8"),
          resolveDir: path.dirname(args.path),
          loader: { ".js": "js", ".css": "css", ".json": "json" }[
            path.extname(args.path)
          ],
        }));
      },
    },
  ],
});
await fs.cp(path.join(root, "public"), dist, { recursive: true });
const outputs = Object.keys(result.metafile.outputs),
  entry = outputs.find((f) =>
    result.metafile.outputs[f].entryPoint?.endsWith("bootstrap.js"),
  ),
  css = outputs.find((f) => f.endsWith(".css"));
const web = (f) =>
  "/" + path.relative(dist, path.resolve(root, f)).split(path.sep).join("/");
let html = await fs.readFile(path.join(root, "index.html"), "utf8");
html = html
  .replace('href="src/styles.css"', 'href="' + web(css) + '"')
  .replace('src="src/bootstrap.js"', 'src="' + web(entry) + '"');
await fs.writeFile(path.join(dist, "index.html"), html);
async function files(dir, prefix = "") {
  const list = [];
  for (const f of await fs.readdir(dir, { withFileTypes: true })) {
    const relative = prefix + f.name;
    if (f.isDirectory())
      list.push(...(await files(path.join(dir, f.name), relative + "/")));
    else list.push(relative);
  }
  return list;
}
const all = await files(dist);
const assets = [
  "/",
  "/index.html",
  ...all
    .filter(
      (f) =>
        !["index.html", "sw.js"].includes(f) && !f.includes("social-banner"),
    )
    .map((f) => "/" + f),
];
const digest = crypto.createHash("sha256");
for (const file of all.sort())
  digest.update(await fs.readFile(path.join(dist, file)));
const version = "donut-profit-" + digest.digest("hex").slice(0, 16);
let worker = await fs.readFile(path.join(root, "public/sw.js"), "utf8");
worker = worker
  .replace("__CACHE__", JSON.stringify(version))
  .replace("__ASSETS__", JSON.stringify(assets));
await fs.writeFile(path.join(dist, "sw.js"), worker);
const sizes = {};
for (const file of outputs)
  if (file.endsWith(".js"))
    sizes[web(file)] = gzipSync(
      await fs.readFile(path.resolve(root, file)),
    ).length;
const initial = new Set();
function visit(file) {
  if (initial.has(file)) return;
  initial.add(file);
  for (const item of result.metafile.outputs[file].imports)
    if (item.kind === "import-statement") visit(item.path);
}
visit(entry);
// The UI is loaded by the startup boundary on every visit; count it as initial.
const ui = outputs.find((f) =>
  result.metafile.outputs[f].entryPoint?.endsWith("ui.js"),
);
if (ui) visit(ui);
const mainGzip = [...initial].reduce((sum, f) => sum + (sizes[web(f)] || 0), 0);
await fs.mkdir(path.join(root, "reports"), { recursive: true });
await fs.writeFile(
  path.join(root, "reports/build.json"),
  JSON.stringify(
    { version, assets, entry: web(entry), sizes, mainGzip },
    null,
    2,
  ),
);
console.log({
  mainGzip,
  jsFiles: Object.keys(sizes).length,
  precache: assets.length,
});
if (mainGzip >= 60000) throw Error("Initial JavaScript exceeds 60 KB gzipped.");
