import fs from "node:fs";
import fsp from "node:fs/promises";
import path from "node:path";
import git from "isomorphic-git";
const dir = path.resolve(import.meta.dirname, "..");
if (!fs.existsSync(path.join(dir, ".git")))
  await git.init({ fs, dir, defaultBranch: "main" });
async function walk(folder = "") {
  for (const entry of await fsp.readdir(path.join(dir, folder), {
    withFileTypes: true,
  })) {
    const name = path.posix.join(folder, entry.name);
    if (
      [
        ".git",
        "node_modules",
        "dist",
        "reports",
        "playwright-report",
        "test-results",
      ].includes(entry.name) ||
      name.startsWith("public/images/screenshots/")
    )
      continue;
    if (entry.isDirectory()) await walk(name);
    else if (!(await git.isIgnored({ fs, dir, filepath: name })))
      await git.add({ fs, dir, filepath: name });
  }
}
await walk();
for (const [filepath, , worktree] of await git.statusMatrix({ fs, dir }))
  if (worktree === 0) await git.remove({ fs, dir, filepath });
console.log(
  await git.commit({
    fs,
    dir,
    author: { name: "Codex", email: "codex@local.invalid" },
    message: process.argv.slice(2).join(" ") || "Checkpoint",
  }),
);
