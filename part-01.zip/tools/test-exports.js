export { test, expect } from "@playwright/test";
export { default as AxeBuilder } from "@axe-core/playwright";

export async function openSection(page, name) {
  const aliases = {
    calculator: "Calculator",
    leaderboard: "Best Profit",
    prices: "Price Book",
    history: "Trade History",
    chains: "Crafting Chains",
    compare: "Compare",
    plans: "Plans",
  };
  const label = aliases[name] || name,
    tab = page.getByRole("tab", { name: label, exact: true });
  if (await tab.isVisible()) await tab.click();
  else {
    await page.locator("#more-button").click();
    await page.getByRole("menuitem", { name: label, exact: true }).click();
  }
}
