import http from "node:http";
import fs from "node:fs/promises";
import path from "node:path";
const project = path.resolve(import.meta.dirname, "..");
const root = path.join(project, "dist");
const types = {
  ".html": "text/html",
  ".js": "text/javascript",
  ".css": "text/css",
  ".json": "application/json",
  ".webmanifest": "application/manifest+json",
  ".svg": "image/svg+xml",
  ".png": "image/png",
};
const config = JSON.parse(
  await fs.readFile(path.join(project, "vercel.json"), "utf8"),
);
const security = Object.fromEntries(
  config.headers[0].headers.map((h) => [h.key, h.value]),
);
http
  .createServer(async (req, res) => {
    try {
      const pathname = decodeURIComponent(
        new URL(req.url, "http://localhost").pathname,
      );
      const target = path.resolve(
        root,
        "." + (pathname === "/" ? "/index.html" : pathname),
      );
      if (!target.startsWith(root + path.sep)) {
        res.writeHead(403);
        res.end();
        return;
      }
      const content = await fs.readFile(target);
      res.writeHead(200, {
        ...security,
        "Content-Type":
          types[path.extname(target)] || "application/octet-stream",
        "Cache-Control": "no-cache",
      });
      res.end(content);
    } catch {
      res.writeHead(404);
      res.end("Not found");
    }
  })
  .listen(Number(process.env.PORT || 8080), "127.0.0.1", () =>
    console.log(
      "Donut calculator: http://localhost:" + (process.env.PORT || 8080),
    ),
  );
