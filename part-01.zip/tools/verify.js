import { spawn } from "node:child_process";
import fs from "node:fs/promises";
const label = process.argv[2] || "check",
  runs = [];
for (const script of [
  "test",
  "test:ui",
  "test:e2e",
  "test:lighthouse",
  "test:offline",
]) {
  const args =
    script === "test"
      ? ["tests/tests.js"]
      : script === "test:ui"
        ? ["tests/test-ui.js"]
        : script === "test:e2e"
          ? [
              "tools/node_modules/@playwright/test/cli.js",
              "test",
              "--config",
              "tools/playwright.config.js",
            ]
          : script === "test:lighthouse"
            ? ["tools/lighthouse-check.js"]
            : ["tools/offline-check.js"];
  const start = Date.now();
  let output = "";
  const code = await new Promise((resolve, reject) => {
    const child = spawn(process.execPath, args, {
      windowsHide: true,
      stdio: ["ignore", "pipe", "pipe"],
    });
    for (const stream of [child.stdout, child.stderr])
      stream.on("data", (data) => {
        output += data;
        process.stdout.write(data);
      });
    child.once("error", reject);
    child.once("exit", resolve);
  });
  runs.push({ script, code, seconds: (Date.now() - start) / 1000, output });
  if (code !== 0) {
    await fs.writeFile(
      "reports/" + label + ".json",
      JSON.stringify(runs, null, 2),
    );
    throw Error(script + " failed");
  }
}
await fs.writeFile("reports/" + label + ".json", JSON.stringify(runs, null, 2));
