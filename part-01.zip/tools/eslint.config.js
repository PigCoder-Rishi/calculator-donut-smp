import js from "@eslint/js";
import unused from "eslint-plugin-unused-imports";
export default [
  { ignores: ["**/node_modules/**", "dist/**", "reports/**", "tests/**"] },
  {
    files: ["src/**/*.js", "tools/*.js"],
    languageOptions: {
      ecmaVersion: "latest",
      sourceType: "module",
      globals: Object.fromEntries(
        "console window document navigator location localStorage sessionStorage matchMedia crypto CustomEvent URL URLSearchParams Blob TextEncoder TextDecoder CompressionStream DecompressionStream atob btoa fetch caches self Response Request setTimeout clearTimeout setInterval clearInterval requestAnimationFrame cancelAnimationFrame performance Node structuredClone process Buffer global"
          .split(" ")
          .map((name) => [name, "readonly"]),
      ),
    },
    plugins: { "unused-imports": unused },
    rules: {
      ...js.configs.recommended.rules,
      "no-undef": "error",
      "no-unused-vars": [
        "error",
        {
          argsIgnorePattern: "^_",
          varsIgnorePattern: "^_",
          caughtErrorsIgnorePattern: "^_",
        },
      ],
      "unused-imports/no-unused-imports": "error",
      "no-empty": ["error", { allowEmptyCatch: true }],
    },
  },
];
