import fs from "node:fs/promises";
import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
let total = 0;
for (const name of await fs.readdir(path.join(root, "public/images"))) {
  const info = await fs.stat(path.join(root, "public/images", name));
  if (!info.isFile()) throw Error("Keep development images outside public.");
  total += info.size;
  if (name.includes("social-banner") && info.size >= 300000)
    throw Error("Social banner exceeds 300 KB.");
}
const build = JSON.parse(
  await fs.readFile(path.join(root, "reports/build.json"), "utf8"),
);
console.log({ imagesBytes: total, mainGzip: build.mainGzip });
if (total >= 500000 || build.mainGzip >= 60000)
  throw Error("Production size budget exceeded.");
