import path from "node:path";
const root = path.resolve(import.meta.dirname, "..");
import { defineConfig } from "@playwright/test";
export default defineConfig({
  testDir: "../tests/e2e",
  outputDir: "../tests/results",
  fullyParallel: false,
  workers: 1,
  retries: 0,
  timeout: 60000,
  use: {
    baseURL: "http://127.0.0.1:4183",
    reducedMotion: "reduce",
    trace: "retain-on-failure",
  },
  projects: [
    { name: "desktop", use: { viewport: { width: 1440, height: 1000 } } },
    {
      name: "mobile",
      use: {
        viewport: { width: 390, height: 844 },
        isMobile: true,
        hasTouch: true,
      },
    },
  ],
  globalSetup: "./playwright-server.js",
  reporter: [
    ["list"],
    [
      "html",
      { open: "never", outputFolder: path.join(root, "reports/playwright") },
    ],
  ],
});
