import { spawn } from "node:child_process";
import path from "node:path";
export default async function setup() {
  const root = path.resolve(import.meta.dirname, "..");
  const server = spawn(process.execPath, [path.join(root, "tools/serve.js")], {
    cwd: root,
    env: { ...process.env, PORT: "4183" },
    windowsHide: true,
    stdio: ["ignore", "pipe", "pipe"],
  });
  await new Promise((resolve, reject) => {
    server.stdout.once("data", resolve);
    server.once("error", reject);
    server.once("exit", (code) =>
      reject(Error("Browser test server exited " + code)),
    );
  });
  return async () => {
    const exited = new Promise((resolve) => server.once("exit", resolve));
    server.kill();
    await exited;
    server.stdout.destroy();
    server.stderr.destroy();
  };
}
