import { spawn } from "node:child_process";
const server = spawn(process.execPath, ["tools/serve.js"], {
  env: { ...process.env, PORT: "4175" },
  windowsHide: true,
  stdio: ["ignore", "pipe", "pipe"],
});
try {
  await new Promise((resolve, reject) => {
    server.stdout.once("data", resolve);
    server.once("error", reject);
    server.once("exit", (code) =>
      reject(Error("Offline-test server exited " + code)),
    );
  });
  process.env.BASE_URL = "http://127.0.0.1:4175/";
  await import("../tests/test-offline.js");
} finally {
  server.kill();
}
