// Development audit only. No dependency from this file is loaded by the app.
import fs from "node:fs/promises";
import { spawn } from "node:child_process";
import lighthouse from "lighthouse";
import { launch } from "chrome-launcher";
import { chromium } from "@playwright/test";
const server = spawn(process.execPath, ["tools/serve.js"], {
  env: { ...process.env, PORT: "4174" },
  windowsHide: true,
  stdio: ["ignore", "pipe", "pipe"],
});
let chrome;
try {
  await new Promise((resolve, reject) => {
    server.stdout.once("data", resolve);
    server.once("error", reject);
    server.once("exit", (code) => reject(Error("Audit server exited " + code)));
  });
  chrome = await launch({
    chromePath: chromium.executablePath(),
    chromeFlags: ["--headless", "--no-sandbox"],
    port: 9229,
  });
  const result = await lighthouse("http://127.0.0.1:4174/", {
    port: chrome.port,
    output: ["html", "json"],
    onlyCategories: ["performance", "accessibility", "best-practices", "seo"],
  });
  await fs.mkdir("reports", { recursive: true });
  await fs.writeFile("reports/lighthouse.html", result.report[0]);
  await fs.writeFile("reports/lighthouse.json", result.report[1]);
  const scores = Object.fromEntries(
    Object.entries(result.lhr.categories).map(([id, c]) => [
      id,
      Math.round(c.score * 100),
    ]),
  );
  await fs.writeFile(
    "reports/quality.json",
    JSON.stringify(
      {
        lighthouseVersion: result.lhr.lighthouseVersion,
        scores,
        pwa: "This Lighthouse version has no PWA scoring category. Manifest, image caching, service-worker control, and offline reload are covered by Playwright.",
        scope:
          "Local mobile audit under the Vercel CSP. Production deployment was not changed.",
      },
      null,
      2,
    ),
  );
  console.log(scores);
  for (const category of Object.values(result.lhr.categories))
    if (category.score < 0.9) process.exitCode = 1;
} finally {
  await chrome?.kill();
  server.kill();
}
